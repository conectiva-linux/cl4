### cleanfeed.local

# This file, if it exists in Cleanfeed's $config_dir directory,
# is loaded up and evaluated as Perl code at filter startup and
# reload, or when the config is reloaded with SIGHUP.

# It can define the following Perl subroutines, which, if
#  defined, will be called at various points in the filter.
# See the "Hacker's Guide" section of the cleanfeed(8)
#  man page for details.

# local_config - called after configuration is loaded
#
# sub local_config {
#
# }

# local_filter_before_emp - called for each article, before any
#  other filters.
#
# sub local_filter_before_emp {
#
# }

# local_filter_after_emp - called for each article, after the
#  EMP filters but before all other filters.
#
# sub local_filter_after_emp {
#
# }

# local_filter_middle - called for each article, after the
#  main filters and before the "expensive" body checks
#
# sub local_filter_middle {
#
# }

# local_filter_scoring - called for each article during the
#  scoring filter.
#
# sub local_filter_scoring {
#
# }

# local_filter_last - called for each article at the very
#  end, after all other filters
#
# sub local_filter_last {
#
# }

# local_filter_cancel - called for each cancel message
#
# sub local_filter_cancel {
#
# }

# local_filter_newrmgroup - called for each newgroup and
#  rmgroup control message
#
# sub local_filter_newrmgroup {
#
# }
