char *load_file(const char *filename);
	
