/* look at output from pnpconf and find pnp soundcard entries    */
/* also change entry to settings requested by the user           */

/* 1998-09-22 - i18n - Arnaldo Carvalho de Melo <acme@conectiva.com.br> */ 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <malloc.h>
#include <string.h>
#include <strings.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <ctype.h>
#include <newt.h>
#include <libintl.h>
#include <locale.h>

#define _(String) gettext((String))

#include "sndconfig.h"
#include "pnpconf.h"
#include "pci-probing/pciprobe.h"

/* read the pnpfile into memory             */
/* -1 means no file found, 0 means we're ok */
int RunCmd(char *cmd, char **args, char **out, char **err) {

    int infd, outfd, errfd, resultfd, resulterrfd;
    int i, pid, status;
    int resultSize;
    int outpipe[2],errpipe[2];
    char *result;
    char *resultbuf[200];
    
    infd = open("/dev/null", O_RDONLY);
    /* errfd = open("/dev/null", O_WRONLY); */
    if (out) {
	pipe(outpipe);
	outfd = outpipe[1];
	resultfd = outpipe[0];
    } else {
	outfd = -1;
	resultfd = -1;
    }
    if (err) {
	pipe(errpipe);
	errfd = errpipe[1];
	resulterrfd = errpipe[0];
    } else {
	errfd = -1;
	resulterrfd = -1;
    }

    if (!(pid = fork())) {
	close(0);
	close(1);
	close(2);
	
        dup2(infd, 0);
	
	if (out)
	    dup2(outfd, 1);
	
	if (err)
	  dup2(errfd, 2);

        close(infd);
	if (out)
	    close(outfd);
	
	if (err)
	  close(errfd);
        close(resultfd);
	close(resulterrfd);

        execv(cmd, args);
	printf(_("Something is wrong\n"));
        exit(-1);
    }
     
    close(infd);
    if (out)
      close(outfd);

    if (err)
      close(errfd);

    if (out) {
        resultSize = 0;
        result = NULL;

        do {
            i = read(resultfd, resultbuf, sizeof(resultbuf));

            if (!result) {
                result = malloc(i + 1);
            } else
                result = realloc(result, resultSize + i + 1);
            memcpy(result + resultSize, resultbuf, i);
            resultSize += i;
            result[resultSize] = '\0';
        } while (i > 0);
	
	/* Embedded '\0's are a pain in the ass */
	for (i = 0;i<resultSize-1;i++) {
	    if (!result[i])
	      result[i] = ' ';
	}

        close(resultfd);
        *out = result;
    }
    if (err) {
	resultSize = 0;
	result = NULL;
	
	do {
	    i = read(resulterrfd, resultbuf, sizeof(resultbuf));
	    
	    if (!result) {
		result = malloc(i + 1);
	    } else
	      result = realloc(result, resultSize + i + 1);
	    memcpy(result + resultSize, resultbuf, i);
	    resultSize += i;
	    result[resultSize] = '\0';
	} while (i > 0);
	
	close(resulterrfd);
	*err = result;
    }

    waitpid(pid, &status, 0);

    if (WIFEXITED(status))
        return WEXITSTATUS(status);

    return -1; 
}

#ifdef USE_PNP
static int ReadPnPConf(char **buf, int autoconfig) {
    char *args[] = { "/sbin/pnpdump", NULL, NULL, NULL };
    
    if (autoconfig) {
	args[1] = "--config";
    }
    return RunCmd("/sbin/pnpdump", args, buf, NULL);
}

/* return next line, starting at p.             */
/* mode = 1 -> mallocs return value             */
/* mode = 0 -> just returns non-NULL on success */
static char *NextLine( char **p, int mode ) {
    char *r, *s;
    
    for (r = *p; *r && *r != '\n'; r++);
    if (*r) {
	r++;
    } else {
	*p = NULL;
	return NULL;
    }

    if (mode == 1) {
	s = malloc(r-*p);
	s[r-*p-1] = 0;
	memcpy(s, *p, r-*p-1);
    } else {
	s = r;
    }

    *p = r;
    return s;
}


/* starting at 'p', look down for next card entry  */
/* return NULL if no more                          */
static char *FindNextCardHdr(char **p) {
    char *r, *l;
    int  fnd;

    fnd = 0;
    l = NULL;
    for (; **p && !fnd; ) {
	l = *p;
	r = NextLine(p, 1);
	if (r) {
	    fnd = (!strncmp(r,"# Card ", 7) && strstr(r,"serial identifier"));
	    free(r);
	}
    }

    if (fnd) 
	*p = l;
    else
	*p = NULL;

    return *p;
}


/* starting at 'p', read in the card header        */
/* assumes p points at the first line of header!   */
/* return NULL                                     */
static char *ReadCardHdr(char **p, char **id, char **ansi) {
    char *r, *s1, *s2;

    /* skip line after header and */
    /* read in the PnP identifier */
    if (!NextLine(p, 0))
	return NULL;

    if (!(r = NextLine(p, 1)))
	return NULL;

    *id = malloc(8);
    if (!strncmp(r,"# Vendor Id",11))
      memcpy(*id, r+12, 7);
    else
      memcpy(*id, r+2, 7);
    (*id)[7] = 0;
    
    if (!NextLine(p, 0))
      return NULL;
    
    if (!(r = NextLine(p, 1)))
      return NULL;

    s1 = strchr(r, '>');
    s2 = strrchr(r, '<');

    if (!s1 || !s2) {
	free(*id);
	free(r);
	return NULL;
    }

    *ansi = malloc(s2-s1);
    (*ansi)[s2-s1-1] = 0;
    memcpy(*ansi, s1+1, s2-s1-1);
    free(r);
    
    return *p;
}

/* find start of configuration for PnP card 'id' */
/* NULL means nothing found                      */
static char *FindPnPCardConfig( char ** p, char *id ) {
    char *r, *l;
    char tmpstr[80];
    int fnd;

    snprintf(tmpstr, 80, "(CONFIGURE %s", id);
    
    fnd = 0;
    l = NULL;
    while( **p && !fnd ) {
	l = *p;
	if (!(r=NextLine(p, 1)))
	    return NULL;

	fnd = !strncmp(r, tmpstr, strlen(tmpstr));
	free(r);
    }

    if (fnd)
	*p = l;
    else
	*p = NULL;

    return *p;
}
    
/* is the card supported? */
int supportedCard( char **id, char **ansistr) {
    /* Creative Labs... */
    if (!strncmp(*id, "CTL", 3)) {
	if (!strstr(*ansistr, "SB") ||
	    !strstr(*ansistr, "Vibra") ||
	    !strstr(*ansistr, "AWE"))
	    return 1;
    }
    /* Crystal Semiconductor... */
    if (!strncmp(*id, "CSC", 3))
      return 1;
    /* ESS1868... */
    if (!strncmp(*id, "ESS", 3))
      return 1;
    /* Ensoniq... */
    if (!strncmp(*id, "ENS", 3))
      return 1;
    /* Gravis... */
    if (!strncmp(*id, "GRV", 3))
      return 1;
    /* Yamaha... */
    if (!strncmp(*id, "YMH", 3))
      return 1;
    /* Terratec... */
    if (!strncmp(*id, "TER", 3))
      return 1;
    /* Aztech... */
    if (!strncmp(*id, "AZT", 3))
      return 1;
    /* OPTi... */
    if (!strncmp(*id, "OPT", 3))
      return 1;
    /* CMedia... */
    if (!strncmp(*id, "CMI", 3))
      return 1;
    return 0;
}


/* this probably doesn't need to go here, but it's as good  */
/* a place as anywhere else                                 */
int FindPCICard( char **type) {
    struct pciDevice **devs;
    int i,n;
    
    n = pciProbeDevice(PCI_AUDIO, &devs);
    if (n<1) {
      return -1;
    }
    /* We don't support more than one card anywhere else;    */
    /* why should we here?                                   */
    *type = strdup(devs[0]->name[0]);
    for (i=0; i<n; i++) {
      pciFreeDevice(devs[i]);
    }
    return 0;
}

/* find first sound card in file                             */
/* -1 means nothing found                                    */
int FindPnPCard( char **id, char **ansistr ) {
    char *buf;
    char *p;

    /* exec pnpdump and see if we found anything useful */
    if (ReadPnPConf(&buf,0) != 0)
	return -1;

    /* ok now go thru looking for several things               */
    /*                                                         */
    /* 1 -> Need to find a line starting with 'Card 1:'        */
    /*      This indicates a new PnP card listing              */
    /*                                                         */
    /* 2 -> Next line should have '# XXXnnn' where XXX         */
    /*      is the manufacturer and should be something we     */
    /*      recognise. nnnn is the model number. We only care  */
    /*      about the manucaturer. If we SEE IT, keep going,   */
    /*      else go to 'First' and  keep looking.              */
    /*                                                         */
    /* 3 -> Skip a line, then look for 'ANSI string...', save  */
    /*      the stuff between the '->' and '<-' for later use  */
    /*      If NOT SEEN, goto 1 and keep looking               */
    /*                                                         */
    /* 5 -> Look for '(CONFIGURE XXXnnnn', followed by a line  */
    /*      containing '-->Audio<--'. This is the section      */
    /*      we want, so at this point we're done.              */

    p = buf;
    while (FindNextCardHdr(&p)) {
	if (!ReadCardHdr(&p, id, ansistr))
	  return -1;

	if (!FindPnPCardConfig(&p, *id))
	  return -1;

	if (supportedCard(id,ansistr)) {
	    free(buf);
	    return 0;
	}
    }
    free(buf);
    return -1;
}

#ifndef TESTING
void frobIO(int autoconfig, int portnum, char **theLine, int *val) {
    char tmpstr[1000];

    if (autoconfig)
      (*val) = strtol(strstr((*theLine),"BASE")+5,NULL,16);
    else {
	free((*theLine));
	snprintf(tmpstr, sizeof(tmpstr),
		 "(IO %d (BASE 0x%x))", portnum, (*val));
	(*theLine) = strdup(tmpstr);
    }
}

int WriteISAPnPConf(struct settings *set,char *pnpid, int autoconfig) {
    char *buf;
    char **lines;
    char *p, *t;
    char *id, *ansistr;
    char tmpstr[100];
    int nlines, i;
    int start=-1,preamble=-1,end,done=0;
    int stage=0, io_ports=-1, inconf=0, useval=0;
    int need_io,need_irq,need_dma,need_dma2,need_mpu_io,need_mpu_irq,need_mem;
    static int madebackup=0;
    char line[1024];
    FILE *f;
    
    /* exec pnpdump and see if we found anything useful */
    if (ReadPnPConf(&buf,autoconfig) != 0)
	return -1;


    /* find top of description for card we want         */
    /* then find appropriate lines and write out values */

    p = buf;
    while (FindNextCardHdr(&p)) {
	if (!ReadCardHdr(&p, &id, &ansistr))
	  return -1;

	if (!FindPnPCardConfig(&p, id))
	  return -1;

	if (!strcmp(pnpid,id))
	  break;
    }
    if (strcmp(pnpid,id)) {
	free(buf);
	free(ansistr);
	free(id);
	return -1;
    }

    /* convert to an array of strings */
    /* easier to handle later         */
    p = buf;
    nlines = 0;
    lines = NULL;
    while ((t=NextLine(&p, 1))) {
	if (!nlines)
	    lines = (char **) malloc((sizeof(char *)));
	else
	    lines = (char **) realloc(lines, (nlines+1)*(sizeof(char *)));

	lines[nlines] = t;
	nlines++;
    }
    end = nlines - 3;
	
    /* find the correct lines */
    /* First, find end of preamble */
    while (!strstr(lines[start+1],"Card 1")) start++;
    preamble = start;
    /* Next, find card we want */
    while (!strstr(lines[start+1],pnpid)) start++;
    /* if we don't need a value, set need_value to 0 */
    need_io = set->io[0]+1;
    need_irq = set->irq[0]+1;
    need_dma = set->dma[0]+1;
    need_dma2 = set->dma2[0]+1;
    need_mpu_io = set->mpu_io[0] + 1;
    need_mpu_irq = set->mpu_irq[0] + 1;
    need_mem = set->mem[0] + 1;

    for (i=start+1;i<nlines;i++) {
	if (!strncmp(lines[i], "# End tag",9)) {
	    /* Whoops! New card, we quit. */
	    end = i;
	    break;
	}
	if (!strncmp(lines[i],"(CONFIGURE",10)) {
	    inconf = 1;
	    if (strstr(lines[i],"ESS1868/-1 (LD 3"))
	      /* IDE */
	      useval = 0;
	    else
	      useval = 1;
	    continue;
	}
	if (strstr(lines[i],"ANSI string")) {
	    int counter;
	    
	    ansistr = strdup(lines[i]);
	    for (counter=0;counter<strlen(lines[i]);counter++)
	      ansistr[counter] = toupper(ansistr[counter]);

	    /* I don't know what happens when you PnP a mounted
	     * CD-ROM controller to a different IO/IRQ, but it
	     * sounds like a Bad Idea(tm).
	     */
	    if (strstr(lines[i],"IDE") || strstr(lines[i],"ATAPI") ||
		strstr(lines[i],"CD-ROM") || strstr(lines[i],"CDROM")) {
		useval = 0;
	    }
	    continue;
	}
	/* We don't care about the comments if we're autoconfiguring... */
	if (!inconf || (lines[i][0] == '#' && autoconfig)) {
	    continue;
	}
	if (!useval && autoconfig) {
	    /* If it's a config we're not using, comment the value out. */
	    snprintf(tmpstr,sizeof(tmpstr),"# %s",lines[i]);
	    free(lines[i]);
	    lines[i] = strdup(tmpstr);
	} else {
	    if (strstr(lines[i],"(INT ")) {
		if (set->type==SOUNDSCAPE) {
		    if (need_mpu_irq) {
			if (autoconfig) {
			    set->mpu_irq[0] = strtol(strstr(lines[i],"IRQ")+4,NULL,0);
			    need_mpu_irq = 0;
			} else {
			    /* Assume 2nd IRQ in first section is for MPU... */
			    if (strstr(lines[i],"INT 1") && !stage) { 
				free(lines[i]);
				snprintf(tmpstr, sizeof(tmpstr), "(INT 1 (IRQ %2d (MODE +E)))",set->mpu_irq[0]);
				lines[i] = strdup(tmpstr);
				need_mpu_irq = 0;
			    } else if (stage) {
				/* Hopefully this isn't some bizarre other part */
				free(lines[i]);
				snprintf(tmpstr, sizeof(tmpstr), "(INT 0 (IRQ %2d (MODE +E)))",set->mpu_irq[0]);
				lines[i] = strdup(tmpstr);
				need_mpu_irq = 0;
			    }
			}
		    } else if (need_irq) {
			if (autoconfig)
			  set->irq[0] = strtol(strstr(lines[i],"IRQ")+4,NULL,0);
			else {
			    free(lines[i]);
			    snprintf(tmpstr, sizeof(tmpstr),
				     "(INT 0 (IRQ %2d (MODE +E)))", set->irq[0]);
			    lines[i] = strdup(tmpstr);
			}
			need_irq = 0;
		    } 
		} else {
		    if (need_irq && !((set->type==CMI8330) && (stage < 2))) {
			if (autoconfig)
			  set->irq[0] = strtol(strstr(lines[i],"IRQ")+4,NULL,0);
			else {
			    free(lines[i]);
			    snprintf(tmpstr, sizeof(tmpstr),
				     "(INT 0 (IRQ %2d (MODE +E)))", set->irq[0]);
			    lines[i] = strdup(tmpstr);
			}
			need_irq = 0;
		    } else if (need_mpu_irq) {
			if (autoconfig) {
			    set->mpu_irq[0] = strtol(strstr(lines[i],"IRQ")+4,NULL,0);
			    need_mpu_irq = 0;
			} else {
			    /* Assume 2nd IRQ in first section is for MPU... */
			    if (strstr(lines[i],"INT 1") && !stage) { 
				free(lines[i]);
				snprintf(tmpstr, sizeof(tmpstr), "(INT 1 (IRQ %2d (MODE +E)))",set->mpu_irq[0]);
				lines[i] = strdup(tmpstr);
				need_mpu_irq = 0;
			    } else if (stage) {
				/* Hopefully this isn't some bizarre other part */
				free(lines[i]);
				snprintf(tmpstr, sizeof(tmpstr), "(INT 0 (IRQ %2d (MODE +E)))",set->mpu_irq[0]);
				lines[i] = strdup(tmpstr);
				need_mpu_irq = 0;
			    }
			}
		    }
		}
	    } else if (strstr(lines[i],"(DMA 0")) {
		if (need_dma && !((stage==0) && (set->type==CMI8330))) {
		    if (autoconfig) 
			set->dma[0] = strtol(strstr(lines[i],"CHANNEL")+8,NULL,0);
		    else {
			free(lines[i]);
			snprintf(tmpstr, sizeof(tmpstr),
				 "(DMA 0 (CHANNEL %2d))", set->dma[0]);
			lines[i] = strdup(tmpstr);
		    }
		    need_dma = 0;
		}
	    } else if (strstr(lines[i],"(DMA 1")) {
		if (need_dma2) {
		    if (autoconfig) 
		      set->dma2[0] = strtol(strstr(lines[i],"CHANNEL")+8,NULL,0);
		    else {
			free(lines[i]);
			snprintf(tmpstr, sizeof(tmpstr),
				 "(DMA 1 (CHANNEL %2d))", set->dma2[0]);
			lines[i] = strdup(tmpstr);
		    }
		    need_dma2 = 0;
		}
	    } else if (strstr(lines[i],"(IO ")) {
		/* Gack. Everything uses IO ports, and everything
		 * puts them in seemingly random order, in random
		 * logical devices.
		 * 
		 * stage = pnp logical device
		 * io_ports = io_port number (IO 0, IO 1, etc.)
		 */
		
		io_ports++;
		switch (stage) {
		 case 0:
		    if (!(set->type==ESS1868)&&!(set->type==CMI8330))
		    switch (io_ports) {
		     case 0: 
			switch (set->type) {
			 case OPL3_SAX:
			    break;
			 case AD1816:
			    break;
			 case SSVIVO:
			    if (need_mpu_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->mpu_io[0]);
				need_mpu_io = 0;
			    }
			    break;
			 case SOUNDSCAPE:
			    if (need_mpu_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->mpu_io[0]);
				need_mpu_io = 0;
			    }
			    break;
			 default:
			    if (need_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->io[0]);
				need_io = 0;
			    }
			}
			break;
		     case 1:
			switch (set->type) {
			 case CS4232:
			    break;
			 case AD1816:
			    break;
			 case OPL3_SAX:
			    if (need_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->io[0]);
				need_io = 0;
			    }
			    break;
			 case SSVIVO:
			    if (need_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->io[0]);
				need_io = 0;
			    }
			    break;
			 default:
			    if (need_mpu_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->mpu_io[0]);
				need_mpu_io = 0;
			    }
			}
			break;
		     case 2:
			if (set->type==AD1816) {
			    if (need_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->io[0]);
				need_io = 0;
			    }
			}
		     case 3:
			if (set->type==OPL3_SAX) {
			    if (need_mpu_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->mpu_io[0]);
				need_mpu_io = 0;
			    }
			}
			break;
		     case 4:
			if (set->type==OPL3_SAX) {
			    if (need_mem) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->mem[0]);
				need_mem = 0;
			    }
			}
			break;
		     default:
			break;
		    }
		    break;
		 case 1:
		    switch (set->type) {
		     case SGALAXY:
			switch (io_ports) {
			 case 0:
			    /* sgbase port. frob 'mem' setting */
			    if (need_mem) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->mem[0]);
				need_mem = 0;
			    }
			    break;
			 case 2:
			    /* wss */
			    if (need_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->io[0]);
				need_io = 0;
			    }
			    break;
			 default:
			    break;
			}
			break;
		     case CMI8330:
			if (io_ports==0) {
			    if (need_mpu_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->mpu_io[0]);
				need_io = 0;
			    }
			}
			break;
		     case MOZART:
			if (io_ports==1) {
			    if (need_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->io[0]);
				need_io = 0;
			    }
			}
			break;
		     case MAD16PRO:
			if (io_ports==0) {
			    if (need_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->io[0]);
				need_io = 0;
			    }
			}
			break;
		     case ESS1868:
			switch (io_ports) {
			 case 0:
			    if (need_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->io[0]);
				need_io = 0;
			    }
			    break;
			 case 2:
			    if (need_mpu_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->mpu_io[0]);
				need_mpu_io = 0;
			    }
			    break;
			 default:
			    break;
			}
			break;
		     case SOUNDSCAPE:
			if (need_io) {
			    frobIO(autoconfig,io_ports,
				   &lines[i],&set->io[0]);
			    need_io = 0;
			}
			break;
		     default:
			break;
		    }
		    break;
		 case 2:
		    if (set->flags & HAS_AWE && strstr(lines[i],"620")) {
			/* pnpdump doesn't find all the AWE I/O ports... */
			int x=strstr(lines[i],"IO")[3];
			snprintf(tmpstr,sizeof(tmpstr),
				 "(IO %c (BASE 0x0620)) (IO %c (BASE 0x0A20)) (IO %c (BASE 0x0E20))",x,x+1,x+2);
			free(lines[i]);
			lines[i] = strdup(tmpstr);
		    }
		    if (set->type == SGALAXY) {
			if (need_mpu_io) {
			    frobIO(autoconfig,io_ports,
				   &lines[i],&set->mpu_io[0]);
			    need_mpu_io = 0;
			}
		    }
		    break;
		 case 3:
		    if (set->type==CS4232 || set->type==MOZART || set->type==MAD16PRO) {
			    if (need_mpu_io) {
				frobIO(autoconfig,io_ports,
				       &lines[i],&set->mpu_io[0]);
				need_mpu_io = 0;
			    }
		    }
		    if (set->type==CMI8330) {
			if (need_io) {
			    frobIO(autoconfig,io_ports,
				   &lines[i],&set->io[0]);
			}
		    }
		    break;
		 default:
		    break;
		}
	    }
	}
	if (strstr(lines[i],"(ACT Y)") && !strstr(lines[i],"uncomment the")) {
	    useval = 1;
	    inconf = 0;
	    /* Increment the number of (ACT Y) statments we've passed. */
	    stage++;
	    /* Reset number of IO ports for this stage */
	    io_ports = -1;
	    if (!autoconfig) {
		free(lines[i]);
		snprintf(tmpstr,sizeof(tmpstr), " (ACT Y)");
		lines[i] = strdup(tmpstr);
		/* if we've written everything, bail... */
		if (!(need_io|need_irq|need_dma|need_mem|
		      need_dma2|need_mpu_io|need_mpu_irq)) {
		    end = i + 2;
		    break;
		}
	    }
	}
    }

    if (!madebackup && !access("/etc/isapnp.conf", F_OK)) {
	newtWinMessage(_("File Exists"), _("Ok"),
		       _("There is already a file called /etc/isapnp.conf."
		       " The existing file will be renamed "
		       "/etc/isapnp.conf.bak and a new file will be "
		       "written."));
	rename("/etc/isapnp.conf", "/etc/isapnp.conf.bak");
	madebackup=1;
    } 

    if ((f=fopen("/etc/isapnp.conf", "w"))==NULL) {
	for (i=0; i<nlines; i++)
	  free(lines[i]);
	free(buf);
	return -1;

    }

    if (madebackup) {
	FILE *g;
	
	done=0;
	/* merge changes */
	if ((g = fopen("/etc/isapnp.conf.bak","r"))!= NULL) {
	    for (i=0;i<=preamble;i++) {
		fputs(lines[i],f);
		fputs("\n",f);
	    }
	    while (strncmp(line,"# Card 1",8))
	      fgets(line,1024,g);
	    while (strncmp(line,"# Returns all",13)) {
		fputs(line,f);
		/* Write lines until we get to the card */
		if (strstr(line,pnpid) && !done) {
		    for (i=start+2; i<end; i++) {
			/* Write new lines */
			fputs(lines[i], f);
			fputs("\n", f);
		    }
		    done = 1;
		    /* Skip until we get to a) end of card section, 
		     * b) the end of the part we configured (counted by stage)
		     */
		    while (strncmp(line,"# End tag...",12) && (stage > 0)) {
			if ((strstr(line,"(ACT Y") &&
			     (!strstr(line,"activate (ACT Y")))) 
			  stage--;
			fgets(line,1024,g);
		    }
		}
		fgets(line,1024,g);
		if (!strncmp(line,"# Returns all",13)) 
		  break;
	    }
	    /* If we got to the end and *haven't* found the card, write
	     * the card info now.
	     */
	    if (!done) {
		for (i=start; i<end; i++) {
		    fputs(lines[i],f);
		    fputs("\n",f);
		}
	    }
	    fputs(line,f);
	    /* Get last line */
	    fgets(line,1024,g);
	    fputs(line,f);
	    fclose(g);
	} else {
	    /* We shouldn't get here - we just made the backup file and
	     * now we can't open it???
	     */
	    for (i=0; i < nlines; i++) {
		fputs(lines[i], f);
		fputs("\n",f);
	    }
	}
    } else {
	/* just write file */
	for (i=0; i < nlines; i++) {
	    fputs(lines[i], f);
	    fputs("\n", f);
	}
    }

    fclose(f);
    
    for (i=0; i<nlines; i++)
	free(lines[i]);
    free(buf);
    return 0;
}
#endif

#ifdef TESTING
int main() {
    char *id, *ansistr;

    setlocale(LC_ALL, "");
    bindtextdomain("sndconfig","/usr/share/locale");
    textdomain("sndconfig");
    
    if (FindPnPCard(&id, &ansistr) != 0) {
	fprintf(stderr, _("No cards found, or error probing for pnp cards\n"));
	return 1;
    } else {
	printf(_("Found PnP Card ->%s<- ->%s<-\n"),id,ansistr);
	free(id);
	free(ansistr);
	return 0;
    }

}
#endif
#endif
