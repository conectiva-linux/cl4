#ifndef PNPCONF_H
#define PNPCONF_H

int RunCmd(char *cmd, char **args, char **out, char **err);
#ifdef USE_PNP
int FindPnPCard( char **id, char **ansistr );
int FindPCICard( char **type);
int WriteISAPnPConf( struct settings *set, char *pnpid, int autoconfig );
#endif

#endif
