/*
 * really simple sound configuration hack
   1998-09-22 - i18n - Arnaldo Carvalho de Melo <acme@conectiva.com.br>
 */

/* 	$Id: sndconfig.c,v 1.52 1999/01/28 05:08:28 notting Exp $	 */

#ifndef lint
static char vcid[] = "$Id: sndconfig.c,v 1.52 1999/01/28 05:08:28 notting Exp $";
#endif /* lint */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <malloc.h>
#include <string.h>
#include <strings.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <newt.h>
#include <ctype.h>
#include <libintl.h>
#include <locale.h>

#define _(String) gettext((String))
#define N_(String) (String)

#include "sndconfig.h"
#include "pnpconf.h"
#include "messages.h"

/* This one should be defined in the Makefile ... */
#ifndef VERSION
#define VERSION "$Revision: 1.52 $"
#endif

/* Typing all this out is a pain... */
#define STANDARD_IRQ    {5,7,9,10,-1}
#define LOW_DMA         {0,1,3,-1}
#define SB16_IO         {0x220,0x240,0x260,0x280,-1}
#define WSS_IO          {0x530,0x604,0xE80,0xF40,-1}
#define MPU401_IO       {0x330,0x300,-1}

static struct settings cards[] = {
      { ACERNB, {5,7,9,10,-1}, SB16_IO, LOW_DMA,
	  {-1}, MPU401_IO, {-1},{-1},
	  HAS_OPL3|ACER,"sb",N_("ACER Notebook sound"), 0, isa
      },
      { AD1816, {5,7,9,10,-1}, WSS_IO, LOW_DMA,
	  LOW_DMA, {-1}, {-1}, {-1},
	  HAS_OPL3,"ad1816",N_("AD1816 (Acer FX-3D, HP Kayak) *2.1.x kernels ONLY!*"), 0, isa
      },
      { ADLIB, {-1},{-1},{-1},{-1},{-1},{-1},{-1},
	  NO_INPUT_REQ,"adlib_card",N_("AdLib"), 0, isa
      },
      { ALS007, STANDARD_IRQ, SB16_IO, LOW_DMA,
	  {0,1,3,5,6,7,-1},MPU401_IO,STANDARD_IRQ,{-1},
	  HAS_OPL3,"sb",N_("Advance Logic ALS-007"), 0, isa
      },
      { SGALAXY, STANDARD_IRQ, WSS_IO, LOW_DMA,
	  LOW_DMA, MPU401_IO, STANDARD_IRQ, SB16_IO,
	  HAS_OPL3,"sgalaxy",N_("Aztech Sound Galaxy Waverider Pro 32-3D, Washington 16"), 0, isa
      },
      { CMI8330, STANDARD_IRQ, SB16_IO, LOW_DMA,
	  {0,1,3,5,6,7,-1},MPU401_IO,STANDARD_IRQ,{-1},
	  HAS_MPU401,"sb",N_("CMI8330 sound chip (Cyrix MediaGX)"), 0, isa
      },
      { DESKPROXL, {7,9,10,11,-1}, WSS_IO, LOW_DMA,
	  LOW_DMA, {-1},{-1},{-1},
	  HAS_OPL3|COMPAQ,"ad1848",N_("Compaq Deskpro XL Sound"), 0, isa
      },
      { CS4232, STANDARD_IRQ, WSS_IO, LOW_DMA,
	  LOW_DMA, MPU401_IO, STANDARD_IRQ,{-1},
	  HAS_OPL3,"cs4232",N_("Crystal CS423x sound chip"), 0, isa
      },
      { ES1370, {-1},{-1},{-1},{-1},{-1},{-1},{-1},
	  NEEDS_SOX|JOYSTICK|NO_INPUT_REQ,"es1370",N_("Ensoniq AudioPCI 1370 (SoundBlaster 64/128 PCI)"), 0, pci
      },
      { ES1371, {-1},{-1},{-1},{-1},{-1},{-1},{-1},
	  NEEDS_SOX|JOYSTICK|NO_INPUT_REQ, "es1371",N_("Creative/Ensoniq AudioPCI 1371"), 0, pci
      },
      { SOUNDSCAPE, {5,7,9,10,15,-1}, WSS_IO, LOW_DMA,
	  {-1}, MPU401_IO, STANDARD_IRQ, {-1},
	  0,"sscape",N_("Ensoniq SoundScape"), 0, isa
      },
      { SSVIVO, STANDARD_IRQ, WSS_IO, LOW_DMA,
	  LOW_DMA, MPU401_IO, STANDARD_IRQ, {-1},
	  HAS_MPU401, "ad1848", N_("Ensoniq SoundScape VIVO"), 0, isa
      },
      { ESS688, {5,7,9,10,-1},SB16_IO,LOW_DMA,
	  {-1},{-1},{-1},{-1},
	  HAS_OPL3,"sb",N_("ESS688 AudioDrive"), 0, isa
      },
      { ESS1688, {5,7,9,10,-1}, {0x220,0x230,0x240,0x250,-1}, LOW_DMA,
	  {-1}, MPU401_IO, {-1},{-1},
	  HAS_OPL3,"sb",N_("ESS1688 AudioDrive"), 0, isa
      },
      { ESS1868, {5,7,9,10,-1}, {0x220,0x230,0x240,0x250,-1}, LOW_DMA,
	  {-1},MPU401_IO,{-1},{-1},
	  HAS_OPL3,"sb",N_("ESS1868 AudioDrive"), 0, isa
      },
      { GUS, {3,5,7,9,11,12,15,-1},{0x210,0x220,0x230,0x240,0x250,0x260,-1},{1,3,5,6,7,-1},
	  {-1},{-1},{-1},{-1},
	  0,"gus",N_("Gravis UltraSound"), 0, isa
      },
      { GUSMAX, {3,5,7,9,11,12,15,-1},{0x210,0x220,0x230,0x240,0x250,0x260,-1},{1,3,5,6,7,-1},
	  {1,3,5,6,7,-1},{-1},{-1},{-1},
	  0,"gus",N_("Gravis UltraSound MAX"), 0, isa
      },
      { GUSPNP, {3,5,7,9,11,12,15,-1},{0x210,0x220,0x230,0x240,0x250,0x260,-1},{1,3,5,6,7,-1},
	  {1,3,5,6,7,-1},{-1},{-1},{-1},
	  0,"gus",N_("Gravis UltraSound PnP"), 0, isa
      },
      { SMGAMES,STANDARD_IRQ, SB16_IO, LOW_DMA,
	  {-1},{-1},{-1},{-1},
	  HAS_OPL3 | SM_GAMES, "sb",N_("Logitech SoundMan Games (not SM16 or SM Wave!)"), 0, isa
      },
      { AUDIOTRIX, {5,7,9,10,11,12,15,-1}, WSS_IO, LOW_DMA,
	  LOW_DMA, MPU401_IO, {5,7,9,10,11,12,15,-1}, {-1},
	  HAS_OPL3|SB_AS_LIB,"trix",N_("MediaTrix AudioTrix Pro"), 0, isa
      },
      { JAZZ16, STANDARD_IRQ, {0x220,0x240,0x260,-1}, LOW_DMA,
	  {0,1,3,5,6,7,-1},{0x310,0x320,0x330,-1},{-1},{-1},
	  HAS_OPL3,"sb",N_("MediaVision Jazz16 (ProSonic, SoundMan Wave)"), 0, isa
      },
      { MOZART, STANDARD_IRQ, WSS_IO, LOW_DMA,
	  LOW_DMA, {-1},{-1},{-1},
	  HAS_OPL3 | SB_AS_LIB | JOYSTICK,"mad16",N_("Mozart/MAD16 (OPTi 82C928)"), 0, isa
      },
      { MAD16PRO, STANDARD_IRQ, WSS_IO, LOW_DMA,
	  LOW_DMA, {0x300,0x310,0x320,0x330,-1}, STANDARD_IRQ, {-1},
	  HAS_OPL3 | SB_AS_LIB | JOYSTICK,"mad16",N_("MAD16 Pro (OPTi 82C929/82C930)"), 0, isa
      },
      { MIROSOUND, STANDARD_IRQ, WSS_IO, LOW_DMA,
	  LOW_DMA, MPU401_IO, STANDARD_IRQ, {-1},
	  ACI,"mad16",N_("miroSOUND PCM12"), 0, isa
      },
      { OPL3_SA, {5,7,9,10,11,12,15,-1}, WSS_IO, LOW_DMA,
	  LOW_DMA, MPU401_IO, STANDARD_IRQ, {-1},
	  HAS_OPL3, "opl3sa",N_("OPL3-SA1 sound chip"), 0, isa
      },
      { OPL3_SAX, {5,7,9,10,11,12,15,-1}, WSS_IO, LOW_DMA,
	  LOW_DMA, MPU401_IO, {-1}, {0x370,0x380,-1},
	  HAS_OPL3, "opl3sa2",N_("OPL3-SA2/3/x sound chip"), 0, isa
      },
      { PAS16, {3,5,7,9,10,11,12,-1},{0x220,0x230,0x240,-1},{0,1,2,3,5,6,7,-1},
	  {-1},{-1},{-1},{-1},
	  SB_AS_LIB|JOYSTICK,"pas2",N_("Pro Audio Spectrum/Studio 16, Logitech SoundMan 16"), 0, isa
      },
      { PSS, {3,5,7,9,10,11,12}, {0x220,0x230,0x240,0x250,-1}, LOW_DMA,
	  {-1}, MPU401_IO, STANDARD_IRQ, {-1},
	  0,"pss",N_("PSS (Orchid SW32, Cardinal DSP16)"), 0, isa
      },
      { SONICVIBES, {-1},{-1},{-1},{-1},{-1},{-1},{-1},
	  NEEDS_SOX|JOYSTICK|NO_INPUT_REQ, "sonicvibes",N_("S3 SonicVibes"), 0, pci
      },
      { SBORIG, {3,5,7,9,-1},{0x220, 0x240, -1}, {1,-1},
	  {-1},{-1},{-1},{-1},
	  HAS_OPL3,"sb",N_("Sound Blaster"), 0, isa
      },
      { SBPRO, STANDARD_IRQ,{0x220, 0x240, -1}, LOW_DMA,
	  {-1},{-1},{-1},{-1},
	  HAS_OPL3,"sb",N_("Sound Blaster Pro"), 0, isa
      },
      { SB16, STANDARD_IRQ, SB16_IO, LOW_DMA,
	  {0,1,3,5,6,7,-1},MPU401_IO,{-1},{-1},
	  HAS_OPL3,"sb",N_("Sound Blaster 16"), 0, isa
      },
      { SB32, STANDARD_IRQ, SB16_IO, LOW_DMA,
	  {0,1,3,5,6,7,-1},MPU401_IO,{-1},{-1},
	  HAS_OPL3 | HAS_AWE,"sb",N_("Sound Blaster AWE32/64"), 0, isa
      },
      { MSND_CLASSIC, {5,7,9,10,11,12,-1}, {0x210,0x220,0x230,0x240,0x250,0x260,0x290,0x3e0,-1}, {-1},
	  {-1}, {-1}, {-1}, {0xb0000,0xc8000,0xd0000,0xd8000,0xe0000,0xe8000,-1},
	  0,"msnd_classic",N_("Turtle Beach MultiSound Classic/Monterey/Tahiti"), 1, isa
      },
      { MSND_PINNACLE, {5,7,9,10,11,12,-1}, {0x210,0x220,0x230,0x240,0x250,0x260,0x290,0x3e0,-1}, {-1},
	  {-1}, MPU401_IO, STANDARD_IRQ, {0xb0000,0xc8000,0xd0000,0xd8000,0xe0000,0xe8000,-1},
	  HAS_MPU401,"msnd_classic",N_("Turtle Beach MultiSound Pinnacle/Fiji"), 2, isa
      },
/* WaveFront doesn't work (in sndconfig) */
#if 0
     { WAVEFRONT, STANDARD_IRQ, WSS_IO, LOW_DMA,
 	  LOW_DMA, {0x200,0x210,-1}, STANDARD_IRQ, {-1},
 	  LOAD_CS4232, "wavefront",N_("Turtle Beach Maui/Tropez/Tropez+"), 3, isa
      },
#endif
      { WSS, {7,9,10,11,-1}, WSS_IO, LOW_DMA,
	  LOW_DMA, {-1},{-1},{-1},
	  HAS_OPL3,"ad1848",N_("Windows Sound System (AD1848/CS4248/CS4231)"), 0, isa
      },
      { AMD7930, {-1}, {-1}, {-1},
	  {-1}, {-1}, {-1}, {-1},
	  NO_INPUT_REQ, "amd7930", N_("AMD7930 (sun4c)"), 0, sbus
      },
      { CS4231, {-1}, {-1}, {-1},
	  {-1}, {-1}, {-1}, {-1},
	  NO_INPUT_REQ, "cs4231", N_("CS4231 (some sun4m, sun4u)"), 0, sbus
      },
/* DBRI doesn't work yet */
#if 0
      { DBRI, {-1}, {-1}, {-1},
 	  {-1}, {-1}, {-1}, {-1},
 	  NO_INPUT_REQ, "dbri", N_("DBRI (SPARCstation 10, 20, LX, Voyager)"), 5, sbus
      },
#endif
      { UNSPEC, {-1}, {-1}, {-1},
	  {-1}, {-1}, {-1}, {-1},
	  0, "","", 0, isa | sbus | pci
      }
};

static void cleanupmods(struct settings *set) {
    char *rmargs[]={"/sbin/rmmod", NULL, NULL, NULL, NULL};
    int rc;

    if (set->flags & HAS_OPL3) {
	rmargs[1]="opl3";
	rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    }
    if (set->flags & HAS_MPU401) {
	rmargs[1]="mpu401";
	rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    }
    if (set->flags & HAS_AWE) {
	rmargs[1]="awe_wave";
	rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    }
    if (set->flags & ACI) {
	rmargs[1]="aci";
	rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    }
    rmargs[1]=set->modulename;
    rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    if (set->flags & LOAD_CS4232) {
	rmargs[1]="cs4232";
	rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    }
    if (set->modulename=="cs4232") {
	rmargs[1]="ad1848";
	rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    }
    if (set->flags & SB_AS_LIB) {
	rmargs[1]="sb";
	rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    }
    rmargs[1]="uart401";
    rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    rmargs[1]="sound";
    rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    rmargs[1]="soundcore";
    rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
    rmargs[1]="soundlow";
    rc = RunCmd("/sbin/rmmod", rmargs, NULL, NULL);
}

static void startsound(struct settings *set) {
    /* char *args[]={"/etc/rc.d/init.d/sound", "restart", NULL, NULL, NULL}; */
    char *args2[]={"/sbin/modprobe", NULL, NULL, NULL};
    
    /* RunCmd("/etc/rc.d/init.d/sound", args, NULL, NULL); */
    args2[1] = "sound";
    RunCmd("/sbin/modprobe", args2, NULL, NULL);
    
    if (set->flags & HAS_OPL3 || set->flags & HAS_MPU401 || set->type == SB32 ) {
	args2[1] = "midi";
	RunCmd("/sbin/modprobe", args2, NULL, NULL);
    }
	
}

/* get newt initialized, set help line, etc */
static void NewtStartUp( void ) {
    char roottext[80];

    newtInit();
    newtCls();
    newtPushHelpLine(_("  <Tab>/<Alt-Tab> between elements  |"
                     "  Use <Enter> to edit a selection") );

    snprintf(roottext, 80,
	     _("Sound Configuration Utility %s          "
             "         (C) 1998 Red Hat Software"), VERSION);
    newtDrawRootText(0, 0, roottext);
}

static char *CardTypeToString( enum cards type ) {
    if (type == SBORIG)
	return "SBORIG";
    else if (type == SBPRO)
	return "SBPRO";
    else if (type == SB16)
	return "SB16";
    else if (type == SB32)
	return "SB32";
    else if (type == AD1816)
        return "AD1816";
    else if (type == ALS007)
	return "ALS007";
    else if (type == SMGAMES)
	return "SMGAMES";
    else if (type == JAZZ16)
	return "JAZZ16";
    else if (type == CMI8330)
      return "CMI8330";
    else if (type == CS4232)
	return "CS4232";
    else if (type == ESS1868)
	return "ESS1868";
    else if (type == ESS1688)
	return "ESS1688";
    else if (type == ESS688)
	return "ESS688";
    else if (type == MOZART)
	return "MOZART";
    else if (type == MAD16PRO)
	return "MAD16PRO";
    else if (type == MSND_CLASSIC)
	return "MSND_CLASSIC";
    else if (type == MSND_PINNACLE)
	return "MSND_PINNACLE";
    else if (type == OPL3_SA)
	return "OPL3_SA";
    else if (type == OPL3_SAX)
	return "OPL3_SAX";
#if 0
    else if (type == WAVEFRONT)
	  return "WAVEFRONT";
#endif
    else if (type == ES1370)
	return "ES1370";
    else if (type == ES1371)
	return "ES1371";
    else if (type == SONICVIBES)
	return "SONICVIBES";
    else if (type == GUS)
	return "GUS";
    else if (type == GUSMAX)
	return "GUSMAX";
    else if (type == GUSPNP)
	return "GUSPNP";
    else if (type == PAS16)
	return "PAS16";
    else if (type == WSS)
	return "WSS";
    else if (type == SGALAXY)
        return "SGALAXY";
    else if (type == DESKPROXL)
	return "DESKPROXL";
    else if (type == AUDIOTRIX)
	return "AUDIOTRIX";
    else if (type == ADLIB)
	return "ADLIB";
    else if (type == SOUNDSCAPE)
	return "SOUNDSCAPE";
    else if (type == SSVIVO)
	return "SSVIVO";
    else if (type == PSS)
	return "PSS";
    else if (type == MIROSOUND)
	return "MIROSOUND";
    else if (type == AMD7930)
      return "AMD7930";
    else if (type == CS4231)
      return "CS4231";
#if 0
    else if (type == DBRI)
      return "DBRI";
#endif
    else if (type == UNSPEC)
	return "UNSPEC";
    else
      return "UNSPEC";
}

static int ReadOldCardSettings(struct settings *set) {
    FILE *f;
    char buf[100],tmpstr[100];
    char *s, *t, *u;
    int x;
    
    if ((f=fopen(CONFFILE,"r"))==NULL)
	return -1;

    set = memcpy(set, &cards[UNSPEC], sizeof(struct settings));
    while (1) {
	if (!fgets(buf,100,f))
	    break;

	if (*buf == '#')
	    continue;

	s = strchr(buf, '=');
	if (!s || !*(s+1))
	    continue;

	*s = 0;
	t = s+1;
	for (s=t; *s && isspace(*s); s++);
	if (!*s)
	    continue;
	t = s;
	s++;
	for (; *s && !isspace(*s); s++);
	if (!*s)
	    continue;
	*s = 0;
	
	if (!strcmp(buf,"CARDTYPE")) {
	    for (x=0;cards[x].type != UNSPEC;x++) {
		if (strstr(t, CardTypeToString(cards[x].type))) {
		    set = memcpy(set, &cards[x], sizeof(struct settings));
		    set->io[0] = -1;
		    set->irq[0] = -1;
		    set->dma[0] = -1;
		    set->dma2[0] = -1;
		    set->mpu_io[0] = -1;
		    set->mpu_irq[0] = -1;
		    set->mem[0] = -1;
		}
	    }
	}
    }
    
    set->descr[0]=0;
    fclose(f);
    
    /* If card is unspecified, don't even bother looking in /etc/conf.modules */
    if (set->type == UNSPEC)
      return 0;

    /* now read io settings from /etc/conf.modules */
    if ((f=fopen("/etc/conf.modules","r"))==NULL)
	return -1;
    
    /* scan for line for modulenames */
    while (1) {
	if (!fgets(buf,100,f))
	    break;
	
	if (*buf == '#')
	    continue;
	
	if (!strstr(buf, "options "))
	  continue;
	
	snprintf(tmpstr,100," %s ",set->modulename);
	if (!strstr(buf,tmpstr) && !strstr(buf,tmpstr) &&
	    !strstr(buf," mpu401 ") && !strstr(buf," mpu401 "))
	    continue;
	
	/* find start of options */
	snprintf(tmpstr,100,"%s ",set->modulename);
	s = strstr(buf,tmpstr);
	if (!s) {
	    snprintf(tmpstr,100,"mpu401 ");
	    s = strstr(buf,tmpstr);
	    if (!s)
	      continue;
	}
	
	s += strlen(tmpstr);	
	while (*s) {
	    u = s;
	    while (*s && *s != '=')
		s++;
	    if (!*s)
		continue;
	    else
		*s++ = '\0';
	    
	    t = s;
	    while (*s && *s != ' ')
		s++;
	    if (!s || !*(s+1))
		continue;
	    *s++=0;
	    
	    if (!strcmp(u,"io")) {
		if (strstr(buf, " mpu401"))
		  set->mpu_io[0] = strtol(t, NULL, 0);
		else
		  set->io[0] = strtol(t, NULL, 0);
	    }
	    else if (!strcmp(u,"irq")) {
		if (strstr(buf, " mpu401"))
		  set->mpu_irq[0] = strtol(t, NULL, 0);
		else
		  set->irq[0] = strtol(t, NULL, 0);
	    }
	    else if (!strcmp(u,"dma16"))
		set->dma2[0] = strtol(t, NULL, 0);
	    else if (!strcmp(u,"mpu_io"))
	      set->mpu_io[0] = strtol(t, NULL, 0);
	    /* silly CS4232 driver... */
	    else if (!strcmp(u,"mpu_base"))
	      set->mpu_io[0] = strtol(t, NULL, 0);
	    else if (!strcmp(u,"mpu_irq"))
	      set->mpu_irq[0] = strtol(t, NULL, 0);
	    else if (!strcmp(u,"mem"))
	      set->mem[0] = strtol(t, NULL, 0);
	    else if (!strcmp(u,"dma")) {
		char *r;
		r = strchr(t, ',');
		if (!r)
		    set->dma[0] = strtol(t,NULL,0);
		else {
		    *r++ = 0;
		    set->dma[0]  = strtol(t,NULL,0);
		    set->dma2[0] = strtol(r,NULL,0);
		}
	    }
	    
	}
    }
    fclose(f);
    
    return 0;
}

static int WriteCardSettings(struct settings *set) {
    FILE *f;
    char *type;
    
    if ((f=fopen(CONFFILE,"w"))==NULL)
	return -1;

    type = CardTypeToString(set->type);
    
    /* file format is pretty static, if you change then */
    /* this program wont read it right.                 */
    fprintf(f,_("# THIS FILE IS WRITTEN BY SNDCONFIG\n"));
    fprintf(f,_("# PLEASE USE SNDCONFIG TO MODIFY\n"));
    fprintf(f,_("# TO CHANGE THIS FILE!\n"));
    fprintf(f,_("# There should be no spaces at the start of a line\n"));
    fprintf(f,_("# or around the '=' sign\n"));
    fprintf(f,"CARDTYPE=%s\n", type);

    fclose(f);
    return 0;
}

static int GetCardType( enum cards *type ) {
    newtComponent tbox, lbox, ok, cancel, answer, form;
    int rc;
    
    newtCenteredWindow(70,17,_("Card Type"));
    form = newtForm(NULL,NULL,0);
 
    tbox = newtTextbox(5, 1, 30, 2, NEWT_FLAG_WRAP);
    newtTextboxSetText(tbox, _("Please select your card:"));

    lbox = newtListbox( 8, 3, 8, NEWT_FLAG_RETURNEXIT| NEWT_FLAG_SCROLL);
    for (rc=0;;rc++) {
	if (cards[rc].type==UNSPEC)
	  break;
	if (cards[rc].bus &
#ifdef __i386__
	    (isa|pci)
#endif
#ifdef __sparc__
	    /* Do the PCI sound cards work on the Ultra AX series? */
	    /* sailer says no. */
	    sbus
#endif
#ifdef __alpha__
	    (isa|pci)
#endif
	     )
	  newtListboxAddEntry(lbox, _(cards[rc].descr), 
			    (void *)cards[rc].type);
    }
	
    if (*type==UNSPEC)
#ifdef __sparc__
	  newtListboxSetCurrent(lbox, AMD7930);
#else
	  newtListboxSetCurrent(lbox, SBORIG);
#endif
    else
	  newtListboxSetCurrent(lbox, *type);

    ok     = newtButton(6, 12, _("Ok"));
    cancel = newtButton(20, 12, _("Cancel"));
    
    newtFormAddComponents(form, tbox, lbox, ok, cancel, NULL);

    answer = newtRunForm(form);

    if (answer != cancel) {
	*type = (int) newtListboxGetCurrent(lbox);
	rc = 0;
    } else {
	rc = -1;
    }

    newtPopWindow();
    newtFormDestroy(form);

    return rc;
}

static void mungeList(int list[10], int value) {
    int x=0;
    
    while (list[x] != value && x < 10) {
	x++;
    }
    while (list[x] != -1 && x < 10) {
	list[x]=list[x+1];
	x++;
    }
}

/* Look for the specified module in the module search path... */
static int FindModule(char *modulename) {
    char tmp[512];
    char modulepath[512];
    FILE *f;

    if ((f = fopen("/proc/version","r")) != NULL)
      fscanf(f,"Linux version %512s (",tmp);
    else {
	/* say what? no proc fs????? */
	if (!(f = popen("/bin/uname -r","r")))
	    return 0;
	fscanf(f,"%512s",tmp);
    }
    fclose(f);
    if (!access("/lib/modules/preferred",R_OK)) {
	snprintf(modulepath,512,"/lib/modules/preferred/misc/%s",modulename);
	if (!access(modulepath,R_OK))
	  return 1;
	else
	  return 0;
    }
    snprintf(modulepath,512,"/lib/modules/%s/misc/%s",tmp,modulename);
    if (!access(modulepath,R_OK))
      return 1;
    else
      return 0;
}

static int EditSettings( int pnpprobe, struct settings *set, struct settings *currset) {
    newtComponent iobox, irqbox, dmabox, dma2box, mpu_iobox, mpu_irqbox;
    newtComponent membox, ok, cancel, answer, form;
    newtComponent iolab, irqlab, dmalab, dma2lab, mpu_iolab, mpu_irqlab;
    newtComponent memlab, instrbox;
    newtGrid grid, subgrid1, subgrid3;
    int rc;
    int i,dmareq, dma2req, mpu_ioreq, mpu_irqreq,memreq;
    char tmpstr[8];
    char *text;
    
    int twidth, theight;

    form = newtForm(NULL,NULL,0);
    
#ifdef __alpha__
	/* IRQ 7 *bad* */
    mungeList(set->irq,7);
    mungeList(set->mpu_irq,7);
#endif
    
    dmareq = (set->dma[0] != -1);
    dma2req = (set->dma2[0] != -1);
    mpu_ioreq = (set->mpu_io[0] != -1);
    mpu_irqreq = (set->mpu_irq[0] != -1);
    memreq = (set->mem[0] != -1);

    iobox = newtListbox( -1, -1, 4, NEWT_FLAG_RETURNEXIT );
    iolab = newtLabel(-1, -1, _("I/O PORT"));
    for (i=0; set->io[i] != -1; i++) {
	snprintf(tmpstr, 8, "0x%3x", set->io[i]);
	newtListboxAddEntry(iobox, tmpstr, (void *) set->io[i]);
	if (currset->io[0] < 0) {
	    if (set->io[i] == 0x220)
		newtListboxSetCurrent(iobox, i);
	} else if (currset->io[0] == set->io[i]) {
	    newtListboxSetCurrent(iobox, i);
	}
    }
    
    irqbox = newtListbox( -1, -1, 4, NEWT_FLAG_RETURNEXIT );
    newtListboxSetWidth(irqbox,3);
    irqlab = newtLabel(-1, -1, _("IRQ"));
    for (i=0; set->irq[i] != -1; i++) {
	snprintf(tmpstr, 8, "%2d", set->irq[i]);
	newtListboxAddEntry(irqbox, tmpstr, (void *) set->irq[i]);
	if (currset->irq[0] < 0) {
	    if (set->irq[i] == 5)
		newtListboxSetCurrent(irqbox, i);
	} else if (currset->irq[0] == set->irq[i]) {
	    newtListboxSetCurrent(irqbox, i);
	}
    }

    if (dmareq) {
	dmabox = newtListbox( -1, -1, 4, NEWT_FLAG_RETURNEXIT );
	newtListboxSetWidth(dmabox,3);
	if ((set->dma2[0] == 5) && (set->dma[0] == 0)) {
	    dmalab = newtLabel(-1, -1, _("8-bit DMA"));
	} else if (dma2req) {
	    dmalab = newtLabel(-1, -1, _("DMA 1"));
	} else {
	    dmalab = newtLabel(-1, -1, _("DMA"));
	}
	for (i=0; set->dma[i] != -1; i++) {
	    snprintf(tmpstr, 8, "%2d", set->dma[i]);
	    newtListboxAddEntry(dmabox, tmpstr, (void *) set->dma[i]);
	    if (currset->dma[0] < 0) {
		if (set->dma[i] == 1)
		  newtListboxSetCurrent(dmabox, i);
	    } else if (currset->dma[0] == set->dma[i]) {
		newtListboxSetCurrent(dmabox, i);
	    }
	}
    } else {
	dmabox = newtTextbox( -1, -1, 0, 0, 0);
	dmalab = newtLabel(-1, -1, "");
    }
    
    if (dma2req) {
	if (set->dma2[0] == 5)
	  dma2lab = newtLabel(-1, -1, _("16-bit DMA"));
        else
	  dma2lab = newtLabel(-1, -1, _("DMA 2"));
	dma2box=newtListbox(-1,-1,4,NEWT_FLAG_RETURNEXIT );
	newtListboxSetWidth(dma2box,3);
	for (i=0; set->dma2[i] != -1; i++) {
	    snprintf(tmpstr, 8, "%2d", set->dma2[i]);
	    newtListboxAddEntry(dma2box, tmpstr, (void *) set->dma2[i]);
	    if (currset->dma2[0] < 0) {
		if (set->dma2[i] == 5)
		  newtListboxSetCurrent(dma2box, i);
	    } else  if (currset->dma2[0] == set->dma2[i]) {
		newtListboxSetCurrent(dma2box, i);
	    }
	}
    } else {
	dma2box = newtTextbox(-1, -1, 0, 0, 0);
	dma2lab = newtLabel(-1, -1, "");
    }

    if (mpu_ioreq) {
	mpu_iolab = newtLabel(-1, -1, _("MPU I/O"));
	mpu_iobox=newtListbox(-1,-1,4,NEWT_FLAG_RETURNEXIT );
	for (i=0; set->mpu_io[i] != -1; i++) {
	    snprintf(tmpstr, 8, "0x%3x", set->mpu_io[i]);
	    newtListboxAddEntry(mpu_iobox, tmpstr, (void *) set->mpu_io[i]);
	    if (currset->mpu_io[0] < 0) {
		if (set->mpu_io[i] == 0x330)
		  newtListboxSetCurrent(mpu_iobox, i);
	    } else  if (currset->mpu_io[0] == set->mpu_io[i]) {
		newtListboxSetCurrent(mpu_iobox, i);
	    }
	}
    } else {
	mpu_iobox = newtTextbox(-1, -1, 0, 0, 0);
	mpu_iolab = newtLabel(-1, -1, "");
    }

    if (mpu_irqreq) {
	mpu_irqlab = newtLabel(-1, -1, _("MPU IRQ"));
	mpu_irqbox=newtListbox(-1,-1,4,NEWT_FLAG_RETURNEXIT );
	newtListboxSetWidth(mpu_irqbox,3);
	for (i=0; set->mpu_irq[i] != -1; i++) {
	    snprintf(tmpstr, 8, "%2d", set->mpu_irq[i]);
	    newtListboxAddEntry(mpu_irqbox, tmpstr, (void *) set->mpu_irq[i]);
	    if (currset->mpu_irq[0] < 0) {
		if (set->mpu_irq[i] == 9)
		  newtListboxSetCurrent(mpu_irqbox, i);
	    } else  if (currset->mpu_irq[0] == set->mpu_irq[i]) {
		newtListboxSetCurrent(mpu_irqbox, i);
	    }
	}
    } else {
	mpu_irqbox = newtTextbox(-1, -1, 0, 0, 0);
	mpu_irqlab = newtLabel(-1, -1, "");
    }

    if (memreq) {
	if (set->type==OPL3_SAX)
	  memlab = newtLabel(-1, -1, _("CONTROL I/O"));
	else if (set->type==SGALAXY)
	  memlab = newtLabel(-1, -1, _("SB I/O"));
	else
	  memlab = newtLabel(-1, -1, _("BASE MEMORY"));
	membox=newtListbox(-1,-1,4,NEWT_FLAG_RETURNEXIT );
	for (i=0; set->mem[i] != -1; i++) {
	    if (set->type==OPL3_SAX || set->type==SGALAXY)
	      snprintf(tmpstr, 8, "0x%3x", set->mem[i]);
	    else
	      snprintf(tmpstr, 8, "0x%5x", set->mem[i]);
	    newtListboxAddEntry(membox, tmpstr, (void *) set->mem[i]);
	    if (currset->mem[0] < 0) {
		if (set->mem[i] == 0xd0000)
		  newtListboxSetCurrent(membox, i);
	    } else  if (currset->mem[0] == set->mem[i]) {
		newtListboxSetCurrent(membox, i);
	    }
	}
    } else {
	membox = newtTextbox(-1, -1, 0, 0, 0);
	memlab = newtLabel(-1, -1, "");
    }

    /* pack em */
    grid = newtCreateGrid(1, 3);
    subgrid1 = newtCreateGrid(7, 2);
    subgrid3 = newtButtonBar(_("Ok"), &ok, _("Cancel"), &cancel, NULL);

    if (pnpprobe)
	text = newtReflowText(_("Your sound card is a PnP device, so "
			      "its settings can be configured w/o "
			      "setting any dip switches.  Choose "
			      "the values you would like to use "
			      "from the menus below."), 40, 30, 30,
			      &twidth, &theight);
    else
	text = newtReflowText(_("Please adjust the settings below to "
			      "match the dip switch settings on your "
			      "sound card."), 40, 30, 30,
			      &twidth, &theight);
    
    instrbox = newtTextbox(-1, -1, twidth, theight, NEWT_FLAG_WRAP);
    newtTextboxSetText( instrbox, text );
    /* free(text); */

    newtGridSetField(subgrid1, 0, 0, NEWT_GRID_COMPONENT, iolab,
		     0, 0, 1, 1, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 0, 1, NEWT_GRID_COMPONENT, iobox,
		     0, 0, 1, 0, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 1, 0, NEWT_GRID_COMPONENT, irqlab,
		     1, 0, 1, 1, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 1, 1, NEWT_GRID_COMPONENT, irqbox,
		     1, 0, 1, 0, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 2, 0, NEWT_GRID_COMPONENT, dmalab,
		     1, 0, 1, 1, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 2, 1, NEWT_GRID_COMPONENT, dmabox,
		     1, 0, 1, 0, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 3, 0, NEWT_GRID_COMPONENT, dma2lab,
		     1, 0, 1, 1, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 3, 1, NEWT_GRID_COMPONENT, dma2box,
		     1, 0, 1, 0, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 4, 0, NEWT_GRID_COMPONENT, mpu_iolab,
		     1, 0, 1, 1, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 4, 1, NEWT_GRID_COMPONENT, mpu_iobox,
		     1, 0, 1, 0, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 5, 0, NEWT_GRID_COMPONENT, mpu_irqlab,
		     1, 0, 1, 1, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 5, 1, NEWT_GRID_COMPONENT, mpu_irqbox,
		     1, 0, 1, 0, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 6, 0, NEWT_GRID_COMPONENT, memlab,
		     1, 0, 0, 1, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(subgrid1, 6, 1, NEWT_GRID_COMPONENT, membox,
		     1, 0, 0, 0, NEWT_ANCHOR_TOP, 0);
	
    newtGridSetField(grid, 0, 0, NEWT_GRID_COMPONENT, instrbox,
		     0, 0, 0, 0, NEWT_ANCHOR_TOP, 0);
    newtGridSetField(grid, 0, 1, NEWT_GRID_SUBGRID, subgrid1,
		     0, 1, 0, 0, 0, NEWT_GRID_FLAG_GROWX);
    newtGridSetField(grid, 0, 2, NEWT_GRID_SUBGRID, subgrid3,
		     0, 1, 0, 0, 0, NEWT_GRID_FLAG_GROWX);

    newtGridWrappedWindow(grid,_("Card Settings"));

    newtFormAddComponents(form, instrbox, NULL);
    newtFormAddComponents(form, iolab, irqlab, dmalab, dma2lab, mpu_iolab,
			  mpu_irqlab, memlab, NULL);
    newtFormAddComponents(form, iobox, irqbox, dmabox, dma2box, mpu_iobox,
			  mpu_irqbox, membox, NULL);
    newtFormAddComponents(form, ok, cancel, NULL);

    answer = newtRunForm(form);

    if (answer != cancel) {
	rc = 0;
	currset->io[0] = (long) newtListboxGetCurrent(iobox);
	currset->irq[0]  = (long) newtListboxGetCurrent(irqbox);
	if (dmareq)
	  currset->dma[0] = (long) newtListboxGetCurrent(dmabox);
	if (dma2req)
	    currset->dma2[0] = (long) newtListboxGetCurrent(dma2box);
	else
	    currset->dma2[0] = -1;
	if (mpu_ioreq)
	    currset->mpu_io[0] = (long) newtListboxGetCurrent(mpu_iobox);
	else
	    currset->mpu_io[0] = -1;
	if (mpu_irqreq)
	    currset->mpu_irq[0] = (long) newtListboxGetCurrent(mpu_irqbox);
	else
	    currset->mpu_irq[0] = -1;
	if (memreq)
	    currset->mem[0] = (long) newtListboxGetCurrent(membox);
	else
	    currset->mem[0] = -1;
    } else {
	rc = -1;
    }

    newtPopWindow();
    newtFormDestroy(form);

    return rc;
}

int WriteConfModules( struct settings *set ) {
    char tmpstr[200],modulename[200];
    char tmpfile[]="/etc/sndconfig-XXXXXX";
    FILE *f, *t;
    static int madebackup=0;
    int tfilefd;

    if ((tfilefd=mkstemp(tmpfile)) < 0)
	return -1;
    close(tfilefd);
    if ((t=fopen(tmpfile, "w"))==NULL) 
	return -1;

    snprintf(modulename,200," %s ",set->modulename);
    if ((f=fopen("/etc/conf.modules", "r"))!=NULL) {
	    while(1) {
		    if (!fgets(tmpstr, sizeof(tmpstr), f))
		      break;
	
		    /* UGLY - skip these lines since we'll rewrite them */
		    /* Now even uglier */
		    if (strstr(tmpstr,"char-major-14") || 
			strstr(tmpstr, modulename) ||
			strstr(tmpstr," sound ") || strstr(tmpstr," midi ") ||
			strstr(tmpstr, " opl3 ") || strstr(tmpstr," mpu401 ") ||
			(strstr(tmpstr, " ad1848 ") && (set->type==CS4232) ) ||
			(strstr(tmpstr, " awe_wave ") && (set->flags & HAS_AWE)) ||
			(strstr(tmpstr, " cs4232 ") && (set->flags & LOAD_CS4232)))
		      continue;
		    
		    fputs(tmpstr, t);
	    }
	    fclose(f);
    }

    if (!madebackup && !access("/etc/conf.modules", F_OK)) {
	newtWinMessage(_("File Exists"), _("Ok"),
		       _("There is already a file called /etc/conf.modules."
		       " The existing file will be renamed "
		       "/etc/conf.modules.bak and a new file will be "
		       "written."));
	rename("/etc/conf.modules", "/etc/conf.modules.bak");
	madebackup=1;
    }
    

    fprintf(t,"alias sound %s\n", set->modulename);

    if (set->flags & HAS_OPL3) {
	if (!(set->flags & HAS_AWE)) 
	  fprintf(t, "alias midi opl3\n");
	fprintf(t, "options opl3 io=0x388\n");
    }
    if (set->flags & LOAD_CS4232) {
	fprintf(t, "alias midi %s\n",set->modulename);
	fprintf(t, "options %s io=0x%x irq=%d\n",set->modulename,
		set->mpu_io[0],set->mpu_irq[0]);
	fprintf(t, "pre-install %s /sbin/modprobe \"cs4232\"\n", set->modulename);
	snprintf(set->modulename,32,"cs4232");
    } 
    if (set->flags & HAS_MPU401) {
	fprintf(t, "alias midi mpu401\n");
	fprintf(t, "options mpu401 io=0x%x irq=%d\n",
		set->mpu_io[0],set->mpu_irq[0]);
	set->mpu_io[0] = -1;
	set->mpu_irq[0] = -1;
	
    }
    if (set->flags & HAS_AWE)
      fprintf(t,"alias midi awe_wave\npost-install awe_wave /bin/sfxload /etc/midi/GU11-ROM.SF2\n");

    if (set->flags & SB_AS_LIB)
      fprintf(t, "options sb %s=1\n",set->modulename);
    
    if (set->flags & ACI)
      fprintf(t,"post-install %s /sbin/modprobe \"aci\"\n",set->modulename);
	    
    if (set->flags & NO_INPUT_REQ) {
	if (set->type==ADLIB) {
	    fprintf(t,"options adlib_card io=0x388\n");
	} 
    } else {
        fprintf(t, "options %s",set->modulename);
	if (set->io[0]!=-1) {
	  if (set->type == OPL3_SAX)
	      fprintf(t," mss_io=0x%x",set->io[0]);
	  else
	      fprintf(t," io=0x%x",set->io[0]);
	}
	if (set->irq[0]!=-1)
	  fprintf(t," irq=%d",set->irq[0]);
	if (set->dma[0]!=-1)
	  fprintf(t," dma=%d",set->dma[0]);
	if (set->dma2[0]!=-1) {
	  if (!strcmp(set->modulename,"sb"))
	      fprintf(t," dma16=%d",set->dma2[0]);
	  else
	      fprintf(t," dma2=%d",set->dma2[0]);
	}
	if (set->mpu_io[0]!=-1) {
	    if (set->flags & LOAD_CS4232) {
		fprintf(t," synthio=0x%x",set->mpu_io[0]);
	    } else {
		if (!strcmp(set->modulename, "cs4232"))
		  /* No, we can't use the same name as everyone else! */
		  fprintf(t," mpu_base=0x%x",set->mpu_io[0]);
		else 
		  fprintf(t," mpu_io=0x%x",set->mpu_io[0]);
	    }
	}
	if (set->mpu_irq[0]!=-1) {
	    if (set->flags & LOAD_CS4232) {
		fprintf(t," synthirq=%d",set->mpu_irq[0]);
	    } else {
		fprintf(t," mpu_irq=%d",set->mpu_irq[0]);
	    }
	}
	/* CS4232 requires synth* if WaveFront support is compiled in */
	if (!strcmp(set->modulename,"cs4232")&& !(set->flags & LOAD_CS4232)
	    && FindModule("wavefront.o"))
	  fprintf(t," synthirq=-1 synthio=-1");
	if (set->mem[0]!=-1) {
	  if (set->type==OPL3_SAX) {
	      /* This is a stupid hack used to avoid adding another field... */
	      fprintf(t," io=0x%x",set->mem[0]);
	  } else if (set->type==SGALAXY) {
	      /* Ditto */
	      fprintf(t," sgbase=0x%x",set->mem[0]);
	  } else { 
	      fprintf(t," mem=0x%x",set->mem[0]);
	  }
	}
	if (set->flags & JOYSTICK)
	  fprintf(t, " joystick=1");
	if (set->flags & SM_GAMES)
	  fprintf(t, " sm_games=1");
	if (set->flags & COMPAQ)
	  fprintf(t, " deskpro_xl=1");
	if (set->flags & ACER)
	  fprintf(t, " acer=1");
	fprintf(t,"\n");
    }

    fclose(t);
    chmod(tmpfile,0644);
    rename(tmpfile,"/etc/conf.modules");
    return 0;
}
 
static int TestSndCard(int dopnp, struct settings *set) {
    char *args[]={"/sbin/isapnp", "/etc/isapnp.conf", NULL, NULL, NULL};
    char *modargs[]={"/sbin/modprobe", "sound", NULL, NULL, NULL};
    char *playargs[]={"/usr/bin/play","/usr/share/sndconfig/sample.au",NULL,NULL,NULL};
    char *err,*errbuf;
    char *out;
    char buf[8000];
    int fd, od;
    int rc;

    newtWinMessage(_("SoundCard Test"), _("Ok"), _("A sound sample will now be played"
		   " to determine if your sound card has been correctly"
		   " configured."));

    cleanupmods(set);
    newtSuspend();
    if (dopnp) {
	rc = RunCmd("/sbin/isapnp", args, &out,&err);
	if (rc) {
	    newtResume();
	    errbuf = strdup(_("The following error occurred "
			    "running the isapnp program:\n\n"));
	    errbuf = realloc(errbuf,strlen(errbuf)+strlen(err)+1);
	    strcat(errbuf,err);
	    newtWinMessage(_("isapnp error"), _("Ok"), errbuf);
	    free(errbuf);
	    free(err);
	    return -1;
	}
    }

    rc = RunCmd("/sbin/modprobe",modargs,&out,&err);
    if (rc) {
	newtResume();
	errbuf = strdup(_("The following error occurred running the "
			"modprobe program:\n\n"));
	errbuf = realloc(errbuf,strlen(errbuf)+strlen(err)+1);
	strcat(errbuf,err);
	newtWinMessage(_("modprobe error"), _("Ok"), errbuf);
	free(errbuf);
	free(err);
	return -1;
    }
    

    if (set->flags & NEEDS_SOX) {
	rc = RunCmd("/usr/bin/play",playargs,&out,&err);
	newtResume();
	if (rc) {
	    errbuf = strdup(_("The following error occurred "
			    "playing the sample:\n\n"));
	    errbuf = realloc(errbuf,strlen(errbuf)+strlen(err)+1);
	    strcat(errbuf,err);
	    newtWinMessage(_("Unable To Play Audio"), _("Ok"), errbuf);
	    free(errbuf);
	    free(err);
	    return -1;
	}
	free(err);
    } else {
	newtResume();
	fd = open("/usr/share/sndconfig/sample.au", O_RDONLY);
	if (fd < 0) {
	    newtWinMessage(_("Sample Not Found"), _("Ok"),
			   _("The sound sample does not appear to be installed."));
	    return -1;
	}
	od = open("/dev/audio", O_WRONLY);
	if (od < 0) {
	    newtWinMessage(_("Unable To Play Audio"),_("Ok"),
			   _("An error occurred opening /dev/audio"));
	    return -1;
	}
	
	while(1) {
	    rc=read(fd, buf, sizeof(buf));
	    if (!rc)
	      break;
	    write(od, buf, rc);
	}
	
	close(fd);
	close(od);
    }
    
    cleanupmods(set);

    rc = newtWinChoice(_("Test Result"), _("Yes"), _("No"),
		       _("Were you able to hear the sample?"));

    if (rc == 2) /* User said No */
	return -1;
    return rc;
}

int main(int argc, char **argv) {
    int pnpprobe;
    int rc;
    int success=0;
    char *id, *ansistr;
    enum cards type=UNSPEC;
    struct settings set, tmpset;
    int noprobe = 0,autoconfig=1;

    setlocale(LC_ALL, "");
    bindtextdomain("sndconfig","/usr/share/locale");
    textdomain("sndconfig");

#ifndef DEBUG
    /* make sure we should even be running */
    if (getuid()) {
        fprintf(stderr,_("\nERROR - You must be root to run sndconfig.\n"));
        exit(1);
    }
#endif

#ifdef USE_PNP
    if (argc > 1) {
	if (!strcmp(argv[1], "--help")) {
	    fprintf(stderr,_("Usage: sndconfig [--help] [--noprobe] [--autoconfig]\n"
		  "     --noprobe    do not probe for PnP sound cards.\n"
    		  "     --noautoconfig do not autoconfigure any probed PnP sound cards.\n\n"));
	    return 0;
	}
        else if (!strcmp(argv[1], "--noprobe")) {
	  noprobe = 1;
	  autoconfig = 0;
	} else if (!strcmp(argv[1], "--noautoconfig")) {
	    autoconfig = 0;
	}
    }
    if (argc > 2) {
	if (!strcmp(argv[2], "--noprobe")) {
	    noprobe = 1;
	    autoconfig = 0;
	}
	else if (!strcmp(argv[2], "--noautoconfig")) {
	    autoconfig = 0;
	}
    }
#else
    if (argc > 1) {
	if (!strcmp(argv[1], "--help")) {
	    fprintf(stderr,_("Usage: sndconfig [--help]\n\n"));
	    return 0;
	}
    }
    autoconfig = 0;
    noprobe = 1;
    pnpprobe = 0;
#endif 
    
    NewtStartUp();

    /* read in old soundcard settings */
    rc = ReadOldCardSettings( &tmpset );
    
    if (rc) 
	memset(&tmpset, 0, sizeof(struct settings));
    else
      type = tmpset.type;
      
    newtWinMessage(_("Introduction"), _("Ok"),
		   _("sndconfig is a configuration tool for "
		   "sound cards.\n\n%s%s\n\n"
		   "Report bugs to sound-list@redhat.com")
#ifdef USE_PNP
		   ,(noprobe) ? _("The automatic probing for PnP cards has "
	                       "been DISABLED") :
	                       _("A probe will now be performed for any PnP "
	                       "cards"),
		   (autoconfig) ? _(" that can be automatically "
		   "configured.") : "."
#else
		   ,"",""
#endif
		   );

#ifdef __i386__
    if (!FindModule("soundcore.o")) {
	newtWinMessage(_("ERROR: No Sound Modules found"), _("Ok"),
		       _("You don't seem to be running a kernel with modular "
		       "sound enabled. (soundcore.o was not found in the module "
		       "search path).\nTo use sndconfig, you must be running "
		       "a kernel with the new modular sound, such as the "
     		       "kernel shipped with Red Hat Linux or a 2.1.x "
		       "kernel, and sound must be compiled as a module. "
		       "Patches for the 2.0.3x series of kernels are "
		       "available at:\n\n"
		       "ftp://ftp.redhat.com/pub/sound/patches-current/"));
        newtFinished();
	return -1;
    }
#endif

#ifdef USE_PNP
    if (!noprobe)
	pnpprobe = !FindPnPCard(&id, &ansistr);
    else
	pnpprobe = 0;
    if (pnpprobe) {
	newtWinMessage(_("PnP Probe Results"), _("Ok"), _("A PnP "
		       "sound card was found in your system. The details "
		       "are:\n\n     Model: %s"), ansistr);
	/* figure out type - real scientifc here */
	if (strstr(id,"CTL")) {
	    if (strstr(ansistr, "16"))
	      type=SB16;
	    else if (strstr(ansistr, "32"))
	      type=SB32;
	    else if (strstr(ansistr, "64"))
	      type=SB32;
	    else
	      type=SB16;
	} else if (strstr(id,"GRV")) {
	    type=GUSPNP;
	} else if (strstr(id,"CSC")) {
#if 0   /* Wavefront don't work yet */
	    if (strstr(ansistr, "Turtle")||strstr(ansistr,"TBS"))
 	      type=WAVEFRONT;
 	    else
#endif
	      type=CS4232;
	} else if (strstr(id,"TER")) {
	    type=AD1816;
	} else if (strstr(id,"OPT")) {
	    if (strstr(ansistr, "931")) {
		type=MAD16PRO;
	    } else if (strstr(ansistr, "925")) {
		type=MOZART;
	    } else {
		type=MOZART; /* definitely maybe... */
	    }
	} else if (strstr(id,"AZT")) {
	    type=SGALAXY;
	} else if (strstr(id,"ENS")) {
		if (strstr(ansistr, "VIVO"))
		  type=SSVIVO;
		else
		  type=SOUNDSCAPE;
	} else if (strstr(id,"ESS")) {
	    type=ESS1868;
	} else if (strstr(id,"YMH")) {
	    type=OPL3_SAX;
	} else if (strstr(id,"CMI")) {
	    type=CMI8330;
	} else {
	    newtWinMessage(_("Probe Error"), _("Ok"),
			   _("A PnP card has been detected, but the model "
			   "identifier is unclear. You will need to select "
			   "the exact model from the next screen."));
	    type=SB16;
	}
    } else {
	pnpprobe = !FindPCICard(&ansistr);
	if (pnpprobe) {
	    newtWinMessage(_("PCI Probe Results"), _("Ok"), _("A PCI "
		       "sound card was found in your system. The details "
		       "are:\n\n     Model: %s"), ansistr);
	    if (strstr(ansistr,"ES1370")) {
		type=ES1370;
	    } else if (strstr(ansistr,"ES1371")) {
		type=ES1371;
	    } else if (strstr(ansistr,"AudioPCI")) {
		type=ES1370;
	    } else if (strstr(ansistr,"SonicVibes")) {
		type=SONICVIBES;
	    } else {
		type=UNSPEC;
		pnpprobe = 0;
		autoconfig = 0;
	    }
	} else {
	    autoconfig = 0;
	}
    }
#endif
    
    rc = 1;
    while (rc) {
	if (pnpprobe && !noprobe && autoconfig) {
	    set = cards[type];
	    memcpy(&tmpset,&set, sizeof(struct settings));
	    rc = 0;
	} else {
	    if (!noprobe && !pnpprobe)
	      newtWinMessage(_("Probe Results"), _("Ok"),
			   _("No PnP or PCI sound cards were found in "
			     "your system. Please select your card type "
			     "from the following list."));
	    rc = GetCardType( &type );
	    if (rc) {
		newtFinished();
		exit(1);
	    }
	    set = cards[type];
	    if (set.type != type)
	      pnpprobe = 0;
	    if (tmpset.type != set.type) {
		memcpy(&tmpset,&set, sizeof(struct settings));
		if (set.flags & NO_INPUT_REQ) {
		    tmpset.irq[0] = -1;
		    tmpset.dma[0] = -1;
		    tmpset.dma2[0] = -1;
		    tmpset.mpu_io[0] = -1;
		    tmpset.mpu_irq[0] = -1;
		    tmpset.mem[0] = -1;
		}
	    }
	}
	if (set.messageno) {
	    newtWinMessage(_("Card Information"),_("Ok"),strdup(messages[set.messageno]));
	}
	if (!(set.flags & NO_INPUT_REQ))
	  if (!autoconfig)
	    rc = EditSettings( 0, &set, &tmpset);
	if (!rc) {
	    WriteCardSettings(&tmpset);
#ifdef USE_PNP
	    if (pnpprobe && !noprobe && !(tmpset.flags & NO_INPUT_REQ))
	      WriteISAPnPConf(&tmpset,id,autoconfig);
#endif
	    WriteConfModules(&tmpset);
	    sync();
	    if (set.type != ADLIB)
	      rc = TestSndCard(pnpprobe && !noprobe,&tmpset);
	    if (rc < 0) {
	      /* If we're in autoconfig, we'll get stuck in a loop if
	       * the sound test fails...
	       */
	      if (autoconfig && pnpprobe) {
		  newtWinMessage(_("Autoconfiguration failed!"),_("Ok"),
				 _("Autoconfiguration of your sound card "
				   "failed. Now proceeding with manual "
				   "configuration."));
		  autoconfig = 0;
		  continue;
	      }
	      cleanupmods(&tmpset);
	      continue;
	    }
	    else {
		success = 1;
		break;
	    }
	}
    }

    newtFinished();

    cleanupmods(&tmpset);
    if (success) {
	sleep(1);
	startsound(&tmpset);
    }
    return 0;
}

