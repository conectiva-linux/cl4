
/* 16 bits */
/* Enable response in I/O space */
/* Enable response in Memory space */
/* Enable bus mastering */
/* Enable response to special cycles */
/* Use memory write and invalidate */
/* Enable palette snooping */
/* Enable parity checking */
/* Enable address/data stepping */
/* Enable SERR */
/* Enable back-to-back writes */
/* 16 bits */
/* Support 66 Mhz PCI 2.1 bus */
/* Support User Definable Features */
/* Accept fast-back to back */
/* Detected parity error */
/* DEVSEL timing */

/* Set on target abort */
/* Master ack of " */
/* Set on master abort */
/* Set when we drive SERR */
/* Set on parity error */
/* High 24 bits are class, low 8
#define PCI_REVISION_ID         0x08    /* Revision ID */
/* Reg. Level Programming Interface */
/* Device class */
/* 8 bits */
/* Return result */
/* 1 to start BIST, 2 secs or less */
/* 1 if BIST capable */
/* 32 bits */
/* 0 = memory, 1 = I/O */

/* 32 bit address */
/* Below 1M */
/* 64 bit address */
/* prefetchable? */

/* 32 bits */
/* Write 1 to enable ROM,
#define PCI_INTERRUPT_LINE	0x3c	/* 8 bits */
/* 8 bits */

/* This is an automatically generated file by makepciids. */

/* some PCI ids map to multiple modules (!!) */
/* we just stick in an mulitple entries for the PCI id, with different */
/* module name for each one. Code just search for ALL matches to a     */
/* given PCI id to get all the modules that might(!) work              */
struct pci_module_map {
	unsigned short	vendor;     /* PCI vendor id */
	unsigned short	device;     /* PCI device id */
	const char      *name;      /* PCI human readable name */
	const char      *module;    /* module to load */
};

struct pci_module_map scsi_pci_ids[] = {
	{0x9004  , 0x5078  , ( 	"AIC-7850" ), ( "aic7xxx" )} ,
	{0x9004  , 0x5578  , ( 	"AIC-7855" ), ( "aic7xxx" )} ,
	{0x9004  , 0x6078  , ( 	"AIC-7860" ), ( "aic7xxx" )} ,
	{0x9004  , 0x6178  , ( 	"AIC-7861" ), ( "aic7xxx" )} ,
	{0x9004  , 0x7078  , ( 	"AIC-7870" ), ( "aic7xxx" )} ,
	{0x9004  , 0x7178  , ( 	"AIC-7871" ), ( "aic7xxx" )} ,
	{0x9004  , 0x7278  , ( 	"AIC-7872" ), ( "aic7xxx" )} ,
	{0x9004  , 0x7378  , ( 	"AIC-7873" ), ( "aic7xxx" )} ,
	{0x9004  , 0x7478  , ( 	"AIC-7874" ), ( "aic7xxx" )} ,
	{0x9004  , 0x8078  , ( 	"AIC-7880U" ), ( "aic7xxx" )} ,
	{0x9004  , 0x8178  , ( 	"AIC-7881U" ), ( "aic7xxx" )} ,
	{0x9004  , 0x8278  , ( 	"AIC-7882U" ), ( "aic7xxx" )} ,
	{0x9004  , 0x8378  , ( 	"AIC-7883U" ), ( "aic7xxx" )} ,
	{0x9004  , 0x8478  , ( 	"AIC-7884U" ), ( "aic7xxx" )} ,
        {0x9005  , 0x0010  , ( "AHA-2940U2" ), ( "aic7xxx" )} ,
        {0x9005  , 0x0050  , ( "AHA-3940U2" ), ( "aic7xxx" )} ,
        {0x9005  , 0x001f  , (   "AIC-7890/1" ), ( "aic7xxx" )} ,
        {0x9005  , 0x005f  , (   "AIC-7896/7" ), ( "aic7xxx" )} ,
	{0x10cd  , 0x1200  , ( 	"ABP940" ), ( "advansys" )} ,
	{0x10cd  , 0x1300  , ( 	"ABP940U" ), ( "advansys" )} ,
	{0x104B  , 0x8130  , (      "FlashPoint" ), ( "BusLogic" )} ,
	{0x104B  , 0x1040  , (     "MultiMaster" ), ( "BusLogic" )} ,
	{0x104B  , 0x0140  , (  "MultiMaster NC" ), ( "BusLogic" )} ,
	{0x1044  , 0xa400  , ( 		"SmartCache/Raid" ), ( "dpt" )} ,
	{0x1000  , 0x0001  , ( 	"53c810" ), ( "ncr53c8xx" )} ,
	{0x1000  , 0x0004  , ( 	"53c815" ), ( "ncr53c8xx" )} ,
	{0x1000  , 0x0002  , ( 	"53c820" ), ( "ncr53c8xx" )} ,
	{0x1000  , 0x0003  , ( 	"53c825" ), ( "ncr53c8xx" )} ,
	{0x1000  , 0x0006  , ( 	"53c860" ), ( "ncr53c8xx" )} ,
	{0x1000  , 0x000f  , ( 	"53c875" ), ( "ncr53c8xx" )} ,
	{0x1000  , 0x000d  , ( 	"53c885" ), ( "ncr53c8xx" )} ,
	{0x1000  , 0x000c  , ( 	"53c895" ), ( "ncr53c8xx" )} ,
	{0x1000  , 0x000b  , ( 	"53c896" ), ( "ncr53c8xx" )} ,
	{0x1077  , 0x1020  , ( 	"ISP1020" ), ( "qlogicisp" )} ,
	{0x1077  , 0x1022  , ( 	"ISP1022" ), ( "qlogicisp" )} ,
	{0x9004  , 0x5800  , ( 	"AIC-5800" ), ( "UNKNOWN" )} ,
	{0x9004  , 0x1078  , ( 	"AIC-7810 RAID" ), ( "UNKNOWN" )} ,
	{0x9004  , 0x7895  , ( 	"AIC-7895U" ), ( "aic7xxx" )} ,
	{0x10cd  , 0x2300  , ( 	"ABP940UW" ), ( "advansys" )} ,
	{0x1000  , 0x008f  , ( 	"53c875J" ), ( "ncr53c8xx" )} ,
	{0x1119  , 0x0112  , ( "GDT 6537RP1" ), ( "gdth" )} ,
	{0x1119  , 0x0122  , ( "GDT 6537RP2" ), ( "gdth" )} ,
	{0x1119  , 0x0102  , ( "GDT 6537RP" ), ( "gdth" )} ,
	{0x1119  , 0x0113  , ( "GDT 6557RP1" ), ( "gdth" )} ,
	{0x1119  , 0x0123  , ( "GDT 6557RP2" ), ( "gdth" )} ,
	{0x1119  , 0x0103  , ( "GDT 6557RP" ), ( "gdth" )} ,
	{0x1119  , 0x0114  , ( "GDT 6111RP1/6511RP1" ), ( "gdth" )} ,
	{0x1119  , 0x0124  , ( "GDT 6111RP2/6511RP2" ), ( "gdth" )} ,
	{0x1119  , 0x0104  , ( "GDT 6111RP/6511RP" ), ( "gdth" )} ,
	{0x1119  , 0x0110  , ( "GDT 6117RP1/6517RP1" ), ( "gdth" )} ,
	{0x1119  , 0x0120  , ( "GDT 6117RP2/6517RP2" ), ( "gdth" )} ,
	{0x1119  , 0x0100  , ( "GDT 6117RP/6517RP" ), ( "gdth" )} ,
	{0x1119  , 0x0115  , ( "GDT 6121RP1/6521RP1" ), ( "gdth" )} ,
	{0x1119  , 0x0125  , ( "GDT 6121RP2/6521RP2" ), ( "gdth" )} ,
	{0x1119  , 0x0105  , ( "GDT 6121RP/6521RP" ), ( "gdth" )} ,
	{0x1119  , 0x0111  , ( "GDT 6127RP1/6527RP1" ), ( "gdth" )} ,
	{0x1119  , 0x0121  , ( "GDT 6127RP2/6527RP2" ), ( "gdth" )} ,
	{0x1119  , 0x0101  , ( "GDT 6127RP/6527RP" ), ( "gdth" )} ,
};
int scsi_num_ids=sizeof(scsi_pci_ids)/sizeof(struct pci_module_map);

struct pci_module_map eth_pci_ids[] = {
	{0x10b7  , 0x5900  , ( 	"3C590 10bT" ), ( "3c59x" )} ,
	{0x10b7  , 0x5952  , ( 	"3C595 100b-MII" ), ( "3c59x" )} ,
	{0x10b7  , 0x5951  , ( 	"3C595 100bT4" ), ( "3c59x" )} ,
	{0x10b7  , 0x5950  , ( 	"3C595 100bTX" ), ( "3c59x" )} ,
	{0x10b7  , 0x9001  , ( "3C900 10b Combo" ), ( "3c59x" )} ,
	{0x10b7  , 0x9000  , ( 	"3C900 10bTPO" ), ( "3c59x" )} ,
	{0x10b7  , 0x9055  , ( 	"3C905B 100bTX" ), ( "3c59x" )} ,
	{0x10b7  , 0x9051  , ( 	"3C905 100bT4" ), ( "3c59x" )} ,
	{0x10b7  , 0x9050  , ( 	"3C905 100bTX" ), ( "3c59x" )} ,
	{0x1022  , 0x2000  , ( 	"79C970" ), ( "pcnet32" )} ,
	{0x1011  , 0x0021  , ( 	"DC21052" ), ( "tulip" )} ,
	{0x1011  , 0x0019  , ( 	"DC21142" ), ( "tulip" )} ,
	{0x1011  , 0x0022  , ( 	"DC21150" ), ( "tulip" )} ,
	{0x1011  , 0x0024  , ( 	"DC21152" ), ( "tulip" )} ,
	{0x1011  , 0x000F  , ( 	"DEFPA" ), ( "unknown" )} ,
	{0x1011  , 0x0002  , ( 	"DC21040" ), ( "tulip" )} ,
	{0x1011  , 0x0009  , ( 	"DC21140" ), ( "tulip" )} ,
	{0x1011  , 0x0014  , ( 	"DC21041" ), ( "tulip" )} ,
	{0x103c  , 0x1030  , ( 	"J2585A" ), ( "hp100" )} ,
	{0x103c  , 0x1031  , ( 	"J2585B (Lassen)" ), ( "hp100" )} ,
	{0x1014  , 0x0018  , ( 		"Token Ring" ), ( "tr" )} ,
	{0x8086  , 0x1229  , ( 	"82557" ), ( "eepro100" )} ,
	{0x11ad  , 0x0002  , ( "LNE100TX" ), ( "tulip" )} ,
	{0x1050  , 0x0940  , ( "NE2000-PCI" ), ( "ne" )} ,
};
int eth_num_ids=sizeof(eth_pci_ids)/sizeof(struct pci_module_map);

struct pci_module_map video_pci_ids[] = {
	{0x121a  , 0x0001  , ( 	"Voodoo" ), ( "UNKNOWN" )} ,
	{0x3d3d  , 0x0001  , ( 	"GLINT 300SX" ), ( "UNKNOWN" )} ,
	{0x3d3d  , 0x0003  , ( 	"GLINT Delta" ), ( "UNKNOWN" )} ,
	{0x3d3d  , 0x0004  , ( "PERMEDIA" ), ( "UNKNOWN" )} ,
	{0xedd8  , 0xa0a1  , ( 	"2000MT" ), ( "Card:Ark Logic ARK2000MT (generic)" )} ,
	{0xedd8  , 0xa091  , ( 	"Stingray" ), ( "UNKNOWN" )} ,
	{0xedd8  , 0xa099  , ( 	"Stingray ARK 2000PV" ), ( "Card:Ark Logic ARK2000MT (generic)" )} ,
	{0x1002  , 0x4358  , (    "210888CX" ), ( "Server:Mach64" )} ,
	{0x1002  , 0x4758  , (    "210888GX" ), ( "Server:Mach64" )} ,
	{0x1002  , 0x4354  , (    "215CT222" ), ( "Card:ATI Mach64" )} ,
	{0x1002  , 0x4754  , ( 	"Mach64 GT (Rage II)" ), ( "Card:ATI Mach64 3D RAGE II, Internal RAMDAC" )} ,
	{0x1002  , 0x5654  , ( 	"Mach64 VT" ), ( "Card:ATI Mach64 VT (264VT), Internal RAMDAC" )} ,
	{0x1002  , 0x4158  , (       "68800AX" ), ( "UNKNOWN" )} ,
	{0x4005  , 0x2064  , ( 	"ALG2064i" ), ( "UNKNOWN" )} ,
	{0x1013  , 0x00a0  , ( 	"GD 5430" ), ( "Card:Cirrus Logic GD543x" )} ,
	{0x1013  , 0x00a4  , ( 	"GD 5434" ), ( "Card:Cirrus Logic GD543x" )} ,
	{0x1013  , 0x00a8  , ( 	"GD 5434" ), ( "Card:Cirrus Logic GD543x" )} ,
	{0x1013  , 0x00ac  , ( 	"GD 5436" ), ( "Card:Cirrus Logic GD543x" )} ,
	{0x1013  , 0x00b8  , ( 	"GD 5446" ), ( "Card:Cirrus Logic GD544x" )} ,
	{0x1013  , 0x00d4  , ( 	"GD 5464" ), ( "Card:Cirrus Logic GD5464" )} ,
	{0x1013  , 0x00d6  , ( 	"GD 5465" ), ( "Card:Cirrus Logic GD5465" )} ,
	{0x1013  , 0x00bc  , ( 	"GD 5480" ), ( "Card:Cirrus Logic GD5480" )} ,
	{0x1013  , 0x1100  , ( 	"CL 6729" ), ( "Card:Cirrus Logic GD6729" )} ,
	{0x1013  , 0x1110  , ( 	"PD 6832" ), ( "UNKNOWN" )} ,
	{0x1013  , 0x1204  , ( 	"CL 7541" ), ( "Card:Cirrus Logic GD754x (laptop)" )} ,
	{0x1013  , 0x1200  , ( 	"CL 7542" ), ( "Card:Cirrus Logic GD754x (laptop)" )} ,
	{0x1013  , 0x1202  , ( 	"CL 7543" ), ( "Card:Cirrus Logic GD754x (laptop)" )} ,
	{0x1013  , 0x0038  , ( 	"GD 7548" ), ( "Card:Cirrus Logic GD754x (laptop)" )} ,
	{0x0e11  , 0x3033  , ( 	"QVision 1280/p" ), ( "UNKNOWN" )} ,
	{0x102c  , 0x00d8  , ( 	"65545" ), ( "Card:Chips & Technologies CT65545" )} ,
	{0x102c  , 0x00dc  , ( 	"65548" ), ( "Card:Chips & Technologies CT65548" )} ,
	{0x102c  , 0x00e0  , ( 	"65550" ), ( "Card:Chips & Technologies CT65550" )} ,
	{0x102c  , 0x00e4  , ( 	"65554" ), ( "Card:Chips & Technologies CT65554" )} ,
	{0x1011  , 0x0004  , ( 	"DC21030" ), ( "Server:TGA" )} ,
	{0x107d  , 0x0000  , ( 	"S3 805" ), ( "UNKNOWN" )} ,
	{0x102B  , 0x0518  , ( 	"Atlas PX2085" ), ( "UNKNOWN" )} ,
	{0x102B  , 0x0d10  , ( 	"MGA Impression" ), ( "Server:SVGA" )} ,
	{0x102B  , 0x0519  , ( 	"Millennium" ), ( "Card:Matrox Millennium (MGA)" )} ,
	{0x102B  , 0x051b  , ( 	"Millennium II" ), ( "Card:Matrox Millennium II" )} ,
	{0x102B  , 0x051A  , ( 	"Mystique" ), ( "Card:Matrox Mystique" )} ,
	{0x105d  , 0x2309  , ( 	"Imagine 128" ), ( "Card:Number Nine Imagine I-128 (2-8MB)" )} ,
	{0x105d  , 0x2339  , ( 	"Imagine 128v2" ), ( "Card:Number Nine Imagine I-128 Series 2 (2-4MB)" )} ,
	{0x10c8  , 0x0001  , (  "MagicGraph NM2070" ), ( "Card:NeoMagic (laptop/notebook)" )} ,
	{0x10c8  , 0x0002  , (  "MagicGraph 128V" ), ( "Card:NeoMagic (laptop/notebook)" )} ,
	{0x10c8  , 0x0003  , (  "MagicGraph 128ZV" ), ( "Card:NeoMagic (laptop/notebook)" )} ,
	{0x10c8  , 0x0083  , (  "MagicGraph 128ZV+" ), ( "Card:NeoMagic (laptop/notebook)" )} ,
	{0x10c8  , 0x0004  , (  "MagicGraph NM2160" ), ( "Card:NeoMagic (laptop/notebook)" )} ,
	{0x10c8  , 0x0001  , (  "MagicGraph NM2070" ), ( "Card:NeoMagic (laptop/notebook)" )} ,
	{0x10c8  , 0x0005  , (  "MagicMedia 256AV" ), ( "UNKNOWN" )} ,
	{0x104e  , 0x0107  , ( 	"OTI107" ), ( "UNKNOWN" )} ,
	{0x1255  , 0x1110  , ( 	"MPEG Forge" ), ( "UNKNOWN" )} ,
	{0x1255  , 0x1210  , ( "MPEG Fusion" ), ( "UNKNOWN" )} ,
	{0x1255  , 0x2110  , ( 	"VideoPlex" ), ( "UNKNOWN" )} ,
	{0x1255  , 0x2120  , ( "VideoPlex CC" ), ( "UNKNOWN" )} ,
	{0x1255  , 0x2130  , ( "VideoQuest" ), ( "UNKNOWN" )} ,
	{0x5333  , 0x88c0  , ( 	"Vision 864-P" ), ( "Card:S3 864 (generic)" )} ,
	{0x5333  , 0x88c1  , ( 	"Vision 864-P" ), ( "Card:S3 864 (generic)" )} ,
	{0x5333  , 0x8880  , ( 	"Vision 868" ), ( "Card:S3 868 (generic)" )} ,
	{0x5333  , 0x88b0  , ( 		"Vision 928-P" ), ( "Card:S3 928 (generic)" )} ,
	{0x5333  , 0x88d0  , ( 	"Vision 964-P" ), ( "Card:S3 964 (generic)" )} ,
	{0x5333  , 0x88d1  , ( 	"Vision 964-P" ), ( "Card:S3 964 (generic)" )} ,
	{0x5333  , 0x88f0  , ( 		"Vision 968" ), ( "Card:S3 968 (generic)" )} ,
	{0x5333  , 0x8812  , ( 	"Aurora64V+" ), ( "UNKNOWN" )} ,
	{0x5333  , 0x8902  , ( 	"PLATO/PX (graphics)" ), ( "UNKNOWN" )} ,
	{0x5333  , 0x0551  , ( 	"PLATO/PX (system)" ), ( "UNKNOWN" )} ,
	{0x5333  , 0x8811  , ( 	"Trio32/Trio64" ), ( "Card:S3 Trio64 (generic)" )} ,
	{0x5333  , 0x8814  , ( 	"Trio64UV+" ), ( "Card:S3 Trio64V+ (generic)" )} ,
	{0x5333  , 0x8901  , ( 	"Trio64V2/DX or /GX" ), ( "Card:S3 Trio64V2 (generic)" )} ,
	{0x5333  , 0x5631  , ( 	"ViRGE" ), ( "Card:S3 ViRGE (generic)" )} ,
	{0x5333  , 0x8a01  , ( 	"ViRGE/DX or /GX" ), ( "Card:S3 ViRGE (generic)" )} ,
	{0x5333  , 0x883d  , ( 	"ViRGE/VX" ), ( "Card:S3 ViRGE (generic)" )} ,
	{0x5333  , 0x8a10  , ( 	"ViRGE/GX2" ), ( "Card:S3 ViRGE/GX2 (generic)" )} ,
	{0x10a8  , 0x0000  , ( 	"STB Horizon 64" ), ( "Server:SVGA" )} ,
	{0x1de1  , 0xdc29  , ( 	"DC-290" ), ( "UNKNOWN" )} ,
	{0x1023  , 0x9420  , ( 	"TG 9420" ), ( "Card:Trident TGUI9420DGi (generic)" )} ,
	{0x1023  , 0x9440  , ( 	"TG 9440" ), ( "Card:Trident TGUI9440 (generic)" )} ,
	{0x1023  , 0x9660  , ( 	"TG 9660" ), ( "Card:Trident TGUI9660 (generic)" )} ,
	{0x100c  , 0x3208  , ( 	"ET6000" ), ( "Card:ET6000 (generic)" )} ,
	{0x100c  , 0x3202  , ( 	"ET4000W32P" ), ( "Card:ET4000 W32i, W32p (generic)" )} ,
	{0x100c  , 0x3205  , ( 	"ET4000W32P rev B" ), ( "Card:ET4000 W32i, W32p (generic)" )} ,
	{0x100c  , 0x3206  , ( 	"ET4000W32P rev C" ), ( "Card:ET4000 W32i, W32p (generic)" )} ,
	{0x100c  , 0x3207  , ( 	"ET4000W32P rev D" ), ( "Card:ET4000 W32i, W32p (generic)" )} ,
	{0x100e  , 0x9001  , ( 	"P9000" ), ( "Server:P9000" )} ,
	{0x100e  , 0x9100  , ( 	"P9100" ), ( "Server:P9000" )} ,
	{0x1002  , 0x4742  , ( 	"Mach64 GB" ), ( "Server:Mach64" )} ,
	{0x1002  , 0x4744  , ( 	"Mach64 GD (Rage Pro)" ), ( "Server:Mach64" )} ,
	{0x1002  , 0x4749  , ( 	"Mach64 GI (Rage Pro)" ), ( "Server:Mach64" )} ,
	{0x1002  , 0x4750  , ( 	"Mach64 GP (Rage Pro)" ), ( "Server:Mach64" )} ,
	{0x1002  , 0x4751  , ( 	"Mach64 GQ (Rage Pro)" ), ( "Server:Mach64" )} ,
	{0x1002  , 0x4755  , ( 	"Mach64 GT (Rage II)" ), ( "Card:ATI Mach64 3D RAGE II, Internal RAMDAC" )} ,
	{0x1002  , 0x4c47  , ( 	"Mach64 LG (3D Rage LT)" ), ( "Server:Mach64" )} ,
	{0x1002  , 0x4c54  , ( 	"Mach64 LT" ), ( "Server:Mach64" )} ,
	{0x102c  , 0x00e5  , ( 	"65555" ), ( "Card:Chips & Technologies CT65555" )} ,
	{0x1011  , 0x0004  , ( 	"DC21030" ), ( "Server:TGA" )} ,
	{0x1011  , 0x0004  , ( 	"DC21030 (TGA)" ), ( "Server:TGA" )} ,
	{0x102B  , 0x051f  , ( "Millennium II AGP" ), ( "Card:Matrox Millennium II AGP" )} ,
	{0x12d2  , 0x0018  , ( 	"Riva 128" ), ( "Server:SVGA" )} ,
	{0x5333  , 0x8c01  , ( 	"ViRGE/MX" ), ( "Card:S3 ViRGE/MX (generic)" )} ,
	{0x5333  , 0x8c02  , ( 	"ViRGE/MX+" ), ( "Card:S3 ViRGE/MX (generic)" )} ,
	{0x5333  , 0x8c03  , ( 	"ViRGE/MX+MV" ), ( "Card:S3 ViRGE/MX (generic)" )} ,
	{0x1023  , 0x9397  , ( 	"Cyber9397" ), ( "Server:SVGA" )} ,
	{0x1023  , 0x9660  , ( 	"TG 9660" ), ( "Card:Trident TGUI9660 (generic)" )} ,
	{0x1023  , 0x9660  , ( 	"TG 9660 / Cyber9385" ), ( "Server:SVGA" )} ,
	{0x1023  , 0x9750  , ( 	"Image 975" ), ( "UNKNOWN" )} ,
        {0x104c  , 0x3d04  , (      "TVP4010 Permedia" ), ( "UNKNOWN" )} ,
        {0x104c  , 0x3d07  , (      "TVP4020 Permedia 2" ), ( "Server:3DLabs" )} ,
        {0x3d3d  , 0x0006  , (       "GLINT MX" ), ( "Server:3DLabs" )} 
};
int video_num_ids=sizeof(video_pci_ids)/sizeof(struct pci_module_map);

struct pci_module_map audio_pci_ids[] = {
	{0x1274  , 0x5000  , ( 	"AudioPCI" ), ( "es1370" )} ,
	{0x1274  , 0x1371  , ( 	"ES1371" ), ( "es1371" )} ,
	{0x5333  , 0xca00  , ( 	"SonicVibes" ), ( "sonicvibes" )} ,
};
int audio_num_ids=sizeof(audio_pci_ids)/sizeof(struct pci_module_map);

/* END of automatically generated text */
