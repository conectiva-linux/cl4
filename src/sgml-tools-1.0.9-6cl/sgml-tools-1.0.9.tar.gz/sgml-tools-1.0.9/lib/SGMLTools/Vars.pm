#
#  Vars.pm
#
#  $Id: Vars.pm,v 1.1 1997/09/11 22:27:17 cg Exp $
#
#  Shared variables.
#
#  � Copyright 1996, 1997, Cees de Groot
#
package SGMLTools::Vars;
use strict;

use Exporter;

use vars qw($VERSION @ISA @EXPORT);
@ISA = qw(Exporter);
@EXPORT = qw(%Formats $global %FmtList);
$VERSION = sprintf("%d.%02d", q$Revision: 1.1 $ =~ /(\d+)\.(\d+)/);

use vars @EXPORT;

1;
