// Copyright (c) 1996 James Clark
// See the file COPYING for copying permission.

// This file must be included first by all files in lib.

#define BUILD_LIBSP
#include "config.h"
#ifdef SP_PCH
#include "splibpch.h"
#endif /* SP_PCH */
