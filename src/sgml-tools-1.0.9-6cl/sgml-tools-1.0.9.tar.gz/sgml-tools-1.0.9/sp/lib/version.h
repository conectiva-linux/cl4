#define SP_VERSION SP_T("1.2.1")
