#
# $Id: test-entitymap.pl,v 1.3 1997/09/13 20:37:46 cg Exp $
#

use Text::EntityMap;

@files = split (/\s/, `echo sdata/*`);
foreach $ii (@files) {
    print "---- $ii ----\n";

    $map = Text::EntityMap->load ($ii);
    open (FILE, $ii)
	|| die "opening \`$ii': $!\n";
    while (<FILE>) {
	chop;
	m/(^[^\t]+)\t(.*)/;
	($key, $value) = ($1, $2);

	if ($map->lookup ($key) ne $value) {
	    warn "$ii:$key: expected \`$value'\n";
	}
    }
}
