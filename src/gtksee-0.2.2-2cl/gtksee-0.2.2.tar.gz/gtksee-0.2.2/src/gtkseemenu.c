/*
 * GTK See -- a image viewer based on GTK+
 * Copyright (C) 1998 Hotaru Lee <jkhotaru@mail.sti.com.cn> <hotaru@163.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "gtypes.h"
#include "common_tools.h"
#include "gtkseemenu.h"

static GtkWidget *thumbnails_item, *small_icons_item, *details_item;

GtkWidget*
get_main_menu(GtkWidget *window)
{
	GtkWidget *menubar, *menu, *menu_item;
	GSList *group;
	
	menubar = gtk_menu_bar_new();
	gtk_widget_show(menubar);
	
	/* File menu */
	menu = gtk_menu_new();
	
	menu_item = gtk_menu_item_new_with_label("View");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_file_view), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new();
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_widget_show(menu_item);

	menu_item = gtk_menu_item_new_with_label("Quit");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_file_quit), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("File");
	gtk_widget_show(menu_item);
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menu_item), menu);
	gtk_menu_bar_append(GTK_MENU_BAR(menubar), menu_item);
	
	/* View menu */
	menu = gtk_menu_new();
	
	thumbnails_item = gtk_radio_menu_item_new_with_label(NULL, "Thumbnails");
	group = gtk_radio_menu_item_group(GTK_RADIO_MENU_ITEM(thumbnails_item));
	gtk_signal_connect(GTK_OBJECT(thumbnails_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_thumbnails), NULL);
	gtk_menu_append(GTK_MENU(menu), thumbnails_item);
	gtk_widget_show(thumbnails_item);
	
	small_icons_item = gtk_radio_menu_item_new_with_label(group, "Small icons");
	group = gtk_radio_menu_item_group(GTK_RADIO_MENU_ITEM(small_icons_item));
	gtk_signal_connect(GTK_OBJECT(small_icons_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_small_icons), NULL);
	gtk_menu_append(GTK_MENU(menu), small_icons_item);
	gtk_widget_show(small_icons_item);
	
	details_item = gtk_radio_menu_item_new_with_label(group, "Details");
	group = gtk_radio_menu_item_group(GTK_RADIO_MENU_ITEM(details_item));
	gtk_signal_connect(GTK_OBJECT(details_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_details), NULL);
	gtk_menu_append(GTK_MENU(menu), details_item);
	gtk_widget_show(details_item);
	
	menu_item = gtk_menu_item_new();
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_widget_show(menu_item);

	menu_item = gtk_check_menu_item_new_with_label("Hide non-images");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_hide), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_check_menu_item_new_with_label("Fast preview");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_preview), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new();
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_widget_show(menu_item);

	menu_item = gtk_menu_item_new_with_label("Refresh");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_view_refresh), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("Quick-refresh");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_view_quick_refresh), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_check_menu_item_new_with_label("Auto-refresh");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "toggled",
		GTK_SIGNAL_FUNC(menu_view_auto_refresh), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("View");
	gtk_widget_show(menu_item);
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menu_item), menu);
	gtk_menu_bar_append(GTK_MENU_BAR(menubar), menu_item);
	
	/* Help menu */
	menu = gtk_menu_new();
	
	menu_item = gtk_menu_item_new_with_label("Legal");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_help_legal), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("Usage");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_help_usage), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("Known-bugs");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_help_known_bugs), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("Feedback");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_help_feedback), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new();
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_widget_show(menu_item);

	menu_item = gtk_menu_item_new_with_label("About");
	gtk_menu_append(GTK_MENU(menu), menu_item);
	gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
		GTK_SIGNAL_FUNC(menu_help_about), NULL);
	gtk_widget_show(menu_item);
	
	menu_item = gtk_menu_item_new_with_label("Help");
	gtk_widget_show(menu_item);
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menu_item), menu);
	gtk_menu_bar_append(GTK_MENU_BAR(menubar), menu_item);
	
	return menubar;
}

void
menu_set_list_type(ImageListType type)
{
	switch (type)
	{
	  case IMAGE_LIST_THUMBNAILS:
		gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(thumbnails_item), TRUE);
		break;
	  case IMAGE_LIST_SMALL_ICONS:
		gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(small_icons_item), TRUE);
		break;
	  case IMAGE_LIST_DETAILS:
	  default:
		gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(details_item), TRUE);
		break;
	}
}

void
menu_help_legal(GtkWidget *widget, gpointer data)
{
	static guint legal_sizes[] =
	{
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		0
	};
	static guchar *legal_text[] =
	{
		"    GTK See is free software; you can redistribute it and/or modify",
		" it under the terms of the GNU General Public License as published by",
		" the Free Software Foundation; either version 2 of the License, or",
		" (at your option) any later version.\n\n",
		"    GTK See is distributed in the hope that it will be useful,",
		" but WITHOUT ANY WARRANTY; without even the implied warranty of",
		" MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the",
		" GNU General Public License for more details.\n\n",
		"    You should have received a copy of the GNU General Public License",
		" along with this program; if not, write to the Free Software",
		" Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.\n",
		NULL
	};
	GtkWidget *dialog;
	
	dialog = info_dialog_new("Legal", legal_sizes, legal_text);
	gtk_widget_show(dialog);
}

void
menu_help_usage(GtkWidget *widget, gpointer data)
{
	static guint usage_sizes[] =
	{
		FONT_BIG,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_BIG,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_BIG,
		FONT_SMALL,
		FONT_BIG,
		0
	};
	static guchar *usage_text[] = {
		"Command-line usage:\n",
		"    gtksee [-R[directory]] [-fis] [files...]\n",
		"      -R  --  Use current directory as root\n",
		"      -R<directory>  --  Use <directory> as root\n",
		"      -f  --  Enable full-screen mode\n",
		"      -i  --  Enable fit-screen mode\n",
		"      -s  --  Enable slide-show mode\n",
		"      files... --  Launch gtksee viewer\n",
		"      -h  --  Print help messages\n\n",
		"Keyboard shortcuts:\n",
		"    These keys are bound to viewer:\n",
		"    [Arrow-keys] Move large image\n",
		"    [PageUp] Show previous image\n",
		"    [PageDown] Show next image\n",
		"    [Home] Show the first image\n",
		"    [End] Show the last image\n",
		"    [Space] Press focused button(default: next)\n",
		"    [Escape] Return to the browser\n",
		"    In full-screen mode, viewer cannot receive any key events. Use pop-up menu instead.\n\n",
		"Mouse hints:\n",
		"    In view mode, double-click on the image to return to the browser.\n\n",
		"Have fun!\n",
		NULL
	};
	GtkWidget *dialog;
	
	dialog = info_dialog_new("Usage", usage_sizes, usage_text);
	gtk_widget_show(dialog);
}

void
menu_help_known_bugs(GtkWidget *widget, gpointer data)
{
	static guint known_bugs_sizes[] = {
		FONT_BIG,
		FONT_SMALL,
		FONT_BIG,
		FONT_SMALL,
		0
	};
	static guchar *known_bugs_text[] = {
		"Resizing the browser:\n",
		"    You cannot shrink the window, because of the gtk_widget_set_usize()...\n\n",
		"Keys do not work for full-screen mode:\n",
		"    In full-screen mode, the window is an override-redirect window. Usually, it can't receive any key events from the window manager. I still don't know how to resolve this with GDK/GTK+...\n\n",
		NULL
	};
	GtkWidget *dialog;
	
	dialog = info_dialog_new("Known-bugs", known_bugs_sizes, known_bugs_text);
	gtk_widget_show(dialog);
}

void
menu_help_feedback(GtkWidget *widget, gpointer data)
{
	static guint feedback_sizes[] =
	{
		FONT_BIG,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_BIG,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		FONT_SMALL,
		0
	};
	static guchar *feedback_text[] = {
		"Comments, suggestions and bug-reportings:\n",
		"    Please send them to my current primary e-mail address:\n",
		"    jkhotaru@mail.sti.com.cn\n\n",
		"    I'm collecting icon for gtksee. If you are interested in this job, make one and send it to me. Thanks. I'm not good at graphics design, sorry. I will distribute them together with the next release.\n\n",
		"Imageware:\n",
		"    I'm always collecting all kinds of images. If you *really* like this program, send your favorite picture(s) to my secondary e-mail address:\n",
		"    hotaru@163.net\n",
		"    Keep sending me things. :) And I'll keep on developing this program.\n",
		"    P.S. My favorite is Anime/Manga. :)\n",
		NULL
	};
	GtkWidget *dialog;
	
	dialog = info_dialog_new("Feedback", feedback_sizes, feedback_text);
	gtk_widget_show(dialog);
}
