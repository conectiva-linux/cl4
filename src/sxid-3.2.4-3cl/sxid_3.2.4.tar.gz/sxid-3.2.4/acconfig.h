/* Define if your system has the getopt functions. */
#undef HAVE_GETOPT

/* The location of your mail program */
#undef MAIL_PROG

/* Define this if MAIL_PROG takes the subject on command line with -s */
#undef CL_SUBJ

/* The default location of sxid.conf */
#undef CONF_FILE

/* The version of this program */
#undef SXID_VERSION
