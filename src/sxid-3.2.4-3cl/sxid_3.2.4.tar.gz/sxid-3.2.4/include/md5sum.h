/*
 * md5sum.h   - Generate/check MD5 Message Digests
 *
 * Compile and link with md5.c.  If you don't have getopt() in your library
 * also include getopt.c.  For MSDOS you can also link with the wildcard
 * initialization function (wildargs.obj for Turbo C and setargv.obj for MSC)
 * so that you can use wildcards on the commandline.
 *
 * Written March 1993 by Branko Lankester
 * Modified June 1993 by Colin Plumb for altered md5.c.
 * Modified Feburary 1995 by Ian Jackson for use with Colin Plumb's md5.c.
 * Hacked (modified is too nice a word) January 1997 by Galen Hazelwood
 *   to support GNU gettext.
 * This file is in the public domain.
 *
 * Modified for sXid by Ben Collins - Dec. 1998
 */

#ifndef MD5SUM_H
#define MD5SUM_H 1

int mdfile (FILE * fp, unsigned char *digest);
int do_check (char *path, char *md5sum);
int hex_digit (int c);

#endif /* MD5SUM_H */
