/*
 * sxid - suid, sgid file and directory checking
 * logging.h - defines and declerations for logging features
 *
 * Copyright (C) 1999 Ben Collins <bcollins@debian.org>
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with sxid; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 * 02111-1307  USA
 */

#ifndef LOGGING_H
#define LOGGING_H 1

void init_file_entries (void);
void compare_output (void);
void save_and_rotate (void);
void check_add_rem (FILE *);
void check_attr (FILE *);
void check_u_g (FILE *);
void check_forbidden (FILE *);
void do_list_all (FILE *);
int add_file_entry (char *, struct stat, char *);
struct file_entry *get_fe_bypath (char *);

#endif /* LOGGING_H */
