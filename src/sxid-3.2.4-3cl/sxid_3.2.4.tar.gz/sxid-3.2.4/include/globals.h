/*
 * sxid - suid, sgid file and directory checking
 * globals.h - global defines and declerations
 *
 * Copyright (C) 1999 Ben Collins <bcollins@debian.org>
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with sxid; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 * 02111-1307  USA
 */

#ifndef GLOBALS_H
#define GLOBALS_H 1

#include <string.h>

extern char *confname;
extern struct config_opt config_options;
extern int changed;
extern int notify_diff;
extern int nomail;
extern char current_time[1024];
extern struct file_entry *global_log;
extern FILE *mail_file;
extern char sxid_version[];

#ifndef uint
#define uint unsigned int
#endif

#ifndef PATH_MAX
#define PATH_MAX 1024
#endif

#ifndef NAME_MAX
#define NAME_MAX 14
#endif

#endif /* GLOBALS_H */
