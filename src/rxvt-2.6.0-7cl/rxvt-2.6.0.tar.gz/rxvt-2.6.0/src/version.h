#define VERSION "2.6.0"
#define DATE	"08 JUNE 1999"
#define LSMDATE	"08JUN99"
