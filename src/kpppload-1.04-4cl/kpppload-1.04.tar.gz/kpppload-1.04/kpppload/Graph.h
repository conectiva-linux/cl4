// KPPPLoad - a PPP load monitor
// Copyright (C) 1998  Sean Vyain, svyain@mail.tds.net
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

#ifndef _Graph_h_
#define _Graph_h_

#include <qpixmap.h>
#include <qwidget.h>

/**
 * @short Widget that graphs the PPP link throughput.
 *
 * This widget draws a throughput graph for the transmit and receive rates of
 * the PPP link.  Different colors may be used for the transmit and receive
 * rates, as well as the dividing lines.  See @see Options for details.  The
 * graph is automatically scrolled as data is received.
 */
class Graph : public QWidget {
    Q_OBJECT
    int     _historySize;
    int*    _txHistory;
    int*    _rxHistory;
    int     _dataSize;
    int*    _txData;
    int*    _rxData;
    int     _txAverage;
    int     _rxAverage;
    int     _max;
    QPixmap _pixmap;

    void updateGraph();
protected:
    /**
     * Rescale and redraw the graph.
     */
    virtual void resizeEvent( QResizeEvent* e );

    /**
     * This method only bitBlt()s a pixmap of the graph onto the screen.  It
     * does not actually redraw the graph.
     */
    virtual void paintEvent( QPaintEvent* e );

    /**
     * Emit the popupMenu() signal when the right mouse button is pressed.  The
     * position of the mouse is given in global screen coordinates (e.g. root
     * window coordinates).
     */
    virtual void mousePressEvent( QMouseEvent* e );
public:
    /**
     * Create a new instance of the graphing widget, with the given parent and name.
     */
    Graph( QWidget* parent = 0, const char* name = 0 );

    /**
     * Cleanup the the graphing widget.
     */
    ~Graph();
public slots:
    /**
     * Update the graph with the new link statistics.
     *
     * @param rxDelta The number of bytes received during the last statistics interval.
     * @param txDelta The number of bytes transmitted during the last statistics interval.
     * @param rxTotal Not used.
     * @param txTotal Not used.
     */
    void updateStats( uint rxDelta, uint txDelta, uint rxTotal, uint txTotal );

    /**
     * Erase the graph, and clear the transmit and receive histories.
     */
    void linkDown();

    /**
     * Erase and completely redraw the graph.  This is usually called when
     * something that affects the appearance of the graph has been changed
     * (e.g. transmit or receive color).
     */
    void redrawGraph();
signals:
    /**
     * This signal is emitted when the right mouse button is pressed.
     *
     * @param pos The position of the mouse cursor when the button was pressed.
     */
    void popupMenu( const QPoint& pos );
};

#endif
