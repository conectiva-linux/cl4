vk|kterm|kterm kanji terminal emurator (X window system):\
	:hs:es:ts=\E[?E\E[?%i%dT:fs=\E[?F:ds=\E[?H:tc=xterm:
