kterm|kterm kanji terminal emulator (X window system),
	hs, eslok, tsl=\E[?E\E[?%i%dT, fsl=\E[?F, dsl=\E[?H, use=xterm,
