#ifndef CALC_H
#define CALC_H
double Calc(char *cmd);
#endif
