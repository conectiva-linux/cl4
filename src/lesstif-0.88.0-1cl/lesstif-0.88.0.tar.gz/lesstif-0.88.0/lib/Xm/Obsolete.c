/**
 *
 * $Id: Obsolete.c,v 1.4 1999/02/02 18:23:19 gritton Exp $
 *
 * Copyright (C) 1997 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/

static const char rcsid[] = "$Id: Obsolete.c,v 1.4 1999/02/02 18:23:19 gritton Exp $";

#include <Xm/Text.h>
#include <Xm/TextF.h>

/* This file contains functions from previous versions that are now obsolete */

/* For the prototype police */
extern int XmTextFieldGetBaseLine(Widget w);
extern int XmTextGetBaseLine(Widget w);

int
XmTextFieldGetBaseLine(Widget w)
{
    return XmTextFieldGetBaseline(w);
}

int
XmTextGetBaseLine(Widget w)
{
    return XmTextGetBaseline(w);
}
