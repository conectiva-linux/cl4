/* SSL directory.  */
#undef SSLDIR

/* Stunnel version.  */
#undef VERSION

/* Stunnel HOST.  */
#undef HOST

/* Define if you have the TCP wrapper library (-lwrap).  */
#undef HAVE_LIBWRAP

/* Define if you have the RSAref library (-lrsaref).  */
#undef HAVE_LIBRSAREF
