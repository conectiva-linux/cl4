/*	$OpenBSD: pathnames.h,v 1.2 1998/05/03 05:02:12 gene Exp $	*/

/*
 * Written Roland McGrath <roland@frob.com> 10/15/93.
 * Public domain.
 */

#include <paths.h>

#define	_PATH_BOOTPARAMS	"/etc/bootparams"

/* XXX this doesn't belong here */
#if defined(__linux__)
#define	in_addr_t	unsigned int
#endif
