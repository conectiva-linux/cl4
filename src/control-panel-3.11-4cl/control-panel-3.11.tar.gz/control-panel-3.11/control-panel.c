/* -*-Mode: c-*- */
/* Copyright (C) 1997 Red Hat Software, Inc.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <gtk/gtk.h>

#define H_WIDTH 380
#define H_HEIGHT 125
#define V_WIDTH 104
#define V_HEIGHT 400

struct userpanel_item
{
  char* program;
  char* icon;
  char* label;
  char* summary;
  struct userpanel_item* next;
};


GtkWidget* main_window;
GtkWidget* icon_box;

void userpanel_create();
GtkWidget* userpanel_menubar_create();
void userpanel_run_program(char* program);
void userpanel_toggle_orientation();
int userpanel_read_rc();
void userpanel_write_rc();
struct userpanel_item* userpanel_parse_root_items();
void userpanel_sigchld();

int
main(int argc, char* argv[])
{
  gtk_init(&argc, &argv);

  userpanel_create();

  if(signal(SIGCHLD, userpanel_sigchld) == SIG_ERR)
    {
      fprintf(stderr, "Error setting signal handler.");
      exit(1);
    }

  gtk_main();

  return 0;
  
}

void
userpanel_create()
{
  struct userpanel_item* items;
  GtkWidget* menubar;
  GtkWidget* scrolled;
  GtkWidget* vbox;
  GtkWidget* hbox;
  GtkWidget* button;
  GtkWidget* icon;
/*   GtkWidget* label; */
  GtkTooltips* tooltips;
  GtkStyle* style;
  GdkPixmap* pixmap;
  GdkBitmap* mask;

  items = userpanel_parse_root_items();

  main_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_realize(main_window);
  /* wish I could get a gtk program to listen to the close from afterstep... */
  /* I believe this problem w/ afterstep has been fixed, but I'm not
   * running it (afterstep) now to test it.
   */
  gtk_signal_connect(GTK_OBJECT(main_window), "destroy", userpanel_write_rc, NULL);
  gtk_signal_connect(GTK_OBJECT(main_window), "destroy", gtk_main_quit, NULL);
  gtk_signal_connect(GTK_OBJECT(main_window), "delete_event", userpanel_write_rc, NULL);
  gtk_signal_connect(GTK_OBJECT(main_window), "delete_event", gtk_main_quit, NULL);

  menubar = userpanel_menubar_create();

  scrolled = gtk_scrolled_window_new(NULL, NULL);

  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled), 
				 GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

  if(userpanel_read_rc() == 0)
    {
      icon_box = gtk_hbox_new(TRUE, 5);
      gtk_widget_set_usize(main_window, H_WIDTH, H_HEIGHT);
    }
  else
    {
      icon_box = gtk_vbox_new(TRUE, 5);
      gtk_widget_set_usize(main_window, V_WIDTH, V_HEIGHT);
    }

  hbox = gtk_hbox_new(FALSE, 5);

  tooltips = gtk_tooltips_new();

  while(items != NULL)
    {
      button = gtk_button_new();
      gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
				(GtkSignalFunc) userpanel_run_program,
				(gpointer)items->program);
      
      style = gtk_widget_get_style(button);
      pixmap = gdk_pixmap_create_from_xpm(main_window->window, 
					  &mask,
					  &style->bg[GTK_STATE_NORMAL], 
					  items->icon);
      icon = gtk_pixmap_new(pixmap, mask);
      /* turn this into a tooltip widget. */
/*       label = gtk_label_new(items->label); */
/*       tooltips = gtk_tooltips_new(); */
      gtk_tooltips_set_tip(tooltips, button, items->label, items->label);
      
      vbox = gtk_vbox_new(FALSE, 0);

      gtk_box_pack_start(GTK_BOX(vbox), icon, FALSE, FALSE, 0);
/*       gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 0); */
      gtk_container_add(GTK_CONTAINER(button), vbox);
      
      gtk_box_pack_start(GTK_BOX(icon_box), button, TRUE, TRUE, 0);
      
      gtk_widget_show(icon);
/*       gtk_widget_show(label); */
      gtk_widget_show(vbox);
      gtk_widget_show(button);

      items = items->next;
    }

  vbox = gtk_vbox_new(FALSE, 0);

  gtk_box_pack_start(GTK_BOX(hbox), icon_box, FALSE, FALSE, 5);
  gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolled),
					hbox);
/*  gtk_container_add(GTK_CONTAINER(scrolled), hbox); */
  gtk_box_pack_start(GTK_BOX(vbox), menubar, FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), scrolled, TRUE, TRUE, 0);
  gtk_container_add(GTK_CONTAINER(main_window), vbox);

  gtk_widget_show(icon_box);
  gtk_widget_show(hbox);
  gtk_widget_show(scrolled);
  gtk_widget_show(menubar);
  gtk_widget_show(vbox);
  gtk_widget_show(main_window);

}

void
userpanel_run_program(char* program)
{
  pid_t pid;

  pid = fork();

  if(pid == 0)
    {
      if(execlp(program, program, 0) == -1)
	{
	  fprintf(stderr, "exec() error, errno=%d.\n", errno);
	}
    }
  else if(pid < 0)
    {
      fprintf(stderr, "fork error.\n");
    }

  return;
}

GtkWidget*
userpanel_menubar_create()
{
  GtkWidget* menubar;
  GtkWidget* menu;
  GtkWidget* menuitem;

  menubar = gtk_menu_bar_new();
  menu = gtk_menu_new();
  gtk_widget_show(menubar);

  menuitem = gtk_menu_item_new_with_label("Change Orientation");
  gtk_menu_append(GTK_MENU(menu), menuitem);
  gtk_signal_connect(GTK_OBJECT(menuitem), "activate",
                     (GtkSignalFunc) userpanel_toggle_orientation, NULL);
  gtk_widget_show(menuitem);

  menuitem = gtk_menu_item_new();
  gtk_menu_append(GTK_MENU(menu), menuitem);
  gtk_widget_show(menuitem);

  menuitem = gtk_menu_item_new_with_label("Exit");
  gtk_menu_append(GTK_MENU(menu), menuitem);
  gtk_signal_connect(GTK_OBJECT(menuitem), "activate",
                     (GtkSignalFunc) gtk_main_quit, NULL);
  gtk_signal_connect(GTK_OBJECT(menuitem), "activate",
                     (GtkSignalFunc) userpanel_write_rc, NULL);
  gtk_widget_show(menuitem);

  menuitem = gtk_menu_item_new_with_label("File");
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(menuitem), menu);
  gtk_container_add(GTK_CONTAINER(menubar), menuitem);
  gtk_widget_show(menuitem);

  return menubar;
}

void
userpanel_remove_button(GtkWidget* button, GtkWidget* old_box)
{
  gtk_container_remove(GTK_CONTAINER(old_box), button);
}

void
userpanel_add_button(GtkWidget* button, GtkWidget* new_box)
{
  gtk_box_pack_start(GTK_BOX(new_box), button, TRUE, TRUE, 0);
}

void
userpanel_toggle_orientation()
{
  /* for now, it will just "touch" or remove the file to keep track of
   * the last state.  Later, if there needs to be more, I'll put
   * something in the file.
   */

  char* home_dir;
  char* filename = ".control-panelrc";
  char* full_path;
  int fd;
  int len;

  home_dir = getenv("HOME");

  len = strlen(home_dir) + 1 + strlen(filename) + 1;
  full_path = malloc(sizeof(char) * len);

  snprintf(full_path, len, "%s/%s", home_dir, filename);

  if(GTK_IS_VBOX(icon_box))
    {
      fd = open(full_path, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR);
      write(fd, "loopy", 5);
      close(fd);
    }
  else if(GTK_IS_HBOX(icon_box))
    {
      remove(full_path);
    }
  else
    {
      /* error condition */
    }

  free(full_path);


  /* restart control-panel */
  if (execlp("control-panel", "control-panel", NULL) < 0) {
    fprintf(stderr, "error restarting\n");
  }
 
}

int
userpanel_read_rc()
{
  char* home_dir;
  char* filename = ".control-panelrc";
  char* full_path;
  struct stat stat_buf;
  int len;

  home_dir = getenv("HOME");

  len = strlen(home_dir) + 1 + strlen(filename) + 1;
  full_path = malloc(sizeof(char) * len);

  snprintf(full_path, len, "%s/%s", home_dir, filename);

  return stat(full_path, &stat_buf);

}

void
userpanel_write_rc()
{
  /* for now, it will just "touch" or remove the file to keep track of
   * the last state.  Later, if there needs to be more, I'll put
   * something in the file.
   */

  char* home_dir;
  char* filename = ".control-panelrc";
  char* full_path;
  int fd;
  int len;

  home_dir = getenv("HOME");

  len = strlen(home_dir) + 1 + strlen(filename) + 1;
  full_path = malloc(sizeof(char) * len);

  snprintf(full_path, len, "%s/%s", home_dir, filename);

  if(GTK_IS_HBOX(icon_box))
    {
      fd = open(full_path, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR);
      write(fd, "loopy", 5);
      close(fd);
    }
  else if(GTK_IS_VBOX(icon_box))
    {
      remove(full_path);
    }
  else
    {
      /* error condition */
    }

  free(full_path);
 
}

struct userpanel_item*
userpanel_parse_root_items()
{
  struct userpanel_item* retval;
  struct userpanel_item* new_item;
  char* init_path = "/usr/lib/rhs/control-panel/";
  char* init_file_extension;
  DIR* init_dir;
  struct dirent* init_file;
  int ret;
  int fd;
  char* index;
  char* buf;
  struct stat stat_buf;
  
  retval = NULL;

  chdir(init_path);
  init_dir = opendir(init_path);

  while((init_file = readdir(init_dir)) != NULL)
    {
      init_file_extension = strrchr(init_file->d_name, '.');
      if(init_file_extension == NULL)
	continue;
      if(strcmp(init_file_extension, ".init") == 0)
	{
	  /* FIXME: aggressive error checking. */
	  fd = open(init_file->d_name, O_RDONLY);
	  ret = fstat(fd, &stat_buf);
	  buf = malloc(sizeof(char)*stat_buf.st_size);
	  read(fd, buf, stat_buf.st_size);
	  buf[stat_buf.st_size] = '\0';

	  new_item = malloc(sizeof(struct userpanel_item));

	  new_item->program = buf;
	  index = strchr(buf, '\n');
	  index[0] = '\0';
	  buf = index + 1;

	  /* a little different than the others, so I can prepend the
	   * path to the icon file. 
	   */
	  index = strchr(buf, '\n');
	  index[0] = '\0';
	  new_item->icon = malloc(sizeof(char) * (strlen(init_path) +
						  strlen(buf)) + 1);
	  snprintf(new_item->icon, strlen(init_path) + 1, "%s/", init_path);
	  strcat(new_item->icon, buf);
	  buf = index + 1;

	  new_item->label = buf;
	  index = strchr(buf, '\n');
	  index[0] = '\0';
	  buf = index + 1;

	  new_item->summary = buf;

	  new_item->next = retval;
	  retval = new_item;
	}
    }

  return retval;
}

/* Handle SIGCHLD, only here to clean up zombies. */
void
userpanel_sigchld()
{
  pid_t pid;
  int status;

  pid = waitpid(-1, &status, WNOHANG | WUNTRACED);

  /* shoudln't need any error condition code... think about this one. */
  
  if(signal(SIGCHLD, userpanel_sigchld) == SIG_ERR)
    {
      fprintf(stderr, "Error setting signal handler.");
      exit(1);
    }
}
