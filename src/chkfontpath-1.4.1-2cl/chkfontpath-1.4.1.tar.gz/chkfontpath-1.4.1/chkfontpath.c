#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <libgen.h>
#include <popt.h>

static char *progName;
static char **fpList = 0;
static int fpCount = 0;
static int quiet = 0;

void readFontPath()
{
  FILE *f;
  char buf[250];
  char *s, *p;
  int catFlag = 0;

  f = fopen("/etc/X11/fs/config", "r");
  if (!f) {
    if (!quiet) {
      fprintf(stderr, "%s: error opening /etc/X11/fs/config\n", progName);
      exit(1);
    } else 
      exit(0);
  }

  while ((s = fgets(buf, sizeof(buf), f)) != NULL) {
    p = s;

    /* strip leading white space */
    while (isblank(*s)) s++;
    /* strip trailing white space */
    p = s + strlen(s)-2;
    while (isspace(*p)) {
      *p = '\0';
      p--;
    }
    *(p+1) = '\n';
    *(p+2) = '\0';
    
    /* skip all comment lines */
    if (*s == '#')
      continue;

    if (strstr(s, "catalogue") && !catFlag) {
      catFlag = 1;
      p = strchr(s, '=');
      if (!p) {
	if (!quiet) {
	  fprintf(stderr,"%s: error locating '=' after catalogue token\n",
		  progName);
	  exit(1);
	} else
	  exit(0);
      }
      p++;
      while (isblank(*p))
	p++;
      s = p;
    }

    if (catFlag && s[0] == '\n')
      catFlag = 0;

    if (catFlag) {
      fpCount++;
      p = strdup(s);
      if (p[strlen(p)-1] == '\n')
	  p[strlen(p)-1] = '\0';
      if (p[strlen(p)-1] == ',')
	  p[strlen(p)-1] = '\0';

      fpList = (char **) realloc(fpList, sizeof(char **) * fpCount);
      fpList[fpCount - 1] = p;
    }

    if (catFlag && (s[strlen(s)-2] != ','))
      catFlag = 0;
  }

  fclose(f);
}

void writeNewConfig()
{
  FILE *f, *f1;
  char buf[250];
  char *s, *p;
  int catFlag = 0, i;
  struct stat sb;

  stat("/etc/X11/fs/config", &sb);
  
  f = fopen("/etc/X11/fs/config", "r");
  if (!f) {
    if (!quiet) {
      fprintf(stderr, "%s: error opening /etc/X11/fs/config for reading\n", 
	      progName);
      exit(1);
    } else
      exit(0);
  }
  f1 = fopen("/etc/X11/fs/config-", "w");
  if (!f1) {
    if (!quiet) {
      fprintf(stderr, "%s: error opening /etc/X11/fs/config- for writing\n", 
	      progName);
      exit(1);
    } else 
      exit(0);
  }

  while ((s = fgets(buf, sizeof(buf), f)) != NULL) {
    p = s;

    /* strip leading white space */
    while (isblank(*s)) s++;
    
    /* skip all comment lines */
    if (*s == '#') {
      fprintf(f1, s);
      continue;
    }

    if (strstr(s, "catalogue") && !catFlag) {
      catFlag = 1;
      p = strchr(s, '=');
      if (!p) {
	if (!quiet) {
	  fprintf(stderr,"%s: error locating '=' after catalog token\n",
		  progName);
	  exit(1);
	} else
	  exit(0);
      }
      for (i = 1; i <= fpCount; i++) {
	if (fpList[i-1] == NULL)
	  continue; /* skip deleted paths */
	if (i == 1)
	  fprintf(f1, "catalogue = %s",fpList[0]);
	else
	  fprintf(f1, "\t%s",fpList[i-1]);
	if (i == fpCount)
	  fprintf(f1, "\n");
	else
	  fprintf(f1, ",\n");
      }
    }

    if (!catFlag)
      fprintf(f1, s);

    if (catFlag && (s[0] == '\n' || s[strlen(s)-2] != ',')) {
      catFlag = 0;
    }
  }

  fclose(f);  
  fclose(f1);
  unlink("/etc/X11/fs/config");
  rename("/etc/X11/fs/config-", "/etc/X11/fs/config");

  /* fix up permissions on the new file */
  chmod("/etc/X11/fs/config", sb.st_mode);
}

void addDir(const char *newDir)
{
  int i;
  FILE *f;
  char *fontsdir;

  fontsdir = (char *) malloc(sizeof(char *) * (strlen(newDir) + 12));
  sprintf(fontsdir, "%s/fonts.dir",newDir);
  f = fopen(fontsdir, "r");
  if (!f) {
    if (!quiet) {
      fprintf(stderr,"%s: error opening %s, unwilling to add path\n",
	      progName, fontsdir);
      exit(1);
    } else
      exit(0);
  }
  fclose(f);

  for (i = 0; i < fpCount; i++) {
    if (strcmp(fpList[i], newDir) == 0) {
      if (!quiet) {
	fprintf(stderr, "%s: %s already in list\n",progName, newDir);
	exit(1);
      } else
	exit(0);
    }
  }
  fpCount++;
  fpList = (char **) realloc(fpList, sizeof(char **) * fpCount);
  fpList[fpCount - 1] = strdup(newDir);
}

void removeDir(const char *delDir)
{
  int found = 0;
  int i;

  for (i = 0; i < fpCount; i++) {
    if (strcmp(fpList[i], delDir) == 0) {
      found = 1;
      fpList[i] = NULL;
      /* the following is a HACK.  Because of the way we re-write out the
	 config file, we are getting trailing commas on the font path list
	 when the last path is removed.  So in this case we want to dec.
	 fpCount, so that the count 'looks' ok in that function.  Ugly. */
      if (i == fpCount-1) fpCount--;
    }
  }
  if (!found) {
    if (!quiet) {
      fprintf(stderr, "%s: %s not found in list\n",progName, delDir);
      exit(1);
    } else
      exit(0);
  }
}

void restartXfs()
{
  struct stat st;
  /*  pid_t pid, wst;*/
  
  /* Stat /proc/version to see if /proc is mounted. */
  if (stat("/proc/version", &st) == 0) {
    
    /* It's there, we can do the pidof w/o fear of mounting /proc. */
    system("kill -USR1 `/sbin/pidof xfs` 2&1>/dev/null");
  }
}

void listPaths()
{
  int i;
  printf("Current directories in font path:\n");
  for (i = 0; i < fpCount; i++)
    printf("%d: %s\n",i+1, fpList[i]);
}

void usage(void) 
{
  fprintf(stderr, "Usage: %s [options]\n\n"
	  "     --add <dir>          add directory specified to font path\n"
	  "     --remove <dir>       remove directory specified from path\n"
	  "     --list               list all directories in path\n"
	  "     --help               show this screen\n",
	  progName);
  
  exit(0);
}

int main(int argc, char **argv)
{
  int rc, list = 0, help = 0;
  poptContext optCon;
  char *newDir = NULL, *delDir = NULL;
  struct poptOption options[] = {
    { "add", 'a', POPT_ARG_STRING, &newDir, 0 },
    { "remove", 'r', POPT_ARG_STRING, &delDir, 0 },
    { "list", 'l', 0, &list, 0 },
    { "quiet", 'q', 0, &quiet, 0 },
    { "help", 'h', 0, &help, 0 },
    { 0, 0, 0, 0 }
  };  
  
  progName = basename(argv[0]);
  progName++;

  optCon = poptGetContext(progName, argc, argv, options, 0);
  poptReadDefaultConfig(optCon, 1);

  if ((rc = poptGetNextOpt(optCon)) < -1) {
    fprintf(stderr, "%s: bad argument %s: %s\n",
	    progName, poptBadOption(optCon, POPT_BADOPTION_NOALIAS),
	    poptStrerror(rc));
    exit(1);
  }

  if (poptGetArg(optCon)) {
    fprintf(stderr, "%s: unexpected argument\n",
	    progName);
    exit(1);
  }

  poptFreeContext(optCon);

  if (help || argc == 1)
    usage();

  readFontPath();

  if (newDir != NULL) {
    addDir(newDir);
  }

  if (delDir != NULL) {
    removeDir(delDir);
  }

  if (list)
    listPaths();

  if (newDir != NULL || delDir != NULL) {
    writeNewConfig();
    restartXfs();
  }

  return 0;
}
