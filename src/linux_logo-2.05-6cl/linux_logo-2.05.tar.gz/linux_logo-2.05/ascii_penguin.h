const char *ascii_logo[]={
"         $$$$$$       ",
"        $$$$$$$$        LL     IIIIII NN   NN UU  UU XX  XX",
"        $  $  $$        LL       II   NNN  NN UU  UU  XXXX ",
"        $/o$o\\$$        LL       II   NNNN NN UU  UU   XX  ",
"        $////$$$$       LL       II   NN NNNN UU  UU  XXXX ",
"        <<<<<$$$$       LLLLLL IIIIII NN   NN  UUUU  XX  XX",
"        $......$$$    ",
"       $........$$$$  ",
"       $.........$$$$ ",
"       $.........$$$$ ",
"      $..........$$$$$",
"     $$..........$$$$$",
"     ###........###$$$",
"   #####........####$$",
" #######........######",
" #######$......$######"
};
