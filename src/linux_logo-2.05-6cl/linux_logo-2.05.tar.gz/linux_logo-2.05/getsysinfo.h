void get_os_info(char *os_name,char *os_version,char *os_revision,char *host_name);
void get_hardware_info(char *cpuinfo,char *bogo_total,int skip_bogomips);
