This is mirror-2.9.

The documentation for mirror is now in HTML format.

Please use your internet browser to read the index.html file to get an overview
of the documentation available.  If you cannot then quickstart.txt contains
enough information to get you started.
