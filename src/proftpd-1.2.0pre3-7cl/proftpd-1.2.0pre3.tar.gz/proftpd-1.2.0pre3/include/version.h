#define VERSION                 "1.2.0pre3"
#define INTERNAL_VERSION        0x01020003
