
/* FreeBSD 2.0 is using ifconfig arguments and not ioctl() calls */
#ifdef IOCTL_FLAGS

/* I don't want to work with constant numbers, so we need some defines */
#if !defined(SL_MODE_CSLIP) && defined(SC_COMPRESS)
#define SL_MODE_CSLIP	SC_COMPRESS
#endif
#if !defined(SL_MODE_SLIP6) && defined(SL_OPT_SIXBIT)
#define SL_MODE_SLIP6	SL_OPT_SIXBIT
#endif
#if !defined(SL_MODE_AX25) && defined(SL_MODE_KISS)
#define SL_MODE_AX25	SL_MODE_KISS
#endif
#if !defined(SL_MODE_NOICMP) && defined(SC_NOICMP)
#define SL_MODE_NOICMP	SC_NOICMP
#endif
#if !defined(SL_MODE_ADAPTIVE) && defined(SC_AUTOCOMP)
#define SL_MODE_AUTO	SC_AUTOCOMP
#endif
#if !defined(SL_MODE_ADAPTIVE) && defined(SL_OPT_ADAPTIVE)
#define SL_MODE_AUTO	SL_OPT_ADAPTIVE
#endif

typedef struct slip_modes {
    char	*sm_name;
    int	sm_value;
} slip_modes;

#endif

