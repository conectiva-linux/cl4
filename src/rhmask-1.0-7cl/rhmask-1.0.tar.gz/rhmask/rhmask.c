#include <fcntl.h>
#include <stdio.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#define MAGIC 0xEF8134BE

#define maximum(a,b) (a > b ? a : b)

struct maskHeader {
    unsigned int magic;
    unsigned int version;
    unsigned int origFileSize;
    unsigned int maskFileSize;
    unsigned int outFileSize;
    unsigned int outFileNameLen;
    char inMd5sum[32];
    char outMd5sum[32];
};

static void usage(void) {
    fprintf(stderr, "rhmask: <origfile> <maskfile>\n");
    fprintf(stderr, "        -d <origfile> <newfile> <maskfile>\n");
    exit(1);
}

static unsigned int fdsize(int fd) {
    struct stat sb;

    if (fstat(fd, &sb)) {	
	perror("fstat");
	exit(1);
    }

    return sb.st_size;
}

static void md5buf(char * buf, int bufSize, char result[32]) {
    int childPid;
    int status;
    int pipefds[2];
    int outpipe[2];

    pipe(pipefds);
    pipe(outpipe);

    if (!(childPid = fork())) {
	dup2(pipefds[0], 0);
	close(pipefds[1]);
	close(pipefds[0]);

	dup2(outpipe[1], 1);
	close(outpipe[0]);
	close(outpipe[1]);

	execlp("md5sum", "md5sum", "-", NULL);
	exit(1);
    }

    close(pipefds[0]);
    close(outpipe[1]);
    if (write(pipefds[1], buf, bufSize) != bufSize) 
	perror("md5 write"), exit(1);
    close(pipefds[1]);

    waitpid(childPid, &status, 0);

    if (read(outpipe[0], result, 32) != 32) {
	fprintf(stderr, "failed to read md5sum\n");
	exit(1);
    }

    if (!WIFEXITED(status)) {
	fprintf(stderr, "md5sum failed status\n");
	exit(1);
    }

    close(outpipe[0]);
}

int main(int argc, char ** argv) {
    int generate = 0;
    int infile1, infile2, outfile;
    struct maskHeader hdr;
    int i;
    unsigned int in1size, in2size, outsize;
    char * in1, * in2, * out;
    char * end1, * end2, * endout;
    char zeros[] = { '\0', '\0', '\0', '\0', '\0', '\0', '\0' };
    char * chptr1, * chptr2, * outptr;
    char * outFileName;
    char buf[32];

    if (argc < 3) usage();

    if (!strcmp(argv[1], "-d")) {
	generate = 1;
	if (argc != 5) usage();

	if ((infile1 = open(argv[2], O_RDONLY)) < 0) {
	    perror(argv[2]);
	    exit(1);
	}
	
	if ((infile2 = open(argv[3], O_RDONLY)) < 0) {
	    perror(argv[3]);
	    exit(1);
	}
	
	if ((outfile = open(argv[4], O_RDWR | O_TRUNC | O_CREAT, 0666)) < 0) {
	    perror(argv[4]);
	    exit(1);
	}

	outFileName = argv[3] + strlen(argv[3]) - 1;
	while (outFileName > argv[3] && *outFileName != '/') outFileName--;
	if (*outFileName == '/') outFileName++;

	hdr.magic = MAGIC;
	hdr.version = 1;
	hdr.origFileSize = fdsize(infile1);
	hdr.outFileSize = fdsize(infile2);
	hdr.outFileNameLen = strlen(outFileName) + 1;

	/* pad to eight bytes */
	i = (8 - (hdr.outFileNameLen % 8)) % 8;

	hdr.maskFileSize = maximum(hdr.origFileSize, hdr.outFileSize) + 
			   sizeof(hdr) + hdr.outFileNameLen + i;

	in1size = fdsize(infile1);
	in1 = mmap(NULL, in1size, PROT_READ, MAP_SHARED, infile1, 0);
	if (((long int) in1) == -1) perror("mmap 1"), exit(1);
	end1 = in1 + in1size;

	in2size = fdsize(infile2);
	in2 = mmap(NULL, in2size, PROT_READ, MAP_SHARED, infile2, 0);
	if (((long int) in2) == -1) perror("mmap 2"), exit(1);
	end2 = in2 + in2size;

	outsize = hdr.maskFileSize;
	i += sizeof(hdr) + hdr.outFileNameLen;
	if (lseek(outfile, outsize - 1, SEEK_SET) != outsize - 1) perror("foo");
	write(outfile, zeros, 1);
	out = mmap(NULL, outsize, PROT_WRITE, MAP_SHARED, outfile, 0);
	if (((long int) out) == -1) perror("mmap 3"), exit(1);
	endout = out + outsize;

	chptr1 = in1;
	chptr2 = in2;
	outptr = out + i;

	md5buf(in1, in1size, hdr.inMd5sum);
	md5buf(in2, in2size, hdr.outMd5sum);

	memcpy(out, &hdr, sizeof(hdr));
	memcpy(out + sizeof(hdr), outFileName, hdr.outFileNameLen);
    } else {
	if (argc != 3) usage();

	if ((infile1 = open(argv[1], O_RDONLY)) < 0) {
	    perror(argv[2]);
	    exit(1);
	}
	
	if ((infile2 = open(argv[2], O_RDONLY)) < 0) {
	    perror(argv[3]);
	    exit(1);
	}

	if (read(infile2, &hdr, sizeof(hdr)) != sizeof(hdr))
	    perror("read"), exit(1);

	if (hdr.magic != MAGIC) {
	    fprintf(stderr, "%s is not a rhmask mask file\n", argv[3]);
	    exit(1);
	}

	in1size = fdsize(infile1);
	in2size = fdsize(infile2);

	if (in2size != hdr.maskFileSize) {
	    fprintf(stderr, "%s is corrupt (file size mismatch)\n",
			argv[3]);
	    exit(1);
	}

	if (in1size != hdr.origFileSize) {
	    fprintf(stderr, "%s is not the proper original for this mask\n",
			argv[1]);
	    exit(1);
	}

	outFileName = alloca(hdr.outFileNameLen);
	if (read(infile2, outFileName, hdr.outFileNameLen) != 
		hdr.outFileNameLen)
	    perror("read"), exit(1);

	/* pad to eight bytes */
	i = (8 - (hdr.outFileNameLen % 8)) % 8;
	if (read(infile2, buf, i) != i) perror("read"), exit(1);

	printf("generating %s\n", outFileName);
	
	if ((outfile = open(outFileName, O_RDWR | O_TRUNC | O_CREAT, 
				0666)) < 0) {
	    perror(outFileName);
	    exit(1);
	}

	in1 = mmap(NULL, in1size, PROT_READ, MAP_SHARED, infile1, 0);
	if (((long int) in1) == -1) perror("mmap 1"), exit(1);
	end1 = in1 + in1size;

	i = lseek(infile2, 0, SEEK_CUR);
	in2 = mmap(NULL, in2size, PROT_READ, MAP_SHARED, infile2, 0);
	if (((long int) in2) == -1) perror("mmap 2"), exit(1);
	end2 = in2 + in2size;

	outsize = hdr.outFileSize;
	if (lseek(outfile, outsize - 1, SEEK_SET) != outsize - 1) perror("foo");
	write(outfile, zeros, 1);
	out = mmap(NULL, outsize, PROT_WRITE | PROT_READ, MAP_SHARED, 
			outfile, 0);
	if (((long int) out) == -1) perror("mmap 3"), exit(1);
	endout = out + outsize;

	chptr1 = in1;
	chptr2 = in2 + i;
	outptr = out;

	md5buf(in1, in1size, buf);
	if (memcmp(buf, hdr.inMd5sum, 32)) {
	    printf("read %.32s\n", buf);
	    printf("need %.32s\n", hdr.inMd5sum);
	    fprintf(stderr, "%s is not the proper original for this mask\n",
			argv[1]);
	    exit(1);
	}
    }

    /* this could be more efficient */

    i = 0;
    while (outptr < endout) {
	i++;
	*outptr++ = (*chptr1++ ^ *chptr2++);
	if (chptr1 == end1) chptr1 = in1;
	if (chptr2 == end2) chptr2 = in2;
    }

    if (!generate) {
	md5buf(out, outsize, buf);
	if (memcmp(buf, hdr.outMd5sum, 32)) {
	    fprintf(stderr, "error -- %s is corrupt!\n", outFileName);
	    exit(1);
	}
    }

    munmap(in1, in1size);
    munmap(in2, in2size);
    munmap(out, outsize);

    close(infile1);
    close(infile2);
    close(outfile);

    return 0;
}
