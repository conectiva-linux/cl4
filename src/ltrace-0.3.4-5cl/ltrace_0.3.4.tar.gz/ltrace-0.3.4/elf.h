#include "ltrace.h"

extern struct library_symbol * read_elf(const char *);

