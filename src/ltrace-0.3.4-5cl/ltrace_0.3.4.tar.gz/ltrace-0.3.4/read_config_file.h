extern void read_config_file(char*);

