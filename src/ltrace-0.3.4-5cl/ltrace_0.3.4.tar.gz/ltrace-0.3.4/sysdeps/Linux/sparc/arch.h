#include <sys/types.h>

#define BREAKPOINT_VALUE {0x91, 0xd0, 0x20, 0x01}
#define BREAKPOINT_LENGTH 4
#define DECR_PC_AFTER_BREAK 0

