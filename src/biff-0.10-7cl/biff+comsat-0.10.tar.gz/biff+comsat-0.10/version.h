/*
 * String to embed in binaries to identify package
 */

char pkg[] = "Package: biff+comsat-0.10";
