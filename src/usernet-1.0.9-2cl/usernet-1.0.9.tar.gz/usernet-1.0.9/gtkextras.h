#ifndef _GTK_EXTRAS_H
#define _GTK_EXTRAS_H


void
widget_show_all(GtkWidget *first, ...);

void
table_attach_at(GtkWidget *table, GtkWidget *wid, int r, int c);

GtkWidget *
make_vbox_of_labels(char *labels);

void
gtk_warning_dialog(gint run_main_loop, gchar *string, ...)
  __attribute__ ((format (printf, 2, 3)))
;

#endif /* _GTK_EXTRAS_H */
