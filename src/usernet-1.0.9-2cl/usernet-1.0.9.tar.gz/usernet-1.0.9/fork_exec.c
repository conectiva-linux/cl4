/*
 * Copyright (C) 1997 Red Hat Software, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>

/* We need a fork/exec so that netreport can find this process as the
 * parent pid.  This is a simplified version exec that serves our purposes.
 * 
 * Why doesn't something like this exist in libc?
 * Sometimes I don't want to system()
 */
int
fork_exec(char *path, char *arg)
{
  pid_t child;
  int status;

  if (!(child = fork())) {
    /* child */
    execl(path, path, arg, 0);
    perror(path);
    /* Can't call exit(), because it flushes the X protocol stream */
    _exit (1);
  }

  /* Hmm, I'm a parent.  Might as well wait and avoid zombies, eh? */
  wait4 (child, &status, 0, NULL);
  if (WIFEXITED(status) && (WEXITSTATUS(status) == 0)) {
    return 0;
  } else {
    return 1;
  }
}



/* fork_fork_exec causes init to reap processes we orphan */
int
fork_fork_exec(char **arg)
{
  pid_t child;
  pid_t grandchild;
  int status;

  if (!(child = fork())) {
    if (!(grandchild = fork())) {
      execv(arg[0], arg);
      perror(arg[0]);
      /* Can't call exit(), because it flushes the X protocol stream */
      _exit (1);
    }
    /* exit child, orphaning grandchild for init to clean up */
    _exit (1);
  }

  /* Hmm, I'm a parent.  Might as well wait and avoid zombies, eh? */
  wait4 (child, &status, 0, NULL);
  if (WIFEXITED(status) && (WEXITSTATUS(status) == 0)) {
    return 0;
  } else {
    return 1;
  }
}

