/*
 * Copyright (C) 1997, 1999 Red Hat Software, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <fcntl.h>
#include <gtk/gtk.h>
#include <regex.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <net/if.h>
#include "gtkextras.h"
#include "fork_exec.h"


/* globals.  Sometimes we really need them... */
static GSList *GL_interface_list;
static int GL_top = 1;


typedef struct _Interface Interface;
struct _Interface {
  gchar *name;
  GtkWidget *toggle_button;
  GtkWidget *status_button;
  GSList *clone_list;
  int status;
};

/* status definitions */
#define INT_DOWN 0
#define INT_GOING_DOWN 1
#define INT_GOING_UP 2
#define INT_UP 3

typedef struct _Clone Clone;
struct _Clone {
  gchar *name;
  /* Pointer to cloned interface */
  Interface *interface;
};


/* The destroy() function gets called on exit, whether the window is
 * sent a destroy signal by the WM, or the exit button is pressed.
 */
void
destroy (void)
{
  fork_exec("/sbin/netreport", "-r");
  gtk_exit (0);
}

int
delete (void)
{
  /* tell GTK to call destroy() */
  return TRUE;
}


gchar *
ppp_logical_to_physical(const gchar *logical_name)
{
  /* way too much space for "/var/run/ppp-ppp??.dev" */
  char map_file_name[100];
  /* way too much space for "ppp??" */
  char buffer[20];
  char *p;
  int f, n;
  char *physical_device = NULL;

  sprintf(map_file_name, "/var/run/ppp-%s.dev", logical_name);
  if ((f = open(map_file_name, O_RDONLY)) > 0) {
    if ((n = read(f, buffer, 20)) > 0) {
      buffer[n] = '\0';
      /* get rid of \n */
      p = buffer; while (*p && *p != '\n' && p < buffer+n) p++; *p = '\0';
      physical_device = g_strdup(buffer);
    }
    close(f);
  }

  return physical_device;
}


/* get_interface_status_by_name takes an interface name and returns
 * INT_DOWN or INT_UP (it doesn't know about changing; that
 * is handled elsewhere)
 *
 * ifconfig source code was quite helpful here.  :-)
 */
gint
get_interface_status_by_name(const gchar *interface_name)
{
  int sock = 0;
  int pfs[] = {AF_INET, AF_IPX, AF_AX25, AF_APPLETALK, 0};
  int p = 0;
  struct ifreq ifr;
  gchar *physical_name;
  /* If we don't find it, interface must be down */
  int retcode = INT_DOWN;

  while (!sock && pfs[p]) {
    sock = socket(pfs[p++], SOCK_DGRAM, 0);
  }

  if (!sock) {
    gtk_warning_dialog(GL_top,
	"The running system kernel has no networking installed");
    return INT_DOWN;
  }

  if (!strncmp("ppp", interface_name, 3)) {
    /* It is a PPP device, so we need to map it from logical to physical
     * before we look it up.
     */
    physical_name = ppp_logical_to_physical(interface_name);
    if (!physical_name) {
      /* If we can't find a mapping, it's because it's down. */
      return INT_DOWN;
    }
  } else {
    physical_name = g_strdup(interface_name);
  }

  memset(&ifr, 0, sizeof(ifr));
  strcpy(ifr.ifr_name, physical_name);

  if (ioctl(sock, SIOCGIFFLAGS, &ifr) < 0) {
    retcode = INT_DOWN;
  }
  if (ifr.ifr_flags & IFF_UP) {
    retcode = INT_UP;
  }

  free(physical_name);
  close(sock);
  return retcode;
}

void
update_interface_status(Interface *interface)
{
  int current_status;

  current_status = get_interface_status_by_name(interface->name);
  switch (interface->status) {
  case INT_UP:
  case INT_DOWN:
    /* We aren't trying to track a change -- just get the latest */
    interface->status = current_status;
    break;
  case INT_GOING_UP:
      if (current_status == INT_UP) {
        /* Interface appears to have come up successfully */
        interface->status = current_status;
      } else if (current_status == INT_DOWN) {
	 interface->status = current_status;
      }
    break;
  case INT_GOING_DOWN:
      if (current_status == INT_DOWN) {
        /* Interface appears to have come down successfully */
        interface->status = current_status;
      } else if (current_status == INT_UP) {
	 interface->status = current_status;
      }
    break;
  }
}

void
show_interface_status(Interface *interface)
{
  switch (interface->status) {
  case INT_DOWN:
    gtk_widget_set_name(interface->status_button, "interface_down");
    break;
  case INT_GOING_DOWN:
  case INT_GOING_UP:
    gtk_widget_set_name(interface->status_button, "interface_changing");
    break;
  case INT_UP:
    gtk_widget_set_name(interface->status_button, "interface_up");
    break;
  }
}

void
update_and_show_interface_status(Interface *interface)
{
  update_interface_status(interface);
  show_interface_status(interface);
}

void
update_interface_status_on_signal(int signum)
{
  g_slist_foreach(GL_interface_list,
                  (GFunc) update_and_show_interface_status,
                  NULL);
}

void
run_usernetctl(const gchar *name, const gchar *to_status)
{
  gchar *argv[3];
  gchar namebuffer[32];
  gchar argbuffer[32];

  /* ifup/down are now responsible for running usernetctl if
   * necessary.
   */
  sprintf (namebuffer, "/sbin/if%s", to_status);
  sprintf (argbuffer, "ifcfg-%s", name);

  argv[0] = namebuffer;
  argv[1] = argbuffer;
  argv[2] = (gchar *)NULL;

  fork_fork_exec(argv);
}

void
change_interface_status_by_name(Interface *interface, gchar *name)
{
  update_interface_status(interface);
  switch (interface->status) {
  case INT_GOING_DOWN:
    /* If the interface is going down, I'm not sure we should
     * immediately try to bring it back up.  I'd rather make the user
     * wait until it comes down and try again.  We'll see what users
     * say on this point.
     */
    return;
    break;
  case INT_DOWN:
    interface->status = INT_GOING_UP;
    run_usernetctl(name, "up");
    show_interface_status(interface);
    break;
  case INT_GOING_UP:
    /* In practice, I've found that I want to bring things down as they
     * are coming up.
     * Fall through to the INT_UP state to bring the interface down.
     */
  case INT_UP:
    interface->status = INT_GOING_DOWN;
    /* if this interface has multiple phone numbers associated with it,
     * bring up a menu asking which phone number to call.
     */
    run_usernetctl(name, "down");
    show_interface_status(interface);
    break;
  }
}

void
change_interface_status(Interface *interface)
{
  change_interface_status_by_name(interface, interface->name);
}

void
change_clone_status(Clone *clone)
{
  change_interface_status_by_name(clone->interface, clone->name);
}

Interface *
create_new_interface(const gchar *name) {
  Interface *interface;

  interface = g_malloc0(sizeof(Interface));
  interface->name = g_strdup(name);

  interface->toggle_button = gtk_button_new_with_label(interface->name);
  gtk_widget_set_name(interface->toggle_button, interface->name);
  gtk_widget_set_usize(interface->toggle_button, 50, 40);
  gtk_signal_connect_object (GTK_OBJECT (interface->toggle_button), "clicked",
			     GTK_SIGNAL_FUNC (change_interface_status),
			     (gpointer) interface);

  interface->status_button = gtk_button_new();
  gtk_signal_connect_object (GTK_OBJECT (interface->status_button), "clicked",
			     GTK_SIGNAL_FUNC (update_and_show_interface_status),
			     (gpointer) interface);
  update_interface_status(interface);
  show_interface_status(interface);
  gtk_widget_show(interface->toggle_button);
  gtk_widget_show(interface->status_button);

  return interface;
}

Clone *
create_new_clone(const gchar *name, Interface *interface) {
  Clone *clone;

  clone = g_malloc0(sizeof(Clone));
  clone->name = g_strdup(name);
  clone->interface = interface;

  return clone;
}



GSList *
create_interface_list()
{
  gchar buffer[64];
  gchar *p;
  GSList *interface_list = NULL;
  FILE *list_command;
  int regtmp;
  regex_t clone_ex;
  regmatch_t clone_match;
  int cloned_len;
  char *cloned_name;
  GSList *il;
  Interface *cloned_interface;

  /* prepare to evaluate names for clone-ness, and find their original name */
  if (regtmp = regcomp(&clone_ex, "^\\([^-][^-]*\\)-", 0)) {
      gtk_warning_dialog(GL_top, "Internal error: regcmp failed");
      exit(1);
  }


  if (getuid()) {
    /* running as a normal user */

    /* This is a disgusting shell invocation, but it is a lot easier than
     * writing the equivalent C code...  It prints a list of all interface
     * names (minus the ifcfg- part) which are user-controllable.
     *
     * The sort invocation causes the real interfaces to be listed before
     * their clone devices, an invariant the rest of the code uses.
     *
     * Note that this is NOT a security hole, because this program
     * does NOT run setuid root.
     */
    list_command = popen (
	  "cd /etc/sysconfig/network-scripts; "
	  "for interface in $(ls ifcfg-* | egrep -v '~$|.bak~|.rpm(save|orig)' | sort) ; do "
	  "  if /usr/sbin/usernetctl $interface report ; then "
	  "    echo $interface | sed 's/^ifcfg-//' ;"
	  "  fi ; "
	  "done",
      "r");
  } else {
    /* running as root, list all interfaces */
    list_command = popen (
	  "cd /etc/sysconfig/network-scripts; "
	  "for interface in $(ls ifcfg-* | "
	       "egrep -v '~$|.bak~|.rpm(save|orig)' | sort) ; do "
	     "echo $interface | sed 's/^ifcfg-//' ;"
	  "done",
      "r");
  }

  while (fgets(buffer, 64, list_command)) {
    /* if any interface names are longer than 64 characters, give up
     * with an error message.
     */
    if (p = strchr(buffer, '\n')) {
      *p = '\0';
    } else {
      gtk_warning_dialog(GL_top,
	"Error parsing interface list at \"%s\": name too long.", buffer);
      pclose(list_command);
      regfree(&clone_ex);
      return interface_list;
    }


    if ((regtmp = regexec(&clone_ex, buffer, 1, &clone_match, 0))
	== REG_NOMATCH) {
      /* Must be a real interface.
       * create_new_interface g_strdup's the data
       */
      interface_list = g_slist_append(interface_list,
                                      create_new_interface(buffer));
    } else {
      /* Must be a clone -- add it to the correct list */
      cloned_len = clone_match.rm_eo - clone_match.rm_so;
      cloned_name = g_malloc0(cloned_len);
      /* careful not to copy the `-' between cloned_name and clone name */
      strncpy(cloned_name, &buffer[clone_match.rm_so], cloned_len-1);

      il = interface_list;
      while (il && il->data) {
        cloned_interface = (Interface *) il->data;
	if (! strcmp(cloned_name, cloned_interface->name)) {
	  cloned_interface->clone_list = g_slist_append(
	    cloned_interface->clone_list,
	    create_new_clone(buffer, cloned_interface));
	  break;
	}
        il = il->next;
      }
      if (!il) {
	/* The base interface is not controllable. */
	/* FIXME: figure out what to do in this case. */
      }

      g_free(cloned_name);
    }
  }

  if (!interface_list) {
    gtk_warning_dialog(GL_top, "No user-controllable interfaces found.");
    exit (1);
  }

  pclose(list_command);
  regfree(&clone_ex);

  return interface_list;
}




static gint
popup_interface_menu (GtkWidget *widget, GdkEvent *event)
{
  GSList *i_list;
  Interface *interface;
  GdkEventButton *bevent;

  if (event->type == GDK_BUTTON_PRESS) {

    /* first of all, we need to find out whether we want to handle
     * events on this button at this time
     */
    i_list = GL_interface_list;
    while (i_list) {
      interface = (Interface *)i_list->data;
      if (gtk_object_get_user_data(GTK_OBJECT(widget))
          == (gpointer) interface) {
	update_interface_status(interface);
	if (interface->status != INT_DOWN) {
	  /* interface isn't down; let the default handling happen */
	  return FALSE;
	}
	/* We want to fall through and post a menu, since the interface
	 * is down.
	 */
	
	/* we've found the widget; don't go any further */
	i_list = NULL;
      } else {
	i_list = i_list->next;
      }
    }
    
    bevent = (GdkEventButton *) event;
    gtk_menu_popup (GTK_MENU(widget), NULL, NULL, NULL, NULL,
                    bevent->button, bevent->time);
    /* Tell calling code that we have handled this event; the buck
     * stops here. */
    return TRUE;
  }

  /* Tell calling code that we have not handled this event; pass it on. */
  return FALSE;
}

GtkWidget *
create_net_table(GtkWidget *parent)
{
  GtkWidget *table;
  GtkWidget *toggle_label;
  GtkWidget *status_label;
  GtkWidget *menu;
  GtkWidget *menuitem;
  GSList    *interface_list,
	    *this_item,
	    *clone_list;
  Interface *interface;

  int i;


  interface_list = create_interface_list ();
  /* give signal handler access to the list */
  GL_interface_list = interface_list;

  table = gtk_table_new (g_slist_length(interface_list)+1, 2, FALSE);
  gtk_table_set_row_spacings (GTK_TABLE(table), 2);
  gtk_table_set_col_spacings (GTK_TABLE(table), 2);

  toggle_label = make_vbox_of_labels ("Toggle\ninterface");
  status_label = make_vbox_of_labels ("Status\ninfo");

  table_attach_at (table, toggle_label, 0, 0);
  table_attach_at (table, status_label, 1, 0);

  for(this_item = interface_list, i=1;
      this_item;
      this_item = this_item->next, i++) {

    interface = (Interface *)this_item->data;
    if (interface->clone_list) {
      menu = gtk_menu_new();
      menuitem = gtk_menu_item_new_with_label(interface->name);
      gtk_menu_append(GTK_MENU (menu), menuitem);
      gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
          GTK_SIGNAL_FUNC(change_interface_status), (gpointer) interface);
      gtk_widget_show(menuitem);

      for (clone_list = interface->clone_list;
           clone_list;
           clone_list = clone_list->next) {
        Clone *clone = (Clone *)clone_list->data;

	menuitem = gtk_menu_item_new_with_label(clone->name);
	gtk_menu_append(GTK_MENU (menu), menuitem);
	gtk_signal_connect_object(GTK_OBJECT(menuitem), "activate",
            GTK_SIGNAL_FUNC(change_clone_status), (gpointer) clone);

	gtk_widget_show(menuitem);
      }

      gtk_object_set_user_data(GTK_OBJECT(menu),
			       (gpointer) interface);
      gtk_signal_connect_object(GTK_OBJECT(interface->toggle_button), "event",
        GTK_SIGNAL_FUNC (popup_interface_menu), GTK_OBJECT(menu));
    }

    table_attach_at (table, interface->toggle_button, 0, i);
    table_attach_at (table, interface->status_button, 1, i);
  }

  widget_show_all (toggle_label, status_label,
		   0);

  return table;
}



int
main (int argc, char *argv[])
{
  GtkWidget *window;
  GtkWidget *box;
  GtkWidget *scrolled_window;
  GtkWidget *table;
  GtkWidget *sep;
  GtkWidget *exit_button;
  struct sigaction sa;
  int table_length;

  gtk_init (&argc, &argv);
  gtk_rc_parse ("/usr/share/usernet/" VERSION "/usernetrc");


  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_signal_connect (GTK_OBJECT (window), "destroy",
		      GTK_SIGNAL_FUNC (destroy), NULL);
  gtk_signal_connect (GTK_OBJECT (window), "delete_event",
		      GTK_SIGNAL_FUNC (delete), NULL);
  gtk_container_border_width (GTK_CONTAINER (window), 5);
  gtk_window_set_title(GTK_WINDOW(window), "UserNet");

  box = gtk_vbox_new (FALSE, 0);

  scrolled_window = gtk_scrolled_window_new (NULL, NULL);
  gtk_container_border_width (GTK_CONTAINER (scrolled_window), 5);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_window),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

  table = create_net_table(scrolled_window);

  /* resize the window to hold the right number of items in the table,
   * up to three.
   */
  table_length = g_slist_length(GL_interface_list);
  if (table_length > 3) table_length = 3;
  gtk_widget_set_usize(scrolled_window, 130, 50 + 50 * table_length);

  gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW (scrolled_window),
					table);

  /* put signal handler in place for device event notification */
  memset(&sa, 0, sizeof(sa));
  sa.sa_handler = update_interface_status_on_signal;
  if (sigaction(SIGIO, &sa, NULL)) {
    gtk_warning_dialog(GL_top, "Device change notification inactive");
    exit (1);
  }

  /* write notification file */
  if (fork_exec("/sbin/netreport", NULL)) {
    gtk_warning_dialog(GL_top,
	"Device change notification inactive because netreport failed");
    exit (1);
  }

  sep = gtk_hseparator_new();

  exit_button = gtk_button_new_with_label("Exit");
  gtk_signal_connect_object (GTK_OBJECT (exit_button), "clicked",
				GTK_SIGNAL_FUNC (gtk_widget_destroy),
				GTK_OBJECT (window));
  
  gtk_container_add (GTK_CONTAINER (window), box);
  gtk_box_pack_start (GTK_BOX (box), scrolled_window, TRUE, TRUE, 2);
  gtk_box_pack_end (GTK_BOX (box), exit_button, FALSE, FALSE, 2);
  gtk_box_pack_end (GTK_BOX (box), sep, FALSE, FALSE, 2);

  widget_show_all(exit_button, sep, table, scrolled_window, box, window, 0);

  GL_top = 0;
  gtk_main ();

  return 0;
}
