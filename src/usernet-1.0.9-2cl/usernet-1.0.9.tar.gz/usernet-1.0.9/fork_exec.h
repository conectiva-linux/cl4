#ifndef FORK_EXEC_H
#define FORK_EXEC_H
int fork_exec(char *path, char *arg);
int fork_fork_exec(char **arg);
#endif /* FORK_EXEC_H */
