/*
 * Copyright (C) 1997 Red Hat Software, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#include <stdarg.h>
#include <string.h>
#include "gtkextras.h"


/* When you are too lazy to type gtk_widget_show a million times...
 * The list MUST be terminated with a 0 or random segvs will happen
 * at random times (sometimes things will just work...)
 */
void
widget_show_all(GtkWidget *first, ...)
{
  va_list ap;
  GtkWidget *more;

  va_start(ap, first);
  gtk_widget_show(first);
  while (more = va_arg(ap, GtkWidget *))
  {
    gtk_widget_show(more);
  }
  va_end(ap);
}


void
table_attach_at(GtkWidget *table, GtkWidget *wid, int r, int c)
{
  gtk_table_attach (GTK_TABLE (table), wid, r, r+1, c, c+1,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
}


/* make_vbox_of_labels creates a vbox stuffed with centered, non-expanded
 * labels.  It splits its labels argument on \n characters to create the
 * labels in the boxes.
 */
GtkWidget *
make_vbox_of_labels(char *labels)
{
  char *local_labels, *p;
  GtkWidget *vbox;
  GtkWidget *label;

  local_labels = g_strdup(labels);

  vbox = gtk_vbox_new(FALSE, 0);

  while (p = strrchr(local_labels, '\n'))
  {
    /* ++ ignores the \n; -- later backs up to delete it */
    label = gtk_label_new(++p);
    gtk_box_pack_end (GTK_BOX (vbox), label, FALSE, FALSE, 0);
    gtk_widget_show(label);
    *--p = '\0';
  }

  label = gtk_label_new(local_labels);
  gtk_box_pack_end (GTK_BOX (vbox), label, FALSE, FALSE, 0);
  gtk_widget_show(label);

  g_free(local_labels);

  return vbox;
}


/* gtk_warning_dialog puts up a modal dialog with a warning */
void
gtk_warning_dialog(gint run_main_loop, gchar *string, ...)
{
  va_list ap;
  /* warnings should not be more than 1024 characters -- that is
   * 12 full lines of text, after all...
   */
  gchar buffer[1024];
  GtkDialog *dialog;
  GtkWidget *label;
  GtkWidget *button;


  va_start(ap, string);
  vsnprintf(buffer, 1024, string, ap);
  va_end(ap);


  dialog = GTK_DIALOG(gtk_dialog_new());

  gtk_window_set_title(GTK_WINDOW(dialog), "Warning");
  /* the following is a hack until we have a proper text display widget
   * besides a label
   */
  gtk_widget_set_usize (GTK_WIDGET(dialog), 400, 150);
  label = gtk_label_new(buffer);
  gtk_box_pack_start(GTK_BOX(dialog->vbox), label, TRUE, TRUE, 0);
  gtk_widget_show (label);

  button = gtk_button_new_with_label ("close");
  if (run_main_loop) {
    gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                               GTK_SIGNAL_FUNC (gtk_exit),
                               GTK_OBJECT (0));
  } else {
    gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                               GTK_SIGNAL_FUNC (gtk_widget_destroy),
                               GTK_OBJECT (dialog));
  }
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->action_area), button, TRUE, TRUE, 0);
  gtk_widget_grab_default (GTK_WIDGET(button));
  gtk_widget_show (GTK_WIDGET(button));
  gtk_widget_show (GTK_WIDGET(dialog));

  if (run_main_loop) gtk_main();

}

