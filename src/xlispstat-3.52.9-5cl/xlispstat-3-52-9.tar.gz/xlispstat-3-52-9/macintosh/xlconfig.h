#define ANSI
#define IEEEFP
#define ADEPTH 8000
#define EDEPTH 8000
#define IEEEFP
#define STSZ 6 * 32768
#ifndef EACCES
#  define EACCES 13 /* value probably doesn't matter as long as it's not 0 or 1 */
#endif
#ifdef powerc
#  define HAVE_DLOPEN 1
#  define SHAREDLIBS
#else
#  define HAVE_DLOPEN 0
#endif
