  /*  This file is included by xosview.cc, to set up the version
   *  string.  */
static const char * const versionString = "xosview version 1.6.1";
static const char * const version_cc_cvsID = "$Id: version.cc,v 1.8 1998/05/29 21:34:37 bgrayson Exp $";
