#! /bin/sh
PATH=.:$PATH
size=$1
from=$2
dopkbm1.sh $size $from 0 p o
dopkbm1.sh $size $from 1 n o
dopkbm1.sh $size $from 2 b o
dopkbm1.sh $size $from 3 r o
dopkbm1.sh $size $from 4 q o
dopkbm1.sh $size $from 5 k o
dopkbm1.sh $size $from 014 p s
dopkbm1.sh $size $from 015 n s
dopkbm1.sh $size $from 016 b s
dopkbm1.sh $size $from 017 r s
dopkbm1.sh $size $from 020 q s
dopkbm1.sh $size $from 021 k s
