char * mgetty_version = "experimental test release 1.1.14-Apr02";
