char *vgetty_version = "experimental test release 0.8.1 / 25Mar98";
