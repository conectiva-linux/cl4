/*
 * variables.c
 *
 * Just defines necessary global variables.
 *
 * $Id: variables.c,v 1.1 1998/03/25 23:14:08 marc Exp $
 *
 */

#include "../include/voice.h"
#include "../include/version.h"

char POS[80];
