char gStrnLibVersion[20] = "@(#) Strn 2.1.0";
