/* FTP.h
 *
 * Copyright (c) 1996 Mike Gleason, NCEMRSoft.
 * All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF NCEMRSOFT.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

/* FTP.c */
void MyInetAddr(char *, size_t, char **, int);
int GetOurHostName(char *, size_t);
void CloseControlConnection(const FTPCIPtr);
int SetKeepAlive(const FTPCIPtr, int);
int SetLinger(const FTPCIPtr, int, int);
int SetTypeOfService(const FTPCIPtr, int, int);
int SetInlineOutOfBandData(const FTPCIPtr, int);
int OpenControlConnection(const FTPCIPtr, char *, unsigned int);
void CloseDataConnection(const FTPCIPtr);
int SetStartOffset(const FTPCIPtr, longest_int);
int OpenDataConnection(const FTPCIPtr, int);
int AcceptDataConnection(const FTPCIPtr);
void HangupOnServer(const FTPCIPtr);
void SendTelnetInterrupt(const FTPCIPtr);
