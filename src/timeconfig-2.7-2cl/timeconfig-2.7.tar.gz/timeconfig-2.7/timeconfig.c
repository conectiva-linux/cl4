/*
  ChangeLog:
  1998/11/15 - Arnaldo Carvalho de Melo <acme@conectiva.com.br>
             - timezones internationalized
*/
#include <ctype.h>
#include <errno.h>
#include <newt.h>
#include <popt.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <libintl.h> 
#include <locale.h> 

#define _(String) gettext((String)) 

#ifdef __alpha__
#define SUPPORT_ARC
#endif

struct clockMode {
    int isUtc;
    int isArc;
};

static char * progName;

/* reads /etc/sysconfig/clock, which just has CLOCKMODE=<GMT|ARC|other> */
/* double quotes are stripped, #'s denote comments */

static int getTimeConfig(struct clockMode * modeptr, int useBack,
			 char ** tzpath) {
    newtComponent form, okay, cancel, listbox;
    newtComponent gmtCheck, arcCheck = NULL, answer;
    newtGrid grid, buttons;
    FILE * f;
    char buf[255];
    char * start, * end;
    int num = 0;
    int rc, i;
    char isUtc, isArc = ' ';

    form = newtForm(NULL, NULL, 0);

    gmtCheck = newtCheckbox(-1, -1, _("Hardware clock set to GMT"), 
				modeptr->isUtc ? '*' : ' ', NULL,
				&isUtc);
#ifdef SUPPORT_ARC
    arcCheck = newtCheckbox(-1, -1, _("Startup through ARC console"),
				modeptr->isArc ? '*' : ' ', NULL,
				&isArc);
				
#endif

    listbox = newtListbox(-1, -1, 6, NEWT_FLAG_SCROLL);

    f = popen("cd /usr/share/zoneinfo; find . -type f -or -type l | "
		"grep '^./[A-Z]' | sort", "r");
    if (!f) {
	*tzpath = _("cannot scan /usr/share/zoneinfo for timezones");
	return -1;
    }
    while (fgets(buf, sizeof(buf) - 1, f)) {
	start = buf + 2;
	end = strlen(start) + start - 1;
	*end = '\0';
	
	start = strdup(start);
	newtListboxAddEntry(listbox, _(start), start);

	if (*tzpath && !strcmp(start, *tzpath)) {
	    newtListboxSetCurrent(listbox, num);
	}

	num++;
    }

    fclose(f);

    buttons = newtButtonBar(_("Ok"), &okay, 
			    useBack ? _("Back") : _("Cancel"), &cancel, NULL);

    grid = newtCreateGrid(1, arcCheck ? 5 : 4);
    i = 0;
    newtGridSetField(grid, 0, i++, NEWT_GRID_COMPONENT, 
		     newtLabel(-1, -1, _("Format machine time is stored in:")),
		     0, 0, 0, 0, NEWT_ANCHOR_LEFT, 0);
    newtGridSetField(grid, 0, i++, NEWT_GRID_COMPONENT, gmtCheck,
		     0, 1, 0, 0, NEWT_ANCHOR_LEFT, 0);
    if (arcCheck)
	newtGridSetField(grid, 0, i++, NEWT_GRID_COMPONENT, arcCheck,
			 0, 0, 0, 0, NEWT_ANCHOR_LEFT, 0);
    newtGridSetField(grid, 0, i++, NEWT_GRID_COMPONENT, listbox,
		     0, 1, 0, 0, 0, 0);
    newtGridSetField(grid, 0, i++, NEWT_GRID_SUBGRID, buttons,
		     0, 1, 0, 0, 0, NEWT_GRID_FLAG_GROWX);
    newtGridAddComponentsToForm(grid, form, 1);

   
    newtGridWrappedWindow(grid, _("Configure Timezones"));
    newtGridFree(grid, 1);

    answer = newtRunForm(form);

    if (answer == cancel) {
	*tzpath = NULL;
	rc = 1;
    } else {
	*tzpath = newtListboxGetCurrent(listbox);
	rc = 0;

	modeptr->isUtc = isUtc != ' ';
	modeptr->isArc = isArc != ' ';
    }
 
    newtFormDestroy(form);
    newtPopWindow();

    return rc;
}

int removeQuotes(char ** startptr, char ** endptr, int line) {
    char * start = *startptr;
    char * end = *endptr;

    if (*start == '"' && *end != '"') {
	fprintf(stderr, _("%s: mismatched quotes on line %d in /etc/sysconfig/clock\n"), 
				progName, line);
	return 1;
    } else if (*start == '"') {
	start++;
	*end = '\0';
	end--;
    }

    *startptr = start;
    *endptr = end;

    return 0;
}

static int readConfigFile(struct clockMode * modeptr) {
    FILE * f;
    char * start, * end;
    char buf[250];
    int line = 0;

    modeptr->isUtc = modeptr->isArc = 0;

    f = fopen("/etc/sysconfig/clock", "r");
    if (!f) {
	if (errno == ENOENT) {
	    return 0;
	}

	fprintf(stderr, _("%s: cannot open /etc/sysconfig/clock: %s\n"),
		progName, strerror(errno));
	return 1;
    }

    while (errno = 0, fgets(buf, sizeof(buf) - 1, f)) {
	line++;

	start = buf;

	/* skipping leading spaces */
	while (*start && isspace(*start)) start++;
	if (!*start) continue;

	/* skip comments */
	if (*start == '#') continue;

	/* cut off trailing spaces and \n */
	end = start + strlen(start) - 2;
	while (isspace(*end)) end--;
	end++;
	*end = '\0';	
	end--;
	
	if (!strncmp("CLOCKMODE=", start, 10)) {
	    /* Red Hat 4.0 and earlier did this */
	    start += 10;
	    if (removeQuotes(&start, &end, line)) return 1;
	    if (!strcmp(start, "GMT")) {
		modeptr->isArc = 0;
		modeptr->isUtc = 1;
	    } else if (!strcmp(start, "ARC")) {
		modeptr->isArc = 1;
		modeptr->isUtc = 0;
	    } else {
		modeptr->isArc = 0;
		modeptr->isUtc = 0;
	    }
	} else if (!strncmp("UTC=", start, 4)) {
	    start += 4;
	    if (removeQuotes(&start, &end, line)) return 1;
	    if (!strcasecmp(start, "true") || 
				!strcasecmp(start, "yes") ||
		!strcasecmp(start, "1"))
		modeptr->isUtc = 1;
	    else 
		modeptr->isUtc = 0;
	} else if (!strncmp("ARC=", start, 4)) {
	    /* accept the ARC variable on non-Alpha machines, but just 
	       preserve it */
	    start += 4;
	    if (removeQuotes(&start, &end, line)) return 1;
	    if (!strcasecmp(start, "true") 
			|| !strcasecmp(start, "yes") ||
		!strcasecmp(start, "1"))
		modeptr->isArc = 1;
	    else 
		modeptr->isArc = 0;
	} else {
	    fprintf(stderr, 
		_("%s: line %d unexpected in /etc/sysconfig/clock:\n"),
		    progName, line);
	    fclose(f);
	    return 1;
	}
    }

    if (errno) {
	fprintf(stderr, 
		_("%s: cannot read /etc/sysconfig/clock: %s\n"),
		progName, strerror(errno));
    }

    return 0;
}

int main(int argc, char ** argv) {
    struct clockMode mode = { 0, 0 };
    char buf[1024];
    char * timezone;
    int i;
    FILE * f;
    poptContext optCon;
    int utc = 0;
    int arc = 0;
    int rc;
    int back = 0;
    int test = 0;
    char * tz;
    struct poptOption options[] = {
#if defined(SUPPORT_ARC)
            { "arc", '\0', POPT_ARG_STRING, &arc, 0 },
#endif
            { "back", '\0', 0, &back, 0 },
            { "test", '\0', 0, &test, 0 },
            { "utc", '\0', 0, &utc, 0 },
            { 0, 0, 0, 0, 0 }
        };

    setlocale(LC_ALL, ""); 
    bindtextdomain("timeconfig","/usr/share/locale"); 
    textdomain("timeconfig"); 

    progName = argv[0];

    optCon = poptGetContext("timeconfig", argc, argv, options,0);
    poptReadDefaultConfig(optCon, 1);

    if ((rc = poptGetNextOpt(optCon)) < -1) {
	fprintf(stderr, _("%s: bad argument %s: %s\n"), progName,
		poptBadOption(optCon, POPT_BADOPTION_NOALIAS), 
		poptStrerror(rc));
	return 2;
    }

    timezone = poptGetArg(optCon);
    if (timezone && poptGetArg(optCon)) {
	sprintf(_("%s: only one argument (the timezone) may be used\n"),
		 progName);
	return 2;
    }

    poptFreeContext(optCon);

    if (!test && getuid()) {
	fprintf(stderr, _("%s: can only be run as root\n"),
		progName);
	exit(2);
    }

    if (readConfigFile(&mode)) {
	fprintf(stderr, _("%s: critical error reading /etc/sysconfig/clock"),
		progName);
	exit(2);
    }

    if (utc) mode.isUtc = 1;
    if (arc) mode.isArc = 1;

    if (!timezone) {
	if ((i = readlink("/etc/localtime", buf, sizeof(buf) - 1)) < 0) {
	    if (errno == ENOENT)
		strcpy(buf, "zoneinfo/US/Eastern");
	    else {
   	     fprintf(stderr, 
	      _("%s: critical error reading /etc/localtime: %s\n"),
			progName, strerror(errno));
		exit(2);
	    }
	}

	buf[i] = '\0';
	timezone = strstr(buf, "zoneinfo/");
	if (!timezone) {
	  fprintf(stderr, _("%s: /etc/localtime points to unknown timezone %s\n"), progName, buf);
	    fprintf(stderr,_("%s: current value will be ignored\n"),
				progName);
	    sleep(1);
	    timezone = NULL;
	} else {
	    timezone += 9;
	}

	newtInit();
	newtCls();

	newtPushHelpLine(_("  <Tab>/<Alt-Tab> between elements  |  <Space> selects |  <F12> next screen"));
	newtDrawRootText(0, 0, "timeconfig " VERSION " - (C) 1999 Red Hat " 
					"Software");
	
	if (getTimeConfig(&mode, back, &timezone)) {
	    /* cancelled */
	    newtFinished();

	    if (timezone) {
		fprintf(stderr, "%s: %s\n", progName, timezone);
		exit(2);
	    }

	    exit(1);
	}

	newtFinished();
    }

    unlink("/etc/localtime");
    strcpy(buf, "../usr/share/zoneinfo/");
    strcat(buf, timezone);

    if (!test) {
	if (symlink(buf, "/etc/localtime")) {
	    fprintf(stderr, _("%s: failed to make /etc/localtime: %s"),
		    progName,strerror(errno));
	    exit(2);
	}
			    
	f = fopen("/etc/sysconfig/clock", "w");
	if (!f) {
	    fprintf(stderr, 
		    _("%s: failed to make /etc/sysconfig/clock: %s"),
			    progName,strerror(errno));
	    exit(2);
	}

	if (mode.isUtc)
	    strcpy(buf, "UTC=true\n");
	else
	    strcpy(buf, "UTC=false\n");

	if (mode.isArc)
	    strcat(buf, "ARC=true\n");
	else
	    strcat(buf, "ARC=false\n");

	if (fputs(buf, f) < 0) {
	    fprintf(stderr, 
		_("%s: failed to write to /etc/sysconfig/clock: %s"), 
		    progName, strerror(errno));
	    unlink("/etc/sysconfig/clock");
	    exit(2);
	}

	fclose(f);
    }

    return 0;
}
