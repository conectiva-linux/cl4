#ifdef DEBUG
#include <stdio.h>
#include <fcntl.h>

extern FILE *__dbf;
#endif
