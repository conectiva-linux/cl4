/*
 *  linux/ibcs/socket.h
 *
 *  Copyright (C) 1994  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 * $Id: socket.h,v 1.2 1998/06/24 20:34:21 jaggy Exp $
 * $Source: /u/CVS/ibcs/include/ibcs/socket.h,v $
 */

/* Linux spells this differently. */
#define SO_ACCEPTCONN	SO_ACCEPTCON

/* These aren't (currently) defined by Linux. Watch out for warnings
 * about redefinitions...
 */
#define SO_USELOOPBACK	0xff02
#define SO_ORDREL	0xff03
#define SO_IMASOCKET	0xff04
#define SO_PROTOTYPE	0xff09
