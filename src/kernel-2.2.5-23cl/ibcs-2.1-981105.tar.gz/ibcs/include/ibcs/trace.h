/*
 * ibcs trace -- mask of trace values
 *
 * $Id: trace.h,v 1.10 1998/02/02 23:02:52 jaggy Exp $
 * $Source: /u/CVS/ibcs/include/ibcs/trace.h,v $
 */
#include <ibcs/traceflags.h>

extern int ibcs_trace;
extern IBCS_func *ibcs_func_p;

extern int ibcs_trace_set(int arg);
extern int ibcs_trace_func(unsigned int per, int func, int val);
