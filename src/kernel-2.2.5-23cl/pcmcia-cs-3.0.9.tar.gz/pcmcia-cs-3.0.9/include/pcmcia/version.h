/* version.h 1.55 1998/02/25 22:21:07 (David Hinds) */

#define CS_RELEASE "3.0.9"
#define CS_RELEASE_CODE 0x3009
