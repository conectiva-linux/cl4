#ifndef H_VERSION
#define H_VERSION

#include "common.h"

int getMdVersion(struct md_version * ver);

#endif
