/* Define if you're md header files which include md_minor */
#undef HAVE_MD_MINOR

/* Define if you're using RAID w/ support for RAID 10, 4, and 5 */
#undef HAVE_RAID1
