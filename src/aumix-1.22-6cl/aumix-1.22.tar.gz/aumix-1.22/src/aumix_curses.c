#ifdef HAVE_LIBNCURSES
#include "aumix.h"
#include "aumix_curses.h"

WINDOW *w_keys;
WINDOW *w_panel;

char *chark, *charl, *charm, *charo, *charq, *chars, *charu;

void InitScreen()
{
	int i, y = 0;
	w_panel = newwin(LINES - 1, COLS, 0, 0);
	wclear(w_panel);
	wattrset(w_panel, COLOR_PAIR(MENU_COLOR));
	wmove(w_panel, 2, 1);
	waddstr(w_panel, (char *) LOCAL_TEXT("uit "));
	wmove(w_panel, 3, 1);
	waddstr(w_panel, (char *) LOCAL_TEXT("oad "));
	wmove(w_panel, 4, 1);
	waddstr(w_panel, (char *) LOCAL_TEXT("ave "));
	wmove(w_panel, 5, 1);
	waddstr(w_panel, (char *) LOCAL_TEXT("eys "));
	wmove(w_panel, 6, 1);
	waddstr(w_panel, (char *) LOCAL_TEXT("ute "));
	wmove(w_panel, 7, 1);
	waddstr(w_panel, (char *) LOCAL_TEXT("nly "));
	wmove(w_panel, 8, 1);
	waddstr(w_panel, (char *) LOCAL_TEXT("ndo "));
	wattrset(w_panel, COLOR_PAIR(MENU_COLOR) | A_UNDERLINE);
	wmove(w_panel, 0, 0);
	waddstr(w_panel, "aumix");
	wattrset(w_panel, COLOR_PAIR(HOTKEY_COLOR) | A_BOLD);
	wmove(w_panel, 2, 0);
	waddstr(w_panel, (char *) LOCAL_TEXT("Q"));
	wmove(w_panel, 3, 0);
	waddstr(w_panel, (char *) LOCAL_TEXT("L"));
	wmove(w_panel, 4, 0);
	waddstr(w_panel, (char *) LOCAL_TEXT("S"));
	wmove(w_panel, 5, 0);
	waddstr(w_panel, (char *) LOCAL_TEXT("K"));
	wmove(w_panel, 6, 0);
	waddstr(w_panel, (char *) LOCAL_TEXT("M"));
	wmove(w_panel, 7, 0);
	waddstr(w_panel, (char *) LOCAL_TEXT("O"));
	wmove(w_panel, 8, 0);
	waddstr(w_panel, (char *) LOCAL_TEXT("U"));
	wattrset(w_panel, COLOR_PAIR(AXIS_COLOR));
	for (i = 0; i < SOUND_MIXER_NRDEVICES; i++) {	/* total existing channels */
		if (devmask & (1 << i))
			y++;
	}
	if (YOFFSET + y <= LINES) {
		wmove(w_panel, YOFFSET + y, XOFFSET + 1);
		waddstr(w_panel, (char *) LOCAL_TEXT("0             Level            100          L         Balance        R"));
	}
	y = 0;			/* Now recycle it for a different use. */
	for (i = 0; i < SOUND_MIXER_NRDEVICES; i++) {
		if ((1 << i) & devmask) {
			wattrset(w_panel, COLOR_PAIR(AXIS_COLOR));
			/* draw control labels */
			wmove(w_panel, YOFFSET + y++, XOFFSET + 36);	/* devices really existing */
			waddstr(w_panel, dev_label[i]);
		}
	}
	refresh();
	wrefresh(w_panel);
	RefreshAllSettings();
}

void KeysBox(void)
{
	alarm(100000000);	/* Give user time to read screen. */
	w_keys = newwin(LINES, COLS, 0, 0);
	wclear(w_keys);
	wattrset(w_keys, COLOR_PAIR(AXIS_COLOR));
	wmove(w_keys, 3, 0);
	waddstr(w_keys, (char *) LOCAL_TEXT("page arrows\n"));
	waddstr(w_keys, (char *) LOCAL_TEXT("tab enter < > , .\n"));
	waddstr(w_keys, (char *) LOCAL_TEXT("+ - [ ] arrows digits\n"));
	waddstr(w_keys, (char *) LOCAL_TEXT("space\n"));
	waddstr(w_keys, (char *) LOCAL_TEXT("|\n"));
	wprintw(w_keys, (char *) LOCAL_TEXT("\nPress a key to resume."));
	wmove(w_keys, 1, 0);
	wprintw(w_keys, (char *) LOCAL_TEXT("Key                       Function\n"));
	wprintw(w_keys, (char *) LOCAL_TEXT("------------------------- --------------------"));
	wmove(w_keys, 3, 26);
	waddstr(w_keys, (char *) LOCAL_TEXT("change channel\n"));
	wmove(w_keys, 4, 26);
	waddstr(w_keys, (char *) LOCAL_TEXT("toggle level/balance\n"));
	wmove(w_keys, 5, 26);
	waddstr(w_keys, (char *) LOCAL_TEXT("adjust slider\n"));
	wmove(w_keys, 6, 26);
	waddstr(w_keys, (char *) LOCAL_TEXT("toggle record/play\n"));
	wmove(w_keys, 7, 26);
	waddstr(w_keys, (char *) LOCAL_TEXT("center balance\n"));
	wrefresh(w_keys);

#if HAVE_LIBGPM
	Gpm_Wgetch(w_keys);
#else
	getch();
#endif
	alarm(REFRESH_PERIOD);
	InitScreen();
}

void RefreshAllSettings(void)
{
	int dev;
	for (dev = 0; dev < SOUND_MIXER_NRDEVICES; dev++) {
		if ((1 << dev) & devmask) {
			EraseLevel(dev);
			RedrawBalance(dev);
			wattrset(w_panel, COLOR_PAIR(HANDLE_COLOR));
			DrawLevel(dev);
			/* print record/play indicators */
			if ((1 << dev) & recmask)
				DrawRecordPlay(dev);
		}
	}
	wrefresh(w_panel);
}

void RefreshNewSettings(void)
/* Periodically redraws the screen, in case another process has changed the
   mixer settings. */
{
	int dev, i = 0;
	for (dev = 0; dev < SOUND_MIXER_NRDEVICES; dev++) {
		if ((1 << dev) & devmask) {
			if (ioctl(mixer_fd, MIXER_READ(dev), &i) == -1) {
				perror("MIXER_READ");
				exit(EXIT_FAILURE);	/* xxx We should close the screen first. */
			}
/* record/play indicators */
			if ((1 << dev) & recmask) {
				if (ioctl(mixer_fd, SOUND_MIXER_READ_RECSRC, &recsrc) == -1) {
					perror("SOUND_MIXER_READ_RECSRC");
					exit(EXIT_FAILURE);
				}
/* Redraw if the setting changed. */
				if (our_recplay[dev] - recsrc)
					DrawRecordPlay(dev);
				our_recplay[dev] = recsrc;
			}
			if (i - ourlevel[dev]) {	/* Has the setting changed? */
				EraseLevel(dev);
				RedrawBalance(dev);
				DrawLevel(dev);
				if ((1 << dev) & recmask)
					DrawRecordPlay(dev);
				ourlevel[dev] = i;
				wmove(w_panel, LINES, 0);
			}
		}
	}
}

void AumixSignalHandler(int signal_number)
{
/* So far, only SIGALRM is handled. */
	signal(SIGALRM, (void *) AumixSignalHandler);	/* Reset the signal handler. */
	RefreshNewSettings();
	alarm(REFRESH_PERIOD);
}

/* Change muted, normal, and solo states. */
void Muting(int device, int newstate)
{
/* device:  current device
   * mutestate:  0 for no mute, -1 for global mute, or set to soloing device
   * newstate:  new value for mutestate */
	switch (newstate) {
	case MUTE_OFF:
		switch (mutestate) {
		case MUTE_OFF:
			return;
			break;
		case MUTE_GLOBAL:
			UnmuteAll();
			break;
		case MUTE_ONLY:
			UnmuteAll();
			break;
		}
		break;
	case MUTE_GLOBAL:
		switch (mutestate) {
		case MUTE_OFF:
			StoreAll();
			MuteAll();
			break;
		case MUTE_GLOBAL:
			return;
			break;
		case MUTE_ONLY:
			MuteAll();
			break;
		}
		break;
	case MUTE_ONLY:
		switch (mutestate) {
		case MUTE_OFF:
			StoreAll();
			MuteAllButOne(device);
			break;
		case MUTE_GLOBAL:
			UnmuteOne(device);
			break;
		case MUTE_ONLY:
			MuteAllButOne(device);
			UnmuteOne(device);
		}
	}
	RefreshAllSettings();
	wattrset(w_panel, COLOR_PAIR(AXIS_COLOR));
	wmove(w_panel, 1, 0);
	switch (newstate) {
	case MUTE_OFF:
		wprintw(w_panel, "%s", LOCAL_TEXT("     "));
		break;
	case MUTE_GLOBAL:
		wprintw(w_panel, "%s", LOCAL_TEXT("muted"));
		break;
	case MUTE_ONLY:
		wprintw(w_panel, "%s", LOCAL_TEXT("only "));
	}
	wrefresh(w_panel);
	mutestate = newstate;
}

/* Switch between no muting and global muting; do nothing if soloing. */
void ToggleMuting(void)
{
	switch (mutestate) {
	case MUTE_OFF:
		Muting(MUTE_NO_DEVICE, MUTE_GLOBAL);
		break;
	case MUTE_GLOBAL:
		Muting(MUTE_NO_DEVICE, MUTE_OFF);
		break;
	case MUTE_ONLY:
		/* Do nothing. */
	}
}

void MuteAll(void)
/* Set all channels to zero. */
{
	int dev;
	for (dev = 0; dev < SOUND_MIXER_NRDEVICES; dev++)
		MuteOne(dev);
}

void UnmuteAll(void)
{
/* Restore all from mutelevel array. */
	int dev;
	for (dev = 0; dev < SOUND_MIXER_NRDEVICES; dev++)
		UnmuteOne(dev);
}

void StoreAll(void)
/* Read all channels into mutelevel array. */
{
	int dev;
	for (dev = 0; dev < SOUND_MIXER_NRDEVICES; dev++)
		StoreOne(dev);
}

void StoreOne(int device)
/* Read one channel into mutelevel array. */
{
	if ((1 << device) & devmask) {
		if (ioctl(mixer_fd, MIXER_READ(device), &mutelevel[device]) == -1) {
			perror("MIXER_READ");
			exit(EXIT_FAILURE);
		}
	}
}

void MuteAllButOne(int device)
/* Set all channels except one to zero. */
{
	int i;
	for (i = 0; i < SOUND_MIXER_NRDEVICES; i++)
		if (device != i)
			MuteOne(i);
}

void MuteOne(int device)
/* Set one channel to zero. */
{
	const int null = 0;
	if ((1 << device) & devmask) {
		if (ioctl(mixer_fd, MIXER_WRITE(device), &null) == -1) {
			perror("MIXER_WRITE");
			exit(EXIT_FAILURE);
		}
	}
}

void UnmuteAllButOne(int device)
{
/* Restore all but current from mutelevel array. */
	int i;
	for (i = 0; i < SOUND_MIXER_NRDEVICES; i++)
		if (device != i)
			UnmuteOne(i);
}

void UnmuteOne(int dev)
{
/* Restore one channel from mutelevel array. */
	if ((1 << dev) & devmask) {
		if (ioctl(mixer_fd, MIXER_WRITE(dev), &mutelevel[dev]) == -1) {
			perror("MIXER_WRITE");
			exit(EXIT_FAILURE);
		}
	}
}

void SetDefaultColors(void)
{
	init_pair(MENU_COLOR, COLOR_CYAN, COLOR_BLUE);
	init_pair(HOTKEY_COLOR, COLOR_RED, COLOR_BLUE);
	init_pair(HANDLE_COLOR, COLOR_CYAN, COLOR_BLUE);
	init_pair(TRACK_COLOR, COLOR_BLUE, COLOR_BLACK);
	init_pair(RECORD_COLOR, COLOR_RED, COLOR_BLACK);
	init_pair(PLAY_COLOR, COLOR_GREEN, COLOR_BLACK);
	init_pair(ACTIVE_COLOR, COLOR_YELLOW, COLOR_RED);
	init_pair(AXIS_COLOR, COLOR_WHITE, COLOR_BLACK);
}

void InitCurses(void)
{
	ReadInteractiveKeys();
	initscr();
	noecho();
	leaveok(stdscr, TRUE);
	keypad(stdscr, TRUE);
	cbreak();
	timeout(1000);
	start_color();
}

int InitColors(char *scheme)
{
	const int wordsize = 8;
	FILE *schemefile;
	char filename[MAXPATHLEN], item[wordsize], fore[wordsize], back[wordsize];
	char *colors[] =
	{"black", "red", "green", "yellow", "blue", "magenta", "cyan", "white"};
	char *items[] =
	{"active", "axis", "handle", "hotkey", "menu", "play", "record", "track"};
	int bg, fg, i, j = 0;
	sprintf(filename, "%s", scheme);
	schemefile = fopen(filename, "r");
	if (schemefile == NULL) {
		sprintf(filename, "%s/%s", DATADIRNAME, scheme);
		schemefile = fopen(filename, "r");
		if (schemefile == NULL)
			return (EFILE);
	}
	while (j != EOF) {
		j = fscanf(schemefile, "%8s%8s%8s\n", item, fore, back);
		for (i = COLOR_BLACK; i <= COLOR_WHITE; i++) {
			if (strncasecmp(fore, colors[i], sizeof(colors)) == 0)
				fg = i;
			if (strncasecmp(back, colors[i], sizeof(colors)) == 0)
				bg = i;
		}
/* Cycle through names of channels, looking for matches. */
		for (i = ACTIVE_COLOR; i <= TRACK_COLOR; i++)
			if (strncasecmp(item, items[i - 1], sizeof(colors)) == 0) {
				init_pair(i, fg, bg);
				refresh();
			}
	}
	fclose(schemefile);
	return (0);
}

void Inter(void)
{
	int incr, dir, dev, key, levelbalmode = 0, i, y = 0;
	char keyval;
/* Find first existing channel. */
	for (dev = 0; !(devmask & (1 << dev)); dev++);
	for (i = 0; i < dev; i++) {
		if (devmask & (1 << i))
			y++;
	}
	current_dev = dev;
/* Highlight the label. */
	wattrset(w_panel, COLOR_PAIR(ACTIVE_COLOR) | ((has_colors())? A_BOLD : A_REVERSE));
	wmove(w_panel, YOFFSET + y, XOFFSET + 36);
	waddstr(w_panel, dev_label[dev]);
	EraseLevel(current_dev);
	DrawLevel(current_dev);
	DrawLevelBalMode(current_dev, 0);
	wrefresh(w_panel);
	signal(SIGALRM, (void *) AumixSignalHandler);
	alarm(REFRESH_PERIOD);
	for (;;) {
#if HAVE_LIBGPM			/* Gpm_Getch doesn't honor halfdelay. */
		key = Gpm_Getch();
#else
		key = getch();
#endif
		incr = 0;
		dir = 0;
		switch (key) {
		case '.':
		case ',':
		case '<':
		case '>':
		case '\t':
		case '\n':
			levelbalmode = !levelbalmode;
			wattrset(w_panel, COLOR_PAIR(AXIS_COLOR));
			y = 0;
			for (i = 0; i < current_dev; i++)
				if (devmask & (1 << i))
					y++;
			wmove(w_panel, YOFFSET + y, XOFFSET + 35);
			waddstr(w_panel, "          ");
			wattrset(w_panel, COLOR_PAIR(ACTIVE_COLOR) | ((has_colors())? A_BOLD : A_REVERSE));
			wmove(w_panel, YOFFSET + y, XOFFSET + 36);
			waddstr(w_panel, dev_label[current_dev]);
			DrawLevelBalMode(current_dev, levelbalmode);
			break;
/* The 4 is ASCII for control-c; 27 is for escape. */
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			keyval = (char) (key);
			if ((levelbalmode) && ((1 << current_dev) & stereodevs))
				AdjustBalance(current_dev, 0, (MAXLEVEL / 10) * atoi(&keyval));
			else
				AdjustLevel(current_dev, 0, (MAXLEVEL / 10) * atoi(&keyval));
			break;
		case 4:
		case 27:
			return;
		case KEY_UP:
		case KEY_PPAGE:
		case KEY_DOWN:
		case KEY_NPAGE:
			if (key == KEY_UP || key == KEY_PPAGE)
				dir = -1;
			if (!dir)	/* if not PgUp or < pressed */
				dir = 1;
			/* un-highlight current label */
			EraseLevel(current_dev);
			DrawLevel(current_dev);
			wattrset(w_panel, COLOR_PAIR(AXIS_COLOR));
			y = 0;
			for (i = 0; i < current_dev; i++)
				if (devmask & (1 << i))
					y++;
			wmove(w_panel, YOFFSET + y, XOFFSET + 35);
			waddstr(w_panel, "          ");
			wattrset(w_panel, COLOR_PAIR(AXIS_COLOR));
			wmove(w_panel, YOFFSET + y, XOFFSET + 36);
			waddstr(w_panel, dev_label[current_dev]);
/* switch to next existing device */
			do {
				if (dir == 1) {
					current_dev++;
/* Wrap around. */
					if (current_dev > SOUND_MIXER_NRDEVICES - 1)
						current_dev = 0;
				} else {
					current_dev--;
					if (current_dev < 0)
						current_dev = SOUND_MIXER_NRDEVICES - 1;
				}
			}
			while (!((1 << current_dev) & devmask));
			/* highlight new device label */
			wattrset(w_panel, COLOR_PAIR(ACTIVE_COLOR) | ((has_colors())? A_BOLD : A_REVERSE));
			y = 0;
			for (i = 0; i < current_dev; i++) {
				if (devmask & (1 << i))
					y++;
			}
			wmove(w_panel, YOFFSET + y, XOFFSET + 36);
			waddstr(w_panel, dev_label[current_dev]);
			EraseLevel(current_dev);
			DrawLevel(current_dev);
			DrawLevelBalMode(current_dev, levelbalmode);
		}
		switch (key) {
		case ' ':
			SwitchRecordPlay(current_dev);
			break;
		case '[':
			if ((levelbalmode) && ((1 << current_dev) & stereodevs))
				AdjustBalance(current_dev, 0, 0);
			else
				AdjustLevel(current_dev, 0, 0);
			break;
		case ']':
			if ((levelbalmode) && ((1 << current_dev) & stereodevs))
				AdjustBalance(current_dev, 0, MAXLEVEL);
			else
				AdjustLevel(current_dev, 0, MAXLEVEL);
			break;
		case '+':
		case '-':
		case KEY_LEFT:
		case KEY_RIGHT:
			if (key == '+' || key == KEY_RIGHT) {
				incr = INCREMENT;
			}
			if (!incr)	/* '+'/up/right not pressed */
				incr = -INCREMENT;
			if ((levelbalmode) && ((1 << current_dev) & stereodevs))
				AdjustBalance(current_dev, incr, -1);
			else
				AdjustLevel(current_dev, incr, -1);
			break;
		case '|':
			AdjustBalance(current_dev, -1, (MAXLEVEL / 2));
		}
		key == tolower(key);
		if (key == *chark) {
			KeysBox();
			DrawLevelBalMode(current_dev, levelbalmode);
			wmove(w_panel, YOFFSET + y, XOFFSET + 36);
			waddstr(w_panel, dev_label[current_dev]);
		} else if (key == *charl)
			LoadSettings();
		else if (key == *charm)
			ToggleMuting();
		else if (key == *charo)
			Muting(current_dev, MUTE_ONLY);
		else if (key == *charq)
			return;
		else if (key == *chars)
			SaveSettings();
		else if (key == *charu)
			Muting(MUTE_NO_DEVICE, MUTE_OFF);
		wrefresh(w_panel);
	}
}

void DrawLevelBalMode(int dev, int mode)
/* arrow to show whether keyboard commands will adjust level or balance */
{
	int i, y = 0;
	for (i = 0; i < dev; i++) {
		if (devmask & (1 << i))
			y++;
	}
	wattrset(w_panel, COLOR_PAIR(ACTIVE_COLOR) | ((has_colors())? A_BOLD : A_REVERSE));
	if ((mode) && ((1 << dev) & stereodevs)) {
		wmove(w_panel, YOFFSET + y, XOFFSET + 44);
		waddch(w_panel, '>');
		wmove(w_panel, YOFFSET + y, XOFFSET + 44);
	} else {
		wmove(w_panel, YOFFSET + y, XOFFSET + 35);
		waddch(w_panel, '<');
		wmove(w_panel, YOFFSET + y, XOFFSET + 35);
	}
}

void AdjustLevel(int dev, int incr, int setlevel)
/*
 *  dev: device to adjust
 *  incr: signed percentage to increase (decrease) level, ignored unless
 *      setlevel = -1
 *  setlevel: level to set directly, or -1 to increment
 */
{
	int balset, max, left, right, temp;
	if (!((1 << dev) & devmask) || (dev > SOUND_MIXER_NRDEVICES - 1) || (dev < 0))
		return;
	if (ioctl(mixer_fd, MIXER_READ(dev), &temp) == -1) {
		CloseScreen();
		perror("MIXER_READ");
		exit(EXIT_FAILURE);
	}
	left = temp & 0x7F;
	right = (temp >> 8) & 0x7F;
	max = (left > right) ? left : right;
	if (max) {
		balset = (left > right) ? (MAXLEVEL / 2) * right / max : MAXLEVEL - ((MAXLEVEL / 2) * left / max);
	} else {
		balset = (MAXLEVEL / 2);
	}
	max += incr;
	if (balset > (MAXLEVEL / 2 - 1)) {
		left = max * (MAXLEVEL - balset) / (MAXLEVEL / 2);
		right = max;
	} else {
		right = max * balset / (MAXLEVEL / 2);
		left = max;
	}
	left = (setlevel > -1) ? setlevel : left;
	right = (setlevel > -1) ? setlevel : right;
	left = (left > MAXLEVEL) ? MAXLEVEL : left;
	right = (right > MAXLEVEL) ? MAXLEVEL : right;
	left = (left < 0) ? 0 : left;
	right = (right < 0) ? 0 : right;
	temp = (right << 8) | left;
	if (ioctl(mixer_fd, MIXER_WRITE(dev), &temp) == -1) {
		CloseScreen();
		perror("MIXER_WRITE");
		exit(EXIT_FAILURE);
	}
	EraseLevel(dev);
	/* Draw handle at new position. */
	RedrawBalance(dev);
	DrawLevel(dev);
}

void DrawLevel(int dev)
{
	int left, right, temp, i, y = 0;
	if (!((1 << dev) & devmask) || (dev > SOUND_MIXER_NRDEVICES - 1) || (dev < 0))
		return;
	for (i = 0; i < dev; i++) {
		if (devmask & (1 << i))
			y++;
	}
	if (ioctl(mixer_fd, MIXER_READ(dev), &temp) == -1) {
		CloseScreen();
		perror("MIXER_READ");
		exit(EXIT_FAILURE);
	}
	left = temp & 0x7F;
	right = (temp >> 8) & 0x7F;
	wattrset(w_panel, COLOR_PAIR(AXIS_COLOR));
	wmove(w_panel, YOFFSET + y, XOFFSET + 1 + left / INCREMENT);
	waddch(w_panel, 'L');
	wmove(w_panel, YOFFSET + y, XOFFSET + 1 + right / INCREMENT);
	waddch(w_panel, 'R');
	wattrset(w_panel, COLOR_PAIR(HANDLE_COLOR) | ((has_colors())? A_BOLD : A_REVERSE));
	wmove(w_panel, YOFFSET + y, XOFFSET + 1 + (left + right) / INCREMENT / 2);
	waddch(w_panel, 'O');
	wmove(w_panel, YOFFSET + y, XOFFSET + 1 + (left + right) / INCREMENT / 2);
	wrefresh(w_panel);
}

void EraseLevel(int dev)
{
/* Redraw level track. */
	int i, y = 0;
	if (!((1 << dev) & devmask) || (dev > SOUND_MIXER_NRDEVICES - 1) || (dev < 0))
		return;
	for (i = 0; i < dev; i++)
		if (devmask & (1 << i))
			y++;
	wattrset(w_panel, COLOR_PAIR(TRACK_COLOR));
	for (i = 0; i < 34; i++) {
		wmove(w_panel, YOFFSET + y, XOFFSET + 1 + i);
		waddch(w_panel, '+');
	}
}

void AdjustBalance(int dev, int incr, int setabs)
/*
 *  dev: device to adjust
 *  incr: signed percentage to change balance
 *  setabs: absolute balance setting, or -1 to increment only
 *  Balance settings go from 0 to MAXLEVEL; at setting of 0, right amplitude is 0.
 */
{
	int balset, max, left, right, temp, left_orig, right_orig;
	if (!((1 << dev) & devmask) || (dev > SOUND_MIXER_NRDEVICES - 1))
		return;
	if (ioctl(mixer_fd, MIXER_READ(dev), &temp) == -1) {
		CloseScreen();
		perror("MIXER_READ");
		exit(EXIT_FAILURE);
	}
	left = temp & 0x7F;
	right = (temp >> 8) & 0x7F;
	left_orig = left;
	right_orig = right;
	max = (left > right) ? left : right;
	if (max) {
		balset = (left > right) ? (MAXLEVEL / 2) * right / max : MAXLEVEL - ((MAXLEVEL / 2) * left / max);
	} else {
		balset = (MAXLEVEL / 2);
	}
	balset = (setabs == -1) ? balset + incr : setabs;
	balset = (balset > MAXLEVEL) ? MAXLEVEL : balset;
	balset = (balset < 0) ? 0 : balset;
	if (balset > (MAXLEVEL / 2 - 1)) {
		left = max * (MAXLEVEL - balset) / (MAXLEVEL / 2);
		right = max;
	} else {
		right = max * balset / (MAXLEVEL / 2);
		left = max;
	}
	temp = (right << 8) | left;
	if (ioctl(mixer_fd, MIXER_WRITE(dev), &temp) == -1) {
		CloseScreen();
		perror("MIXER_WRITE");
		exit(EXIT_FAILURE);
	}
	/* Draw handle at new position. */
	RedrawBalance(dev);
}

void RedrawBalance(int dev)
/* Redraw balance track. */
{
	int left, right, max, temp, balset, i, y = 0;
	for (i = 0; i < dev; i++)
		if (devmask & (1 << i))
			y++;
	if ((1 << dev) & stereodevs) {
		wattrset(w_panel, COLOR_PAIR(TRACK_COLOR));
		for (temp = 0; temp < 26; temp++) {
			wmove(w_panel, YOFFSET + y, XOFFSET + 45 + temp);
			waddch(w_panel, '+');
		}
		if (ioctl(mixer_fd, MIXER_READ(dev), &temp) == -1) {
			CloseScreen();
			perror("MIXER_READ");
			exit(EXIT_FAILURE);
		}
		left = temp & 0x7F;
		right = (temp >> 8) & 0x7F;
		max = (left > right) ? left : right;
		if (temp) {
			balset = (left > right) ? (MAXLEVEL / 2) * right / max : MAXLEVEL - ((MAXLEVEL / 2) * left / max);
		} else {
			balset = (MAXLEVEL / 2);
		}
		wattrset(w_panel, COLOR_PAIR(HANDLE_COLOR) | ((has_colors())? A_BOLD : A_REVERSE));
		wmove(w_panel, YOFFSET + y, XOFFSET + 45 + balset / 4);
		waddch(w_panel, 'O');
		wmove(w_panel, YOFFSET + y, XOFFSET + 45 + balset / 4);
		wrefresh(w_panel);
	}
}

void SwitchRecordPlay(int dev)
{
	/* Toggle record/play. */
	if ((1 << dev) & recmask) {
		if (ioctl(mixer_fd, SOUND_MIXER_READ_RECSRC, &recsrc) == -1) {
			perror("SOUND_MIXER_READ_RECSRC");
			exit(EXIT_FAILURE);
		}
		if (recsrc & (1 << dev))
			recsrc &= ~(1 << dev);	/* Turn off recording. */
		else
			recsrc |= (1 << dev);	/* Turn on recording. */
		if (ioctl(mixer_fd, SOUND_MIXER_WRITE_RECSRC, &recsrc) == -1) {
			CloseScreen();
			perror("SOUND_MIXER_WRITE_RECSRC");
			exit(EXIT_FAILURE);
		}
		if (ioctl(mixer_fd, SOUND_MIXER_READ_RECSRC, &recsrc) == -1) {
			perror("SOUND_MIXER_READ_RECSRC");
			exit(EXIT_FAILURE);
		}
		our_recplay[dev] = recsrc;	/* Store setting for updates. */
		DrawRecordPlay(dev);	/* Print indicators. */
	}
}

void DrawRecordPlay(int dev)
{
	int i, y = 0;
	wattrset(w_panel,
		 (1 << dev) & recsrc ? COLOR_PAIR(RECORD_COLOR) | ((has_colors())? A_NORMAL : A_REVERSE) : COLOR_PAIR(PLAY_COLOR));
	for (i = 0; i < dev; i++) {
		if (devmask & (1 << i))
			y++;
	}
	wmove(w_panel, YOFFSET + y, XOFFSET + 0);
	waddch(w_panel, ((1 << dev) & recsrc ? 'R' : 'P'));
	wmove(w_panel, YOFFSET + y, XOFFSET + 0);
	wrefresh(w_panel);
}

void CloseScreen(void)
{
	if (interactive) {
		initscr();	/* Calling refresh() will cause a segfault if we do it without initializing the screen. */
		clear();
		refresh();
		endwin();
	}
}

void ReadInteractiveKeys(void)
{
	chark = malloc(strlen(LOCAL_TEXT("k")));
	charl = malloc(strlen(LOCAL_TEXT("l")));
	charm = malloc(strlen(LOCAL_TEXT("m")));
	charo = malloc(strlen(LOCAL_TEXT("o")));
	charq = malloc(strlen(LOCAL_TEXT("q")));
	chars = malloc(strlen(LOCAL_TEXT("s")));
	charu = malloc(strlen(LOCAL_TEXT("u")));
	sprintf(chark, LOCAL_TEXT("k"));
	sprintf(charl, LOCAL_TEXT("l"));
	sprintf(charm, LOCAL_TEXT("m"));
	sprintf(charo, LOCAL_TEXT("o"));
	sprintf(charq, LOCAL_TEXT("q"));
	sprintf(chars, LOCAL_TEXT("s"));
	sprintf(charu, LOCAL_TEXT("u"));
}

#endif
