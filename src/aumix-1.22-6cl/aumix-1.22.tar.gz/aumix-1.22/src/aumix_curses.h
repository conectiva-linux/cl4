#ifndef AUMIX_CURSES_H
#define AUMIX_CURSES_H
#define ACTIVE_COLOR 1
#define AXIS_COLOR 2
#define HANDLE_COLOR 3
#define HOTKEY_COLOR 4
#define MENU_COLOR 5
#define PLAY_COLOR 6
#define RECORD_COLOR 7
#define TRACK_COLOR 8
#define REFRESH_PERIOD 1	/* number of seconds between updates */
#define MUTE_NO_DEVICE -1
#define MUTE_OFF 0
#define MUTE_GLOBAL 1
#define MUTE_ONLY 2
#define INCREMENT 3
#define BALANCE_INCREMENT 4

void ReadInteractiveKeys(void);
void InitCurses(void);
int InitColors(char *scheme);
void SetDefaultColors(void);
void Inter(void);
void AdjustLevel(int dev, int incr, int setlevel);
void SwitchRecordPlay(int dev);
void DrawRecordPlay(int dev);
void InitScreen(void);
void AdjustBalance(int dev, int incr, int setlevel);
void DrawLevel(int dev);
void DrawLevelBalMode(int dev, int mode);
void RedrawBalance(int dev);
void EraseLevel(int dev);
void CloseScreen(void);
void KeysBox(void);
void Muting(int device, int newstate);
void ToggleMuting(void);
void MuteAll(void);
void MuteOne(int device);
void UnmuteAll(void);
void StoreAll(void);
void StoreOne(int device);
void MuteAllButOne(int device);
void UnmuteAllButOne(int device);
void UnmuteOne(int device);
#endif
