#ifndef AUMIX_H
#define AUMIX_H
			/* for people compiling manually--these need to go away */
#ifndef DATADIRNAME
#define DATADIRNAME "/usr/local/share/aumix"
#endif
#ifndef VERSION
#define VERSION "1.22"
#endif
#define AUMIXRC_PATH "/etc"
#define AUMIXRC "aumixrc"
#define MAXLEVEL 100		/* highest level permitted by OSS drivers */
#ifndef TRUE			/* defined in ncurses.h */
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif
#include <stdio.h>
#include <stdlib.h>		/* getenv() */
#ifdef __linux__
#include <getopt.h>		/* getopt() */
#endif
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
/* The nice thing about standards... */
#if defined (__linux__)
#include <sys/soundcard.h>
#else
#if defined (__FreeBSD__)
#include <machine/soundcard.h>
#else
#if defined (__NetBSD__)
#include <soundcard.h>		/* OSS emulation */
#endif
#endif
#endif
#ifdef HAVE_ALSA
#include <sys/asoundlib.h>
#endif
#if HAVE_LIBGPM
#include <gpm.h>
extern int MouseHandler(Gpm_Event * event, void *data);
#else
#include "gpm-xterm.h"
#endif
#define ENODEV 2		/* no device found */
#define EREADDEV 3		/* SOUND_MIXER_READ_DEVMASK */
#define EREADRECMASK 4		/* SOUND_MIXER_READ_RECMASK */
#define EREADRECSRC 5		/* SOUND_MIXER_READ_RECSRC */
#define EREADSTEREO 6		/* SOUND_MIXER_READ_STEREODEVS */
#define EWRITERECSRC 7		/* SOUND_MIXER_WRITE_RECSRC */
#define EREADMIX 8		/* MIXER_READ */
#define EWRITEMIX 9		/* MIXER_WRITE */
#define ENOTOPEN 10		/* mixer not open */
#define EFILE 11		/* unable to open settings file */
#if HAVE_LIBNCURSES
#define XOFFSET 6
#define YOFFSET 0
#include <sys/param.h>		/* MAXPATHLEN */
#include <sys/time.h>
#include <signal.h>
#include <ncurses.h>
#include "aumix_curses.h"
#endif

/* Our `LOCAL_TEXT(STRING)' macro stands in for gettext (STRING)' when using
   NLS, and simply returns STRING otherwise.  */
#ifdef HAVE_NLS
#define LOCAL_TEXT(string) gettext (string)
#ifdef HAVE_LIBINTL_H
#include <libintl.h>
#endif				/* HAVE_LIBINTL_H */
#else				/* HAVE_NLS not defined */
#define LOCAL_TEXT(string) string
#endif				/* HAVE_NLS */

extern int current_dev, devmask, mixer_fd, recsrc, recmask, stereodevs,
 mutelevel[SOUND_MIXER_NRDEVICES], mutestate, interactive;
extern char *dev_label[SOUND_MIXER_NRDEVICES];
extern void RefreshAllSettings(void);
int ourlevel[SOUND_MIXER_NRDEVICES];
int our_recplay[SOUND_MIXER_NRDEVICES];		/* Store record/play settings for updates. */
int LoadSettings(void);
int SaveSettings(void);

#endif
