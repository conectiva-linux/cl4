#include "aumix.h"
#if HAVE_LIBGPM && HAVE_LIBNCURSES
extern int GpmHalfdelay(void);
extern int MouseHandler(Gpm_Event * event, void *data);

int MouseHandler(Gpm_Event * event, void *data)
{
	int dev_orig, i, j, temp;
	if ((event->type & GPM_DOWN) || (event->type & GPM_DRAG)) {
/* menu */
		if (event->x < 6) {	/* menu */
			switch (event->y) {
			case 3:	/* quit */
				Gpm_Close();
				close(mixer_fd);
				CloseScreen();
				exit(EXIT_SUCCESS);
			case 4:	/* load */
				LoadSettings();
				return;
			case 5:	/* save */
				SaveSettings();
				return;
			case 6:	/* keys */
				KeysBox();
				return;
			case 7:	/* mute */
				Muting(MUTE_NO_DEVICE, MUTE_GLOBAL);
				return;
			case 8:	/* only */
				Muting(current_dev, MUTE_ONLY);
				return;
			case 9:	/* undo */
				Muting(MUTE_NO_DEVICE, MUTE_OFF);
			default:
				return;
			}
		}
		current_dev = event->y - 1 - YOFFSET;
		j = 0;
		dev_orig = current_dev;
		for (i = 0; j <= dev_orig; i++) {
			if (!(devmask & (1 << i))) {
				current_dev++;
			} else {
				j++;
			}
		}
		temp = event->x - 2 - XOFFSET;
		if ((temp > 41) & (temp < 69)) {	/*balance */
			temp = (temp - 42) * BALANCE_INCREMENT;
			if ((((1 << current_dev) & stereodevs) && ((1 << current_dev) & devmask))) {
				AdjustBalance(current_dev, 0, temp);
				EraseLevel(current_dev);
				DrawLevel(current_dev);
			}
			return;
		}
		if (temp == -1) {
			SwitchRecordPlay(current_dev);
			return;
		}
		if (temp < 34) {
			temp = temp * INCREMENT;
			AdjustLevel(current_dev, 0, temp);
		}
	}
	return 0;
}

int GpmHalfdelay(void)
{				/* from Alessandro Rubini */
/*
   MouseHandler();
 */
	return (getch());
}
#endif
