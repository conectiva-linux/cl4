#!/usr/bin/python

# setup -- meta configuration tool calls other configuration tools.
# Copyright (C) 1997 Red Hat Software, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

import sys
if not '/usr/lib/rhs/python' in sys.path:
    sys.path[:0] = ['/usr/lib/rhs/python']

import os
import string

from snack import *





_toollist = (
	('Filesystem configuration' ,'/usr/sbin/cabaret'),
	('Keyboard configuration' ,'/usr/sbin/kbdconfig'),
	('Mouse configuration' ,'/usr/sbin/mouseconfig'),
	('System services', '/usr/sbin/ntsysv'),
	('Sound card configuration' ,'/usr/sbin/sndconfig'),
	('Timezone configuration' ,'/usr/sbin/timeconfig'),
	('X configuration' ,'/usr/X11R6/bin/Xconfigurator'),
)

toollist = []
maxlinewidth = 1
maxnamewidth = 1
for (description, path) in _toollist:
    if os.path.exists(path):
	name = string.split(path, '/')[-1]
	toollist.append((name, description, path))
	maxlinewidth = max(maxlinewidth, len(name)+len(description)+2)
	maxnamewidth = max(maxnamewidth, len(name))




class MainForm(SnackScreen):

    def draw_main_window(self):

	# should we throw an exception if the window is too small?

	# resize this string to fit the display
	spaceWidth = self.width - 47
	format_string = "%%s %%-%d.%ds  %%s" % (spaceWidth, spaceWidth)
	self.drawRootText(0, 0, format_string % (
		"setup 1.0", "", "Copyright (C) 1997 Red Hat Software"))


	toolbox = Listbox(height = min(self.height - 12, len(toollist)),
			  width = maxlinewidth + 8,
			  returnExit = 1)
	# consider sorting these later; fstab.keys() returns them in
	# the order they are in the fstab file.
	for (name, description, path) in toollist:
	    toolbox.append("%-15s  %s" % (name, description), path)

	bb = ButtonBar(self, (("Run", "run", "F1"),
				("Quit", "quit", "F12")))

	# consider trying to resize this string?  Difficult to make the
	# strings always come out exactly beneath the buttons, though.
	self.pushHelpLine(
          '                        F1=Run               F12=Quit')

	g = GridForm(self, "Choose a Configuration Tool", 1, 2)
	g.add(toolbox, 0, 0, (0, 0, 0, 1))
	g.add(bb, 0, 1, growx = 1)

	return ((g, toolbox, bb))


    def run_command(self, path):
	self.finish()
	os.system(path)
	self.__init__()


    def run(self):

	(g, toolbox, bb) = self.draw_main_window()

	while 1:
	    result = g.run()
	    button = bb.buttonPressed(result)
	    if button:
		if button == "run":
		    self.run_command(toolbox.current())
		    (g, toolbox, bb) = self.draw_main_window()
		elif button == "quit":
		    break;
	    elif result == toolbox:
		self.run_command(toolbox.current())
		(g, toolbox, bb) = self.draw_main_window()
	    elif result == "RESIZE":
		# Some day, snack will be capable of this, and we'll be ready.
		self.popWindow
		(g, toolbox, bb) = self.draw_main_window()
	    else:
		raise NameError, "Unknown button"



if __name__ == '__main__':
    m = MainForm()
    try:
	m.run()
	m.popWindow()
	m.finish()
    except:
	m.finish()
	print "error in setup:"
	raise sys.exc_type, sys.exc_value, sys.exc_traceback

