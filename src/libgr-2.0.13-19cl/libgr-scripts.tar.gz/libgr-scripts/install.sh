#!/bin/bash

DEST=$1

SCRIPTS="anytopnm pnmindex pnmmargin ppmquantall pstopnm"
MANS="anytopnm.1 pnmindex.1 ppmquantall.1 pnmmargin.1"

mkdir -p $DEST/usr/bin $DEST/usr/man/man1

for i in $SCRIPTS; do
	install -m 755 -o root -g root $i $DEST/usr/bin
done

for i in $MANS; do
	install -m 644 -o root -g root $i $DEST/usr/man/man1
done


