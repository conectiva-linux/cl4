/* version.h - define the current version of the package
*/

#define PBMPLUS_VERSION "Netpbm 1 March 1994"
