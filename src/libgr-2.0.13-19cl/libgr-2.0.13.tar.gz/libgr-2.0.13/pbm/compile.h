/* compile_time.h  This file tells the package when it was compiled */
/* DO NOT EDIT - THIS FILE IS MAINTAINED AUTOMATICALLY              */
#define COMPILE_TIME "Sat Aug 19 13:53:38 EST 1995"
#define COMPILED_BY "root"
