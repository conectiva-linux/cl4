/*
 * STAT stuff that breaks Applix
 */

#include <sys/stat.h>

int
_xstat (int vers, const char *name, struct stat *buf)
{
    return __xstat (vers, name, buf);
}

int
_fxstat (int vers, int fd, struct stat *buf)
{
    return __fxstat (vers, fd, buf);
}

int
_lxstat (int vers, const char *name, struct stat *buf)
{
    return __lxstat (vers, name, buf);
}

/*
 * __setjmp stuff that breaks again Applix
 */

#include <setjmp.h>

int __setjmp(jmp_buf env)
{
    return _setjmp(env);
}

