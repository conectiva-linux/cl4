/*
 * String to embed in binaries to identify package
 */

char pkg[] = "Package: netkit-rwho-0.10";
