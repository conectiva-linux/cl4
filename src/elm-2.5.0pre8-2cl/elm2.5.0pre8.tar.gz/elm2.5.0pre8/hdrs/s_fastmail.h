
#define FastmailSet	0x12
#define FastmailNoDebug	0x1
#define FastmailUsage	0x2
#define FastmailCannotOpenInput	0x3
#define FastmailTooManyToRecip	0x4
#define FastmailTooManyRecip	0x5
#define FastmailCannotCreateTemp	0x6
#define FastmailErrorSending	0x7
