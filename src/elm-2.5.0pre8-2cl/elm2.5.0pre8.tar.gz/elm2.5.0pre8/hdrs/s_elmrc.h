
#define ElmrcSet	0x1
#define ElmrcExpandHome	0x1
#define ElmrcOpenElmrc	0x2
#define ElmrcExpandShell	0x3
#define ElmrcCannotOpenElmrc	0x4
#define ElmrcCannotOpenRcinfo	0x5
#define ElmrcSortOrderCorrupt	0x6
#define ElmrcOptionsFile	0x7
#define ElmrcSavedAutoFor	0x8
#define ElmrcSavedAuto	0x9
#define ElmrcSavedRaw	0xa
#define ElmrcUnknownOptionWarning	0xb
#define ElmrcUnknownOptionMssg	0xc
#define ElmrcMissingOptionWarning	0xd
#define ElmrcMissingOptionMssg	0xe
#define ElmrcOptionsSavedIn	0xf
