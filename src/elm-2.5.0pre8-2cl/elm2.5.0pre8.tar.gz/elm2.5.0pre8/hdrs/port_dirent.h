/*
 * FOO - This is interim until the dirent/ndir portability is
 * worked out.  If this does not work for you, contact
 * <chip@unicom.com> and tell him to move his butt and get
 * this fixed.
 */
#include <dirent.h>
#define DIRENT dirent
