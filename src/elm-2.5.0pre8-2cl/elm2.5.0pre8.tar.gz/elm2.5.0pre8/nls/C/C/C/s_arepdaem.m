$set 14 #Arepdaem
$ #DefSubj
1	Auto-reply Mail
$ #SubjFw
2	Auto-reply
$ #ArepSubj
3	Auto-reply to:%s
$ #DataFileChange
4	Autoreply data file has changed!  Reading...
$ #NoOne
5	No-one is using autoreply...
$ #MaxPeople
6	Couldn't add %s - already at max people!
$ #AddingUser
7	adding %s to the active list
$ #RemovingUser
8	removing %s from the active list
$ #ErrUpdate
9	Couldn't update autoreply file
$ #NewMail
10	New mail for %s
$ #ErrOpen
11	can't open mail file for user %s
$ #ErrSeek
12	couldn't seek to %ld in mail file!
$ #ArepTo
13	auto-replying to '%s'
$ #ErrFstat
14	Error %d attempting fstat on %s
$ #MailCommand
15	%s/fastmail -f '%s [autoreply]' -s '%s' %s %s
$ #ErrUnlink
16	Error %s\n\ttrying to unlink file %s (%s)\n
