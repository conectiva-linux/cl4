$set 15 #Autoreply
$ #ArgsHelp1
1	Usage: %s <filename>\tto start autoreply,\n
$ #ArgsHelp2
2	       %s off\t\tto turn off autoreply\n
$ #ArgsHelp3
3	   or  %s    \t\tto check current status\n
$ #NoPasswdEntry
4	You have no password entry!\n
$ #ErrRead
5	Error: Can't read file '%s'\n
$ #ErrOpen
6	Error: couldn't open temp file '%s'.  Not removed\n
$ #NotAutoreply
7	You're not currently autoreplying to mail.\n
$ #NoOneAutoreply
8	No-one is autoreplying to their mail!\n
$ #CurrArep
9	You're currently autoreplying to mail with the file %s\n
$ #NoArepOff
10	You're not currently autoreplying to mail!\n
$ #NoArep
11	You're not currently autoreplying to mail.\n
$ #ErrReopenTemp
12	Error: couldn't reopen temp file '%s'.  Not removed.\n
$ #ErrReopenArep
13	Error: couldn't reopen autoreply file for writing!  Not removed.\n
$ #RemovedMulti
14	Warning: your username appeared %d times!!   Removed all\n
$ #Removed
15	You've been removed from the autoreply table.\n
$ #ErrOpenArep
16	Error: couldn't open the autoreply file!  Not added\n
$ #AddArep
17	You've been added to the autoreply system.\n
$ #ErrFstat
18	Error %d attempting fstat on %s\n
