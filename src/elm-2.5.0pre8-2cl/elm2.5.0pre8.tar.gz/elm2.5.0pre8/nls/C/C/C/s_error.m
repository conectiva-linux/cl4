$set 2 #Error
$quote "
$ #GetoptReq
1	": option requires an argument -- "
$quote
$ #CalendarCanOpen
2	Not able to append to file %s!
$ #CalendarAppend
3	Couldn't append to file %s!
$ #CalendarSavedPlural
4	%d entries saved in calendar file.
$ #CalendarSaved
5	1 entry saved in calendar file.
$ #CalendarNoneSaved
6	No calendar entries found in that message.
$ #CalendarSeek
7	ELM [seek] failed trying to read %d bytes into file.
$ #SystemConnections
9	Warning: couldn't figure out system connections...
$ #InitCommonNoPasswordEntry
10	You have no password entry!\n
$ #SafeMallocOutOfMemory
11	error - out of memory [%s failed allocating %d bytes]\n
