$set 19 #Readmsg
$ #Usage
1	Usage: %s [-anhp] [-f Folder] {MessageNum ... | pattern | *}\n
$ #StateFileCorrupt
2	%s: Elm folder state file appears to be corrupt!\n
$ #CannotExpandFolderName
3	%s: Cannot expand folder name "%s".\n
$ #CannotGetIncomingName
4	%s: Cannot figure out name of your incoming mail folder.\n
$ #FolderEmpty
5	%s: Folder "%s" is empty.\n
$ #IDontUnderstand
6	%s: I don't understand what "%s" means.\n
$ #CannotSeek
7	%s: Cannot seek to selected message. [offset=%ld]\n
$ #CannotFindStart
8	%s: Cannot find start of selected message. [offset=%ld]\n
$ #CannotFindMessage
9	%s: Cannot find message number %d.\n
$ #OutOfMemory
10	%s: Out of memory [malloc failed].\n
