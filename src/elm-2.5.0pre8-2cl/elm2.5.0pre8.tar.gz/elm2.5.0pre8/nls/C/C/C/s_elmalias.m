$set 4 #Elmalias
$ #Usage
1	usage: %s [-adenrsuvV] [-f format] [alias ...]\n
$ #OutOfMemory
2	%s: out of memory [could not allocate %d bytes]\n
$ #CannotSpecifyExpand
3	%s: cannot specify "-e" when dumping all aliases\n
$ #UnknownAlias
4	%s: "%s" is not a known alias\n
$ #CannotDetermineHome
5	%s: cannot determine your HOME directory\n
$ #IllegalFmtChar
6	<illegal format char>
$ #TypePerson
7	Person
$ #TypeGroup
8	Group
$ #TypeUnknown
9	Unknown
