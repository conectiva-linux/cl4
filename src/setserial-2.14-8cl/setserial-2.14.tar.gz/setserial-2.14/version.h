/*
 * version.h --- Defines the version number of setserial
 *
 * Copyright 1995, 1996, 1997, 1998 by Theodore Ts'o.  This file may be
 * redistributed under the GNU Public License.
 */

#define SETSERIAL_VERSION "2.14"
#define SETSERIAL_DATE "9-Jun-98"
