#define PSEUDOCOLOR 1
#define TRUECOLOR   2

extern unsigned long x11_map[256];

extern unsigned long x11_lut_red[256];
extern unsigned long x11_lut_green[256];
extern unsigned long x11_lut_blue[256];

int     x11_color_init(Widget shell);
Pixmap  x11_create_pixmap(Widget shell, unsigned char *data,
			  int width, int height);
