void init_dither (int, int, int);
void dither_line (char*,char*,int,int);
