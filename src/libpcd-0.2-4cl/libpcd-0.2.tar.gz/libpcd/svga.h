#define MAX(x,y)    ((x)>(y)?(x):(y))
#define MIN(x,y)    ((x)<(y)?(x):(y))

#define KEY_EOF      -1    /* ^D */
#define KEY_ESC      -2
#define KEY_SPACE    -3
#define KEY_Q        -4
#define KEY_PGUP     -5
#define KEY_PGDN     -6
#define KEY_TIMEOUT  -7

vga_modeinfo *svga_guess_mode(int width, int height, int colors, int mode);
void svga_display_image(vga_modeinfo *vgamode, char *image,
			int width, int height, int xoff, int yoff);
void svga_gray_palette();
void svga_dither_palette(int r, int g, int b);
void svga_cls(vga_modeinfo *vgamode);
int  svga_show(vga_modeinfo *vgamode, char *image,
	       int width, int height, int timeout);


