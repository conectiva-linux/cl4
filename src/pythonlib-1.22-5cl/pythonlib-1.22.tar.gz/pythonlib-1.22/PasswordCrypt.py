# Copyright (C) 1996, 1997 Red Hat Software, Inc.
# Use of this software is subject to the terms of the GNU General
# Public License

import string
import crypt
import rand

def _mk_crypt_salt(self):
    ret = ['','']
    for i in [0,1]:
        j = rand.choice(range(0,64))
        if (j < 26):
            ret[i] = string.lowercase[j]
        elif (j < 52):
            ret[i] = string.uppercase[j-26]
        elif (j < 62):
            ret[i] = string.digits[j-52]
        elif (j == 63):
            ret[i] = '.'
        else:
            ret[i] = '/'
    return ret[0]+ret[1]

def crypt_passwd(password):
    return crypt.crypt(password, _mk_crypt_salt())

def md5_passwd(password):
    # FIXME
    return 'this needs to be fixed'
