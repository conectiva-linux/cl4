# GLINT graphical package management
# Copyright (C) 1995 Red Hat, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

from Tkinter import *
from buttonbar import *
from rhtkinter import *

class Relay:
    def callback(self):
	self.func(self.data)

    def __init__(self, func, data):
	self.func = func
	self.data = data

class Dialog(Frame):
    def button(self, num):
	self.Master.destroy()
	self.num = num

    def __init__(self, title, message, bitmap, default, buttons): 
	self.Master = Toplevel()
	Frame.__init__(self, self.Master)

	self.bitmap = Label(self, { 'bitmap' : bitmap } )
	self.bitmap.pack()
	
	self.message = Message(self, { 'text' : message, 'aspect' : 600 })
	self.message.pack( )

	self.Buttons = ButtonBar(self)
	num = 0
	for button in buttons:
	    r = Relay(self.button, num)
	    self.Buttons.addButton(button, r.callback, 1)
	    num = num + 1

	self.num = default

	self.Buttons.pack()

	self.pack()

	self.update()
	self.grab_set()
	self.wait_window(self)

class WaitBox(RHFrame):
    def __init__(self, message):
	self.Master = Toplevel()
	RHFrame.__init__(self, self.Master)

	self.bitmap = Label(self, { 'bitmap' : 'warning' } )
	self.bitmap.pack()

	self.message = Message(self, { 'text' : message, 'aspect' : 600 })
	self.message.pack()

	self.pack()
	self.grab_set()
	self.update()

def error(message,  bitmap = 'error'):
    Dialog('Error', message, bitmap, 0, ['Ok']).num

def message(message, bitmap = 'warning'):
    Dialog('Message', message, bitmap, 0, ['Ok']).num

def scrolledMessageDialog(label, message, bitmap = 'warning'):
    win = RHFrame(Toplevel())

    win.bitmap = Label(win, { 'bitmap' : bitmap } )
    win.bitmap.pack()

    win.label = Label(win, { 'text' : label } )
    win.label.pack({ 'anchor' : 'w' })

    f = Frame(win)
    win.text = Text(f)
    win.text.insert('end', message)
    win.text.pack({ 'expand' : '1', 'fill' : 'both', 'side' : 'left'})
    f.pack()

    s = Scrollbar(f, { 'command' : win.text.yview } )
    win.text.pack({ 'fill' : 'y', 'side' : 'left'})
    win.text['yscrollcommand'] = s.set 

    win.Buttons = ButtonBar(win)
    win.Buttons.addButton("Ok", win.quit, 1)
    win.Buttons.pack()

    win.pack()

    win.update()
    win.grab_set()

    win.wait_window(win)
   
    
