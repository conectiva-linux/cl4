# GLINT graphical package management
# Copyright (C) 1995-1997 Red Hat Software, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

from Tkinter import *

class ButtonBar(Frame):
    def addButton(self, text, command, default = 0):
	b = Button(self, { 'text' : text , 'command' : command }  )
	self.buttonlist.append(b)
	#if (default):
	    #b['default'] = '1'

	if (self.packside == 'left'):
	    b.pack( { 'side' : 'left', 'ipady' : '2', 'expand' : '1' } )
	else:
	    b.pack( { 'side' : 'top', 'ipady' : '2', 'expand' : '1',
		      'fill' : 'x' } )

    def setOrientation(self, orient):
	if (orient == 'vert'):
	    self.packside = 'top'
	else:
	    self.packside = 'left'

    def setButtonName(self, buttonNumber, buttonName):
	self.buttonlist[buttonNumber].configure({'text':buttonName})

    def setButtonSensitive(self, buttonNumber, buttonSensitivity):
	if buttonSensitivity:
	    self.buttonlist[buttonNumber].configure({'state':'normal'})
	else:
	    self.buttonlist[buttonNumber].configure({'state':'disabled'})

    def __init__(self, Master = None):
	Frame.__init__(self, Master)
	self.buttonlist = []
	self.packside = 'left'
	
