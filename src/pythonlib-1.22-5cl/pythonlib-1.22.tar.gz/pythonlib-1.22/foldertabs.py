# FolderTabs widgets
# Copyright (C) 1996 Red Hat, Inc
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

from Tkinter import *
from rhtkinter import RHFrame

class relay:
    def __init__(self, command, arg = None):
	self.command = command
	self.args = arg
    def cb(self):
	self.command(self.args)

class FolderTabs(RHFrame):
    # This class will hopefully eventually be based on a canvas and
    # paint nice pictures of folder tabs.  In the meantime, this works...
    def addTab(self, text, command, default = 0):
        b = Button(self, {'text':text})
	r = relay(self.callTab, b)
	b['command'] = r.cb
	self.bg = b['bg']
	self.activebackground = b['activebackground']
	self.tabs.append((b, command))
        b.pack( { 'side' : 'left', 'ipady' : '2', 'expand' : '1' } )
	if default:
	    self.setTab(b, 1)
	else:
	    self.setTab(b, 0)

    def callTab(self, button):
	for tabs in self.tabs:
            if tabs[0] == button:
                tabs[1]()
                self.setTab(tabs[0], 1)
            else:
                self.setTab(tabs[0])

    def setTab(self, button, default = 0):
	if default:
	    button.config({'bg':'#b3b3b3', 'activebackground':'#c6c6c6'})
	else:
	    button.config({'bg':self.bg, 'activebackground':self.activebackground})

    def __init__(self, Master = None):
        Frame.__init__(self, Master)
	self.tabs = []


class SubFrame(RHFrame):
    # abstract class to derive switched subwindows from
    def show(self):
        self.pack({'expand':'1', 'fill':'both'})
    def hide(self):
        self.forget()

