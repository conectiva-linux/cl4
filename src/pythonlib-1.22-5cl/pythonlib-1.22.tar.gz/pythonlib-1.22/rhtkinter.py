from Tkinter import *
from string import atoi

class RHPhoto(PhotoImage):

    def transparentColor(self, color):
	return self.tk.call('set', 'TRANSPARENT_GIF_COLOR', color)

    def read(self, file):
	return self.tk.call(self.name, 'read', file)

class RHListbox(Listbox):
    def index(self, Index):
	return self.tk.call(self._w, 'index', Index)

class RHEntry(Entry):
    def __init__(self, Master, Config):
	Entry.__init__(self, Master, Config)
	# this is left for legacy only

class RHFrame(Frame):

    def quit(self):
	if (self._Master == None):
	    self.quit
	else:
	    self._Master.destroy()
    
    def __init__(self, Master = None):
	Frame.__init__(self, Master)
	self._Master = Master

class Popup(Menu):

    def postev(self, e):
	self.post(e.x_root, e.y_root)
	self.focus()
	self.grab_set_global()

    def __init__(self, Master = None):
	Menu.__init__(self, Master)
	self['tearoff'] = '0'

# get the correct backspace behavior for an item on machines with screwy
# keymaps (like XFree86's)

def entry_backspace(e):
    self = e.widget
    where = self.index('insert')
    self.delete("%d" % (where - 1))

e = Entry()
e.bind_class('Entry', '<Delete>', entry_backspace)
del e
