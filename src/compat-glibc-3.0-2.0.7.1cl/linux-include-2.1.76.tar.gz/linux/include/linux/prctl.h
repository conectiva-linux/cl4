#ifndef _LINUX_PRCTL_H
#define _LINUX_PRCTL_H

/*  Values to pass as first argument to prctl()  */

#define PR_SET_PDEATHSIG  1  /*  Second arg is a signal  */


#endif /* _LINUX_PRCTL_H */
