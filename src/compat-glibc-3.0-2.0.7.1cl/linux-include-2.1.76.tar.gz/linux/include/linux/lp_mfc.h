#ifndef _LINUX_LP_MFC_H_
#define _LINUX_LP_MFC_H_

/*
 * created 6.11.95 Joerg Dorchain
 */

#include <linux/types.h>
#include <linux/lp_m68k.h>

int lp_mfc_init(void);

#endif

