#ifndef _LINUX_NTFS_FS_H
#define _LINUX_NTFS_FS_H

int init_ntfs_fs(void);

#endif

