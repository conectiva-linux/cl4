#ifndef __LINUX_SMPLOCK_H
#define __LINUX_SMPLOCK_H

#include <asm/smp_lock.h>

#endif
