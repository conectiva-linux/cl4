#define NUMCARDS 1
#define NBDEVS 2

struct board_info static_boards[NUMCARDS]={
	{ ENABLED, 0, OFF, 2, (unchar*) 0x320, (unchar*) 0xd0000 },
};

/* DO NOT HAND EDIT THIS FILE! */
