#ifndef __ASM_MIPS_SMP_H
#define __ASM_MIPS_SMP_H

/* We'll get here eventually.. */

#endif /* __ASM_MIPS_SMP_H */
