/***

serv.c  - TCP/UDP port statistics module
Written by Gerard Paul Java
Copyright (c) Gerard Paul Java 1997, 1998

This software is open source; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License in the included COPYING file for
details.

***/

#include <curses.h>
#include <panel.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include "tcphdr.h"
#include "dirs.h"
#include "ipcsum.h"
#include "deskman.h"
#include "isdntab.h"
#include "packet.h"
#include "ipfrag.h"
#include "ifaces.h"
#include "stdwinset.h"
#include "input.h"
#include "attrs.h"
#include "serv.h"
#include "servname.h"
#include "error.h"
#include "log.h"
#include "timer.h"
#include "options.h"
#include "instances.h"
#include "packet.h"
#include "logvars.h"

#define SCROLLUP 0
#define SCROLLDOWN 1

extern void writeutslog(struct portlistent *list, unsigned long nsecs, FILE * logfile);

/*
 * SIGUSR1 logfile rotation signal handler
 */
 
void rotate_serv_log()
{
    rotate_flag = 1;
    strcpy(target_logname, TCPUDPLOG);
    signal(SIGUSR1, rotate_serv_log);
}

void initportlist(struct portlist *list)
{
    list->head = list->tail = NULL;
    list->firstvisible = list->lastvisible = NULL;
    list->count = 0;

    list->borderwin = newwin(LINES - 2, 80, 1, 0);
    list->borderpanel = new_panel(list->borderwin);
    wattrset(list->borderwin, BOXATTR);
    box(list->borderwin, ACS_VLINE, ACS_HLINE);

    wmove(list->borderwin, 0, 1);
    wprintw(list->borderwin, " Proto/Port ");
    wmove(list->borderwin, 0, 22);
    wprintw(list->borderwin, " Pkts ");
    wmove(list->borderwin, 0, 31);
    wprintw(list->borderwin, " Bytes ");
    wmove(list->borderwin, 0, 40);
    wprintw(list->borderwin, " PktsTo ");
    wmove(list->borderwin, 0, 49);
    wprintw(list->borderwin, " BytesTo ");
    wmove(list->borderwin, 0, 58);
    wprintw(list->borderwin, " PktsFrom ");
    wmove(list->borderwin, 0, 67);
    wprintw(list->borderwin, " BytesFrom ");

    list->win = newwin(LINES - 4, 78, 2, 1);
    list->panel = new_panel(list->win);

    stdwinset(list->win);
    wtimeout(list->win, -1);
    wattrset(list->win, STDATTR);
    colorwin(list->win);
    update_panels();
    doupdate();
}

struct portlistent *addtoportlist(struct portlist *list, unsigned int protocol,
			    unsigned int port, int *nomem, int servnames)
{
    struct portlistent *ptemp;

    ptemp = malloc(sizeof(struct portlistent));

    if (ptemp == NULL) {
	printnomem();
	*nomem = 1;
	return NULL;
    }
    if (list->head == NULL) {
	ptemp->prev_entry = NULL;
	list->head = ptemp;
	list->firstvisible = ptemp;
    }
    if (list->tail != NULL) {
	list->tail->next_entry = ptemp;
	ptemp->prev_entry = list->tail;
    }
    list->tail = ptemp;
    ptemp->next_entry = NULL;

    ptemp->protocol = protocol;
    ptemp->port = port;		/* This is used in checks later. */

    /* 
     * Obtain appropriate service name
     */

    servlook(servnames, htons(port), protocol, ptemp->servname, 10);

    ptemp->count = ptemp->bcount = 0;
    ptemp->icount = ptemp->ibcount = 0;
    ptemp->ocount = ptemp->obcount = 0;

    list->count++;
    ptemp->idx = list->count;

    if (list->count <= LINES - 4)
	list->lastvisible = ptemp;

    wmove(list->borderwin, LINES - 3, 1);
    wprintw(list->borderwin, " %u entries ", list->count);

    return ptemp;
}

int portinlist(struct porttab *table, unsigned int port)
{
    struct porttab *ptmp = table;

    while (ptmp != NULL) {
	if (((ptmp->port_max == 0) && (ptmp->port_min == port)) ||
	   ((port >= ptmp->port_min) && (port <= ptmp->port_max)))
	    return 1;

	ptmp = ptmp->next_entry;
    }

    return 0;
}

int goodport(unsigned int port, struct porttab *table)
{
    return ((port < 1024) || (portinlist(table, port)));
}

struct portlistent *inportlist(struct portlist *list,
			       unsigned int protocol, unsigned int port)
{
    struct portlistent *ptmp = list->head;

    while (ptmp != NULL) {
	if ((ptmp->port == port) && (ptmp->protocol == protocol))
	    return ptmp;

	ptmp = ptmp->next_entry;
    }

    return NULL;
}

void printportent(struct portlist *list, struct portlistent *entry,
		  unsigned int idx)
{
    unsigned int target_row;

    if ((entry->idx < idx) || (entry->idx > idx + (LINES - 5)))
	return;

    target_row = entry->idx - idx;

    wmove(list->win, target_row, 1);
    if (entry->protocol == IPPROTO_TCP) {
	wattrset(list->win, STDATTR);
	wprintw(list->win, "TCP");
    } else if (entry->protocol == IPPROTO_UDP) {
	wattrset(list->win, PTRATTR);
	wprintw(list->win, "UDP");
    }
    wprintw(list->win, "/%s: ", entry->servname);
    wattrset(list->win, HIGHATTR);
    wmove(list->win, target_row, 17);
    printlargenum(entry->count, list->win);
    wmove(list->win, target_row, 27);
    printlargenum(entry->bcount, list->win);
    wmove(list->win, target_row, 37);
    printlargenum(entry->icount, list->win);
    wmove(list->win, target_row, 47);
    printlargenum(entry->ibcount, list->win);
    wmove(list->win, target_row, 57);
    printlargenum(entry->ocount, list->win);
    wmove(list->win, target_row, 67);
    printlargenum(entry->obcount, list->win);
}

void destroyportlist(struct portlist *list)
{
    struct portlistent *ptmp = list->head;
    struct portlistent *ctmp = NULL;

    if (list->head != NULL)
	ctmp = list->head->next_entry;

    while (ptmp != NULL) {
	free(ptmp);
	ptmp = ctmp;

	if (ctmp != NULL)
	    ctmp = ctmp->next_entry;
    }
}

void printport(struct portlist *list, unsigned int protocol, unsigned int port,
	     int br, unsigned int idx, int fromto, struct porttab *ports,
	       int servnames)
{
    struct portlistent *listent;
    int nomem = 0;

    if (goodport(port, ports)) {
	listent = inportlist(list, protocol, port);

	if ((listent == NULL) && (!nomem))
	    listent = addtoportlist(list, protocol, port, &nomem, servnames);

	if (listent == NULL)
	    return;

	listent->count++;
	listent->bcount += br;

	if (fromto == 0) {	/* from */
	    listent->obcount += br;
	    listent->ocount++;
	} else {		/* to */
	    listent->ibcount += br;
	    listent->icount++;
	}

	printportent(list, listent, idx);
    }
}

void scrollservwin(struct portlist *table, int direction, int *idx)
{
    wattrset(table->win, STDATTR);
    if (direction == SCROLLUP) {
	if (table->lastvisible != table->tail) {
	    wscrl(table->win, 1);
	    table->lastvisible = table->lastvisible->next_entry;
	    table->firstvisible = table->firstvisible->next_entry;
	    (*idx)++;
	    wmove(table->win, LINES - 5, 0);
	    scrollok(table->win, 0);
	    wprintw(table->win, "%78c", ' ');
	    scrollok(table->win, 1);
	    printportent(table, table->lastvisible, *idx);
	}
    } else {
	if (table->firstvisible != table->head) {
	    wscrl(table->win, -1);
	    table->lastvisible = table->lastvisible->prev_entry;
	    table->firstvisible = table->firstvisible->prev_entry;
	    (*idx)--;
	    wmove(table->win, 0, 0);
	    wprintw(table->win, "%78c", ' ');
	    printportent(table, table->firstvisible, *idx);
	}
    }
}

void pageservwin(struct portlist *table, int direction, int *idx)
{
    int i = 1;

    if (direction == SCROLLUP) {
	while ((i <= LINES - 7) && (table->lastvisible != table->tail)) {
	    i++;
	    scrollservwin(table, direction, idx);
	}
    } else {
	while ((i <= LINES - 7) && (table->firstvisible != table->head)) {
	    i++;
	    scrollservwin(table, direction, idx);
	}
    }
}

/*
 * The TCP/UDP service monitor
 */
 
void servmon(char *ifname, struct porttab *ports,
             const struct OPTIONS *options, int facilitytime)
{
    int logging = options->logging;
    int fd;
    int isdn_fd = -1;
   
    char buf[8192];
    char aligned_buf[120];   
    char *ipacket;
    char *tpacket;

    unsigned int iphlen;
    struct sockaddr_pkt fromaddr;
    unsigned short linktype;
    int br;
    int exitloop = 0;

    unsigned int idx = 1;

    unsigned int sport = 0;
    unsigned int dport = 0;
    unsigned int firstin;    

    struct timeval tv;
    unsigned long starttime, startlog, timeint;
    unsigned long now;
    unsigned long long unow;
    unsigned long updtime = 0;
    unsigned long long updtime_usec = 0;

    int csum;
    int ck;

    int ch;

    struct portlist list;

    struct isdntab isdntable;
    
    FILE *logfile = NULL;

    /*
     * Mark this facility
     */
     
    if (!facility_active(TCPUDPIDFILE))
        mark_facility(TCPUDPIDFILE, "TCP/UDP monitor");
    else {
        errbox("TCP/UDP monitor already active in another process", ANYKEY_MSG, &ch);
	return;
    }         

    if (!iface_supported(ifname)) {
        err_iface_unsupported();
        unlink(TCPUDPIDFILE);
        return;
    }
        
    initportlist(&list);

    move(LINES - 1, 1);
    scrollkeyhelp();
    stdexitkeyhelp();

    update_panels();
    doupdate();

    if (options->servnames)
	setservent(1);

    if (logging) {
	opentlog(&logfile, TCPUDPLOG);

	if (logfile == NULL)
	    logging = 0;
    }
    
    if (logging)
        signal(SIGUSR1, rotate_serv_log);
        
    rotate_flag = 0;
    writelog(logging, logfile, "******** TCP/UDP service monitor started");

    open_socket(&fd);

    if (fd < 0)
	return;

    bzero(&isdntable, sizeof(struct isdntab));
    
    gettimeofday(&tv, NULL);
    starttime = startlog = timeint = tv.tv_sec;

    do {
	getpacket(fd, buf, &fromaddr, &ch, &br, list.win);

	if (ch != ERR)
	    switch (ch) {
	    case KEY_UP:
		scrollservwin(&list, SCROLLDOWN, &idx);
		break;
	    case KEY_DOWN:
		scrollservwin(&list, SCROLLUP, &idx);
		break;
	    case KEY_PPAGE:
	    case '-':
		pageservwin(&list, SCROLLDOWN, &idx);
		break;
	    case KEY_NPAGE:
	    case ' ':
		pageservwin(&list, SCROLLUP, &idx);
		break;
	    case 'q':
	    case 'Q':
	    case 'x':
	    case 'X':
	    case 27:
	    case 24:
		exitloop = 1;
	    }
	if (br > 0) {
	    if ((fromaddr.spkt_protocol == ntohs(ETH_P_IP)) &&
	       ((strcmp(fromaddr.spkt_device, ifname) == 0))) {
	        
	        isdn_iface_check(&isdn_fd, fromaddr.spkt_device);
	        linktype = getlinktype(fromaddr.spkt_family, fromaddr.spkt_device,
	                               isdn_fd, &isdntable);
	        
		adjustpacket(buf, linktype, &ipacket, aligned_buf, &br);

		if (ipacket == NULL)
		    continue;

		iphlen = ((struct iphdr *) ipacket)->ihl * 4;
		ck = ((struct iphdr *) ipacket)->check;
		((struct iphdr *) ipacket)->check = 0;
		csum = in_cksum((u_short *) ipacket, iphlen);

		if (ck != csum)
		    continue;

		/*
		 * if not first fragment of a datagram, pass it to
		 * the fragment processor and get the ports from there.
		 */

		if ((ntohs(((struct iphdr *) ipacket)->frag_off) & 0x3fff) != 0) {
		    br = processfragment((struct iphdr *) ipacket, &sport, &dport, &firstin);
		    if (!firstin)
			continue;
		} else {
		    tpacket = ipacket + iphlen;

		    if (((struct iphdr *) ipacket)->protocol == IPPROTO_TCP) {
		        sport = ntohs(((struct tcphdr *) tpacket)->source);
		        dport = ntohs(((struct tcphdr *) tpacket)->dest);
		    } else if (((struct iphdr *) ipacket)->protocol == IPPROTO_UDP) {
		        sport = ntohs(((struct udphdr *) tpacket)->source);
		        dport = ntohs(((struct udphdr *) tpacket)->dest);
		    }
		}
		
		if ((((struct iphdr *) ipacket)->protocol == IPPROTO_TCP) ||
		 (((struct iphdr *) ipacket)->protocol == IPPROTO_UDP)) {
		    printport(&list, ((struct iphdr *) ipacket)->protocol,
		       sport, ntohs(((struct iphdr *) ipacket)->tot_len),
			      idx, 0, ports, options->servnames);
		    printport(&list, ((struct iphdr *) ipacket)->protocol,
		       dport, ntohs(((struct iphdr *) ipacket)->tot_len),
			      idx, 1, ports, options->servnames);
		}
	    }
	}
	gettimeofday(&tv, NULL);
	now = tv.tv_sec;
	unow = tv.tv_sec * 1e+6 + tv.tv_usec;

	if (now - timeint >= 5) {
	    printelapsedtime(starttime, now, LINES - 3, 20, list.borderwin);
	    timeint = now;
	}
	if (((now - startlog) >= options->logspan) && (logging)) {
	    writeutslog(list.head, now - starttime, logfile);
	    startlog = now;
	}
	if (((options->updrate != 0) && (now - updtime >= options->updrate)) ||
	   ((options->updrate == 0) && (unow - updtime_usec >= DEFAULT_UPDATE_DELAY))) {
	    update_panels();
	    doupdate();
	    updtime = now;
	    updtime_usec = unow;
	}
	
	check_rotate_flag(&logfile, logging);
	
	if ((facilitytime != 0) && (((now - starttime) / 60) >= facilitytime))
	    exitloop = 1;
    } while (!exitloop);

    if (logging) {
        signal(SIGUSR1, SIG_DFL);
	writeutslog(list.head, time((time_t *) NULL) - starttime, logfile);
	writelog(logging, logfile, "******** TCP/UDP service monitor stopped");
	fclose(logfile);
    }
    if (options->servnames)
	endservent();

    del_panel(list.panel);
    delwin(list.win);
    del_panel(list.borderpanel);
    delwin(list.borderwin);
    unlink(TCPUDPIDFILE);
    update_panels();
    doupdate();
    destroyportlist(&list);
    destroyfraglist();
    destroy_isdn_table(&isdntable);
}

void portdlg(unsigned int *port_min, int *port_max, int *aborted, int mode)
{
    WINDOW *bw;
    PANEL *bp;
    WINDOW *win;
    PANEL *panel;

    struct FIELDLIST list;

    bw = newwin(14, 50, 5, 5);
    bp = new_panel(bw);

    win = newwin(12, 48, 6, 6);
    panel = new_panel(win);

    wattrset(bw, BOXATTR);
    box(bw, ACS_VLINE, ACS_HLINE);

    wattrset(win, STDATTR);
    colorwin(win);
    stdwinset(win);
    wtimeout(win, -1);

    wmove(win, 1, 1);
    wprintw(win, "Port numbers below 1024 are reserved for");
    wmove(win, 2, 1);
    wprintw(win, "TCP/IP services, and are normally the only");
    wmove(win, 3, 1);
    wprintw(win, "ones monitored by the TCP/UDP statistics");
    wmove(win, 4, 1);
    wprintw(win, "module.  If you wish to monitor a higher-");
    wmove(win, 5, 1);
    wprintw(win, "numbered port or range of ports, enter it");
    wmove(win, 6, 1);
    wprintw(win, "here.  Fill just the first field for a");
    wmove(win, 7, 1);
    wprintw(win, "single port, or both fields for a range.");

    wmove(win, 11, 1);
    tabkeyhelp(win);
    stdkeyhelp(win);

    initfields(&list, 1, 20, 15, 8);
    wattrset(list.fieldwin, STDATTR);
    wmove(list.fieldwin, 0, 6);
    wprintw(list.fieldwin, "to");
    
    addfield(&list, 5, 0, 0, "");
    addfield(&list, 5, 0, 9, "");

    fillfields(&list, aborted);

    if (!(*aborted)) {
	*port_min = atoi(list.list->buf);
	*port_max = atoi(list.list->nextfield->buf);
    }

    del_panel(bp);
    delwin(bw);
    del_panel(panel);
    delwin(win);
    destroyfields(&list);
}

void saveportlist(struct porttab *table)
{
    struct porttab *ptmp = table;
    int fd;
    int bw;
    int resp;

    fd = open(PORTFILE, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IWUSR);

    if (fd < 0) {
	errbox("Unable to open port list file", ANYKEY_MSG, &resp);
	return;
    }
    while (ptmp != NULL) {
	bw = write(fd, &(ptmp->port_min), sizeof(unsigned int));
	bw = write(fd, &(ptmp->port_max), sizeof(unsigned int));
	
	if (bw < 0) {
	    errbox("Unable to write port/range entry", ANYKEY_MSG, &resp);
	    destroyporttab(table);
	    close(fd);
	    return;
	}
	
	ptmp = ptmp->next_entry;
    }

    close(fd);
}

int dup_portentry(struct porttab *table, unsigned int min, unsigned int max)
{
    struct porttab *ptmp = table;

    while (ptmp != NULL) {
	if ((ptmp->port_min == min) && (ptmp->port_max == max))
	    return 1;

	ptmp = ptmp->next_entry;
    }

    return 0;
}

void addmoreports(struct porttab **table)
{
    unsigned int port_min, port_max;
    int aborted;
    int resp;
    struct porttab *ptmp;

    portdlg(&port_min, &port_max, &aborted, 0);

    if (!aborted) {
	if (dup_portentry(*table, port_min, port_max))
	    errbox("Duplicate port/range entry", ANYKEY_MSG, &resp);
	else {
	    ptmp = malloc(sizeof(struct porttab));

	    ptmp->port_min = port_min;
	    ptmp->port_max = port_max;
	    ptmp->prev_entry = NULL;
	    ptmp->next_entry = *table;

	    if (*table != NULL)
		(*table)->prev_entry = ptmp;

	    *table = ptmp;
	    saveportlist(*table);
	}
    }
    update_panels();
    doupdate();
}

void loadaddports(struct porttab **table)
{
    int fd;
    struct porttab *ptemp;
    struct porttab *tail = NULL;
    int br;
    int resp;

    *table = NULL;

    fd = open(PORTFILE, O_RDONLY);
    if (fd < 0)
	return;

    do {
	ptemp = malloc(sizeof(struct porttab));

	br = read(fd, &(ptemp->port_min), sizeof(unsigned int));
	br = read(fd, &(ptemp->port_max), sizeof(unsigned int));

	if (br < 0) {
	    errbox("Error reading port list", ANYKEY_MSG, &resp);
	    close(fd);
	    destroyporttab(*table);
	    return;
	}
	if (br > 0) {
	    if (*table == NULL) {
		*table = ptemp;
		ptemp->prev_entry = NULL;
	    }
	    if (tail != NULL) {
		tail->next_entry = ptemp;
		ptemp->prev_entry = tail;
	    }
	    tail = ptemp;
	    ptemp->next_entry = NULL;
	} else
	    free(ptemp);

    } while (br > 0);

    close(fd);
}

void displayportentry(struct porttab *ptmp, WINDOW *win)
{
    wprintw(win, "%u", ptmp->port_min);
    if (ptmp->port_max != 0)
        wprintw(win, " to %u", ptmp->port_max);	    
}

void displayports(struct porttab **table, WINDOW * win)
{
    struct porttab *ptmp = *table;
    short i = 0;

    do {
	wmove(win, i, 2);
	displayportentry(ptmp, win);
		    
	i++;
	ptmp = ptmp->next_entry;
    } while ((i < 18) && (ptmp != NULL));

    update_panels();
    doupdate();
}

void operate_portselect(struct porttab **table, struct porttab **node,
			WINDOW * win, int *aborted)
{
    int ch = 0;
    int i = 0;

    int exitloop = 0;

    *node = *table;

    do {
	wattrset(win, PTRATTR);
	wmove(win, i, 1);
	waddch(win, ACS_RARROW);
	ch = wgetch(win);
	wmove(win, i, 1);
	waddch(win, ' ');
	wattrset(win, STDATTR);

	switch (ch) {
	case KEY_DOWN:
	    if ((*node)->next_entry != NULL) {
		*node = (*node)->next_entry;

		if (i < 17)
		    i++;
		else {
		    wscrl(win, 1);
		    scrollok(win, 0);
		    wmove(win, 17, 0);
		    wprintw(win, "%22c", ' ');
		    scrollok(win, 1);
		    wmove(win, 17, 2);
		    displayportentry((*node), win);
		}
	    }
	    break;
	case KEY_UP:
	    if ((*node)->prev_entry != NULL) {
		*node = (*node)->prev_entry;

		if (i > 0)
		    i--;
		else {
		    wscrl(win, -1);
		    wmove(win, 0, 0);
		    wprintw(win, "%22c", ' ');
		    wmove(win, 0, 2);
		    displayportentry((*node), win);
		}
	    }
	    break;
	case 13:
	    exitloop = 1;
	    *aborted = 0;
	    break;
	case 27:
	case 24:
	case 'x':
	case 'X':
	case 'q':
	case 'Q':
	    exitloop = 1;
	    *aborted = 1;
	    break;
	}
    } while (!exitloop);
}

void selectport(struct porttab **table, struct porttab **node, int *aborted)
{
    WINDOW *bw;
    PANEL *bp;
    WINDOW *win;
    PANEL *panel;
    int resp;

    if (*table == NULL) {
	errbox("No custom ports", ANYKEY_MSG, &resp);
	return;
    }
    bw = newwin(20, 24, 2, 20);
    bp = new_panel(bw);
    wattrset(bw, BOXATTR);
    box(bw, ACS_VLINE, ACS_HLINE);
    wmove(bw, 0, 1);
    wprintw(bw, " Select port entry ");
    
    win = newwin(18, 22, 3, 21);
    panel = new_panel(win);
    stdwinset(win);
    wattrset(win, STDATTR);
    colorwin(win);

    listkeyhelp();

    displayports(table, win);
    operate_portselect(table, node, win, aborted);

    del_panel(panel);
    delwin(win);
    del_panel(bp);
    delwin(bw);

    update_panels();
    doupdate();
}

void delport(struct porttab **table, struct porttab *ptmp)
{
    if (ptmp != NULL) {
	if (ptmp == *table) {
	    *table = (*table)->next_entry;
	    if (*table != NULL)
		(*table)->prev_entry = NULL;
	} else {
	    ptmp->prev_entry->next_entry = ptmp->next_entry;

	    if (ptmp->next_entry != NULL)
		ptmp->next_entry->prev_entry = ptmp->prev_entry;
	}

	free(ptmp);
    }
}

void removeaport(struct porttab **table)
{
    unsigned int aborted;
    struct porttab *ptmp;

    selectport(table, &ptmp, &aborted);
    
    if (!aborted) {
	delport(table, ptmp);
	saveportlist(*table);
    }
}

void destroyporttab(struct porttab *table)
{
    struct porttab *ptemp = table;
    struct porttab *ctemp = NULL;

    if (ptemp != NULL)
	ctemp = ptemp->next_entry;

    while (ptemp != NULL) {
	free(ptemp);
	ptemp = ctemp;

	if (ctemp != NULL)
	    ctemp = ctemp->next_entry;
    }
}
