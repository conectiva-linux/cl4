/***

instances.h - header file for instances.c

***/

void mark_facility(char *tagfile, char *facility);
int facility_active(char *tagfile);
