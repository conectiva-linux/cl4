
void tcpfilterselect(struct filterlist *fl, unsigned int *filtered,
		     int *aborted);
void udpfilterselect(struct filterlist *fl, unsigned int *filtercode,
		     char *filename, int *aborted);
void loadsavedtcpfilter(struct filterlist *fl, int *filtered);
void loadfilter(char *filename, struct filterlist *fl);
int utfilter(struct filterlist *fl, unsigned long source, unsigned long dest,
	     unsigned int sport, unsigned int dport);
