/* Attribute variables */

extern int STDATTR;
extern int HIGHATTR;
extern int BOXATTR;
extern int BARSTDATTR;
extern int BARHIGHATTR;
extern int DESCATTR;
extern int PTRATTR;
extern int FIELDATTR;
extern int ERRBOXATTR;
extern int ERRTXTATTR;
extern int ERRRESPATTR;
extern int OSPFATTR;
extern int UDPATTR;
extern int IGPATTR;
extern int IGMPATTR;
extern int IGRPATTR;
extern int UNKNATTR;
