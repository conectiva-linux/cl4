extern int rotate_flag;
extern char target_logname[80];

