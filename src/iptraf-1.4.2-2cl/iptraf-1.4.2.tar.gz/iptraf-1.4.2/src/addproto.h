#define IPPROTO_IGP 		  9
#define IPPROTO_IGRP		 88
#define IPPROTO_OSPFIGP	 	 89

