/***

utfdefs.h - declarations for the UDP/TCP filter module
Written by Gerard Paul Java
Copyright (c) Gerard Paul Java 1997

***/

#include "fltmgr.h"

struct filterent {
    struct hostparams hp;
    unsigned long saddr;
    unsigned long daddr;
    unsigned long smask;
    unsigned long dmask;
    unsigned int index;
    struct filterent *next_entry;
    struct filterent *prev_entry;
};

struct filterlist {
    struct filterent *head;
    struct filterent *tail;
    unsigned int lastpos;

    WINDOW *borderwin;
    PANEL *borderpanel;
    WINDOW *filterwin;
    PANEL *filterpanel;
};
