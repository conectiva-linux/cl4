/*
 * dispmode function prototype
 */
 
void dispmode(int mode, char *result);
