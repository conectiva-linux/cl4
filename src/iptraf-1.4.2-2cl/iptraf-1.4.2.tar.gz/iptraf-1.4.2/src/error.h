/***

error.h - public declaration for error box
Written by Gerard Paul Java
Copyright (c) Gerard Paul Java 1997

***/

#define ANYKEY_MSG "Press a key to continue"

void errbox(char *message, char *prompt, int *response);
