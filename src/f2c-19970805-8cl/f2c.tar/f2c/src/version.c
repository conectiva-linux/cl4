char F2C_version[] = "19970805";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 19970805\n";
