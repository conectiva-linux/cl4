#ifndef managerpm_h
#define managerpm_h
#ifndef MISC_H
    #include <misc.h>
#endif
#ifndef MODULE_H
    #include <module.h>
#endif

#include <modapi_def.h>
#include <modapi.h>
class MODULE_managerpm: public LINUXCONF_MODULE{
    /*~PROTOBEG~ MODULE_managerpm */
public:
	MODULE_managerpm (void);
	int dohtml (const char *key);
	int domenu (MENU_CONTEXT context,
		 const char *key);
	int execmain (int argc, char *argv[]);
	void setmenu (DIALOG&dia,
		 MENU_CONTEXT context);
	void usage (SSTRINGS&tb);
    /*~PROTOEND~ MODULE_managerpm */
};

struct VERSION_ITEM {
	int num;
	const char *suffix;
};

struct VERSION_ITEMS{
	char str[100];
	int nb;
	VERSION_ITEM tb[10];
};

class RPM_OPTIONS {
public:
	char nodep;
	char force;
	char oldrev;
	char replace;
	char noscripts;
	char notrigger;
	char excludedocs;
	char test;
	/*~PROTOBEG~ RPM_OPTIONS */
public:
	RPM_OPTIONS (void);
	void addargs (SSTRING&args)const;
	/*~PROTOEND~ RPM_OPTIONS */
};



class PACKAGE: public ARRAY_OBJ{
public:
	SSTRING name;
	SSTRING version;
	VERSION_ITEMS v;	// Parsed version
	SSTRING release;
	VERSION_ITEM relnum;	// Parsed release
	SSTRING group;
	SSTRING vendor;
	SSTRING distribution;
	char selected;
	SSTRING fullname;
	/*~PROTOBEG~ PACKAGE */
public:
	PACKAGE (const char *_name,
		 const char *_version,
		 const char *_release,
		 const char *_group,
		 const char *_vendor,
		 const char *_distribution);
	int cmp (const PACKAGE *p);
	int install (void);
	void showfiles (void);
	void showinfo (void);
	int uninstall (void);
	/*~PROTOEND~ PACKAGE */
};

class PACKAGES: public ARRAY{
	/*~PROTOBEG~ PACKAGES */
public:
	bool any_selected (void);
	PACKAGE *getitem (int no)const;
	int install (void);
private:
	int load (const char *rpmarg);
public:
	int loadfromdir (const char *dir, const char *wild);
	int loadfrompath (const char *path);
	int loadinstall (const char *pattern);
	int loadinstall (void);
	PACKAGE *locate (const char *name);
	void remove_dups (void);
	void selectall (void);
	void sort (void);
	int uninstall (void);
	void unselectall (void);
	/*~PROTOEND~ PACKAGES */
};


#include "managerpm.p"

#endif
