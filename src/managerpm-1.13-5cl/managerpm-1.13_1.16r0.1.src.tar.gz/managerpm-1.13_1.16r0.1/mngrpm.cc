#include <stdlib.h>
#include <string.h>
#include "managerpm.h"
#include "managerpm.m"
#include <popen.h>
#include <userconf.h>
#include <netconf_def.h>
#include <daemoni.h>
#include <fstab.h>
#include <regex.h>

static const char K_MANAGERPM[]="managerpm";
static const char K_DIRS[]="dirs";


static HELP_FILE help_updatedir ("managerpm","updatedir");
static HELP_FILE help_updatepkg ("managerpm","updatepkg");
static HELP_FILE help_managerpm ("managerpm","managerpm");
static HELP_FILE help_prefs ("managerpm","prefs");
static HELP_FILE help_addons ("managerpm","addons");
static HELP_FILE help_pkginfo ("managerpm","pkginfo");
static HELP_FILE help_search ("managerpm","search");
static HELP_FILE help_mount ("managerpm","mount");
static HELP_FILE help_uninstall ("managerpm","uninstall");
static HELP_FILE help_install ("managerpm","install");

/*
	Decompose the version string of a package so it is easier
	to compare.
*/
static void mngrpm_parsever (const char *version, VERSION_ITEMS &v)
{
	/* #Specification: package / version / parsing
		A package version is defined this way ver[.subver[.subsubver...]]
		Each member (between dots) is a number followed optionally by
		a string. managerpm split this sequence so it can compare the
		version numerically, instead of just doing a string compare.
		(This follows RPM specs as far as I can tell)
	*/
	strcpy_cut (v.str,version,sizeof(v.str));
	for (int i=0; i<10; i++){
		v.tb[i].num = 0;
		v.tb[i].suffix = "";
	}
	char *pt = v.str;
	int nb = 0;
	while (*pt != '\0'){
		v.tb[nb].num = atoi(pt);
		pt = str_skipdig(pt);
		v.tb[nb].suffix = pt;
		nb++;
		while (*pt != '\0' && *pt != '.') pt++;
		if (*pt == '.') *pt++ = '\0';
	}
	v.nb = nb;
	#if 0
		fprintf (stderr,"version :%s: -> :",version);
		for (int i=0; i<nb; i++){
			if (i!= 0) fprintf (stderr,".");
			fprintf (stderr,"%d%s",v.tb[i].num,v.tb[i].suffix);
		}
		fprintf (stderr,":\n");
	#endif
}

PUBLIC PACKAGE::PACKAGE(
	const char *_name,
	const char *_version,
	const char *_release,
	const char *_group,
	const char *_vendor,
	const char *_distribution)
{
	name.setfrom (_name);
	version.setfrom (_version);
	release.setfrom (_release);
	vendor.setfrom (_vendor);
	group.setfrom (_group);
	distribution.setfrom (_distribution);
	selected = 0;
	mngrpm_parsever (_version,v);
	relnum.num = atoi(_release);
	relnum.suffix = str_skipdig(release.get());
}

/*
	Execute the RPM command and report error messages
*/
static int mngrpm_execrpm (
	const SSTRING &args,
	SSTRINGS &tb)	// Will hold stdout
{
	int ret = -1;
	SSTRING err;
	POPEN pop ("rpm",args.get());
	if (pop.isok()){
		while (pop.wait(30) > 0){
			char buf[1000];
			while (pop.readout(buf,sizeof(buf)-1)!=-1){
				tb.add (new SSTRING(buf));
			}
			while (pop.readerr(buf,sizeof(buf)-1)!=-1){
				err.append ("\n");
				err.append (buf);
			}
		}
		if (!err.is_empty()){
			xconf_error (MSG_U(E_RPM,"rpm %s\nreported those errors:")
				,err.get());
		}
		ret = pop.getstatus();
	}
	return ret;
}


PUBLIC RPM_OPTIONS::RPM_OPTIONS()
{
	nodep = false;
	force = false;
	oldrev = false;
	replace = false;
	noscripts = false;
	notrigger = false;
	excludedocs = false;
	test = false;
}

static void mngrpm_addargif (SSTRING &args,bool opt, const char *optstr)
{
	if (opt){
		args.append (" ");
		args.append (optstr);
	}
}

PUBLIC void RPM_OPTIONS::addargs( SSTRING &args) const
{
	mngrpm_addargif (args,nodep,"--nodeps");
	mngrpm_addargif (args,force,"--force");
	mngrpm_addargif (args,oldrev,"--oldpackages");
	mngrpm_addargif (args,replace,"--replacefiles");
	mngrpm_addargif (args,noscripts,"--noscripts");
	mngrpm_addargif (args,notrigger,"--notriggers");
	mngrpm_addargif (args,excludedocs,"--excludedocs");
	mngrpm_addargif (args,test,"--test");
}


int mngrpm_domany (
	const PACKAGES &pkgs,
	const char *title,
	const char *rpmoper,
	const RPM_OPTIONS &options)
{
	SSTRING args;
	args.setfrom (rpmoper);
	options.addargs(args);

	int n = pkgs.getnb();
	net_introlog (NETINTRO_MISC);
	net_title (title);
	net_prtlog (NETLOG_CMD,"rpm %s\n",args.get());
	for (int i=0; i<n; i++){
		PACKAGE *p = pkgs.getitem(i);
		if (p->selected){
			args.append (" ");
			const char *pkg = p->fullname.get();
			if (pkg[0] == '\0') pkg = p->name.get();	// An uninstall
			args.append (pkg);
			net_prtlog (NETLOG_CMD,"    %s\n",pkg);
		}
	}
	int ret = -1;
	if (perm_rootaccess (MSG_U(P_MNGPKG,"to manage packages"))){
		DAEMON_INTERNAL *dae = daemon_find ("rpm");
		if (dae != NULL){
			POPEN pop ("rpm",args.get());
			if (pop.isok()){
				SSTRING out;
				while (pop.wait(1000000)!=-1){
					char buf[1000];
					while (pop.readout(buf,sizeof(buf)-1)!=-1){
						out.append (buf);
						net_prtlog (NETLOG_OUT,buf);
					}
					while (pop.readerr (buf,sizeof(buf)-1)!=-1){
						out.append (buf);
						net_prtlog (NETLOG_ERR,buf);
					}
				}
				ret = pop.getstatus() ? -1 : 0;
				if (!out.is_empty()){
					xconf_notice (MSG_U(N_RPMRES,"Rpm results\n\n%s")
						,out.get());
				}
			}
		}
	}
	return ret;
}


void mngrpm_setdelopt (DIALOG &dia, RPM_OPTIONS &options)
{
	dia.newf_chk ("",options.nodep,MSG_R(F_NODEPS));
	dia.newf_chk ("",options.force,MSG_R(F_FORCE));
	dia.newf_chk ("",options.noscripts,MSG_R(F_NOSCRIPTS));
	dia.newf_chk ("",options.notrigger,MSG_R(F_NOTRIGGER));
	dia.newf_chk ("",options.test,MSG_R(F_TESTONLY));
}


/*
	Un-install the selected packages. Let the user pick un-install options
	return -1 if any errors
*/
PUBLIC int PACKAGES::uninstall()
{
	int ret = -1;
	if (any_selected()){
		DIALOG dia;
		RPM_OPTIONS options;
		mngrpm_setdelopt (dia,options);
		int nof = 0;
		while (1){
			MENU_STATUS code = dia.edit (MSG_U(T_UNINSTPKG,"Uninstall package")
				,"",help_uninstall,nof);
			if (code == MENU_CANCEL || code == MENU_ESCAPE){
				break;
			}else{
				if (mngrpm_domany (*this,MSG_U(T_DELPKGS,"Erase packages")
					,"-ev",options)==0){
					ret = 0;
					break;
				}
			}
		}
	}else{
		xconf_error (MSG_U(E_NOSELECTED,"No packages selected"));
	}
	return ret;
}



/*
	Un-install one package. The user may select un-install options
	Return -1 if any errors.
*/
PUBLIC int PACKAGE::uninstall()
{
	PACKAGES tmppkgs;
	tmppkgs.neverdelete();
	tmppkgs.add (this);
	selected = true;
	return tmppkgs.uninstall();
}

void mngrpm_setinstopt (DIALOG &dia, RPM_OPTIONS &options)
{
	dia.newf_chk ("",options.nodep,MSG_R(F_NODEPS));
	dia.newf_chk ("",options.force,MSG_R(F_FORCE));
	dia.newf_chk ("",options.replace,MSG_R(F_REPLACE));
	dia.newf_chk ("",options.noscripts,MSG_R(F_NOSCRIPTS));
	dia.newf_chk ("",options.notrigger,MSG_R(F_NOTRIGGER));
	dia.newf_chk ("",options.excludedocs,MSG_R(F_EXCLUDEDOCS));
	dia.newf_chk ("",options.test,MSG_R(F_TESTONLY));
}

/*
	Install the selected packages. Let the user pick install options
	return -1 if any errors
*/
PUBLIC int PACKAGES::install()
{
	int ret = -1;
	if (any_selected()){
		DIALOG dia;
		RPM_OPTIONS options;
		mngrpm_setinstopt(dia,options);
		int nof = 0;
		while (1){
			MENU_STATUS code = dia.edit (MSG_U(T_INSTPKG,"Install package")
				,"",help_install,nof);
			if (code == MENU_CANCEL || code == MENU_ESCAPE){
				break;
			}else{
				if (mngrpm_domany (*this,MSG_U(T_INSTPKGS,"Install packages")
					,"-iv",options)==0){
					ret = 0;
					break;
				}
			}
		}
	}else{
		xconf_error (MSG_R(E_NOSELECTED));
	}
	return ret;
}

/*
	Install one package. The user may select install options
	Return -1 if any errors.
*/
PUBLIC int PACKAGE::install()
{
	PACKAGES tmppkgs;
	tmppkgs.neverdelete();
	tmppkgs.add (this);
	selected = true;
	return tmppkgs.install();
}

PUBLIC void PACKAGE::showfiles()
{
	SSTRING args;
	bool installed = fullname.is_empty();
	if (installed){
		// Installed package
		args.setfromf ("-qlv %s",name.get());
	}else{
		args.setfromf ("-qplv %s",fullname.get());
	}
	SSTRINGS tb;
	mngrpm_execrpm (args,tb);
	if (tb.getnb()>0){
		dialog_textbox (MSG_U(T_PKGFILES,"Package files"),tb);
	}
}

PUBLIC void PACKAGE::showinfo()
{
	SSTRING args;
	bool installed = fullname.is_empty();
	if (installed){
		// Installed package
		args.setfromf ("-qi %s",name.get());
	}else{
		args.setfromf ("-qpi %s",fullname.get());
	}
	SSTRINGS tb;
	mngrpm_execrpm (args,tb);
	if (tb.getnb()>0){
		char outstr[PATH_MAX+100];
		snprintf (outstr,sizeof(outstr)-1,MSG_U(I_OUTRPM
			,"Output of \"rpm %s\""),args.get());
		DIALOG_TEXTBOX dia;
		dia.newf_text ("",tb);
		dia.setbutinfo (MENU_USR1,MSG_U(B_FILES,"Show files")
			,MSG_R(B_FILES));
		int butmask = MENUBUT_USR1;
		if (installed){
			butmask |= MENUBUT_USR2;
			dia.setbutinfo (MENU_USR2,MSG_U(B_UNINSTALL,"Uninstall")
				,MSG_R(B_UNINSTALL));
		}else{
			butmask |= MENUBUT_USR3;
			dia.setbutinfo (MENU_USR3,MSG_U(B_INSTALL,"Install")
				,MSG_R(B_INSTALL));
		}
		int nof = 0;
		while (1){
			MENU_STATUS code = dia.edit (MSG_U(T_PKGINFO,"Package info")
				,outstr
			,help_pkginfo
			,nof,MENUBUT_CANCEL|butmask);
			if (code == MENU_ESCAPE || code == MENU_CANCEL){
				break;
			}else if (code == MENU_USR1){
				showfiles();
			}else if (code == MENU_USR2){
				if (uninstall() == 0){
					break;
				}
			}else if (code == MENU_USR3){
				install();
				break;
			}
		}
	}else{
		xconf_error (MSG_U(E_NOOUTPUT
			,"The command rpm %s\ndid not produced any output")
			,args.get());
	}
}

PUBLIC int PACKAGE::cmp(const PACKAGE *p)
{
	int ret = name.cmp(p->name);
	if (ret == 0){
		int nb = v.nb;
		if (p->v.nb < nb) nb = p->v.nb;
		for (int i=0; i<nb && ret == 0; i++){
			ret = v.tb[i].num - p->v.tb[i].num;
			if (ret == 0) ret = strcmp(v.tb[i].suffix,p->v.tb[i].suffix);
		}
		if (ret == 0){
			ret = v.nb - p->v.nb;
			if (ret == 0){
				ret = relnum.num - p->relnum.num;
				if (ret == 0) ret = strcmp(relnum.suffix,p->relnum.suffix);
			}
		}
	}
	return ret;
}
		

PUBLIC void PACKAGES::unselectall()
{
	int n = getnb();
	for (int i=0; i<n; i++){
		getitem(i)->selected = 0;
	}
}

PUBLIC void PACKAGES::selectall()
{
	int n = getnb();
	for (int i=0; i<n; i++){
		getitem(i)->selected = 1;
	}
}

/*
	Is there any package selected in the table
*/
PUBLIC bool PACKAGES::any_selected()
{
	bool ret = false;
	int n = getnb();
	for (int i=0; i<n; i++){
		if (getitem(i)->selected){
			ret = true;
			break;
		}
	}
	return ret;
}

/*
	Load the list of installed packages or packages from some directory
*/
PRIVATE int PACKAGES::load (const char *rpmarg)
{
	int ret = -1;
	char arg[PATH_MAX+strlen(rpmarg)];
	snprintf (arg,sizeof(arg)-1
		,"%s --queryformat \"%{name}\t%{version}\t%{release}\t%{group}\t%{vendor}\t%{distribution}\n\""
		,rpmarg);
	POPEN pop ("rpm",arg);
	if (pop.isok()){
		while (pop.wait(10) > 0){
			char buf[1000];
			while (pop.readout(buf,sizeof(buf)-1)!=-1){
				char tb[6][100];
				const int sizetb = sizeof(tb)/sizeof(tb[0]);
				if (str_splitline(buf,'\t',tb,sizetb)==sizetb){
					for (int i=0; i<sizetb; i++) strip_end (tb[i]);
					add (new PACKAGE(tb[0],tb[1],tb[2],tb[3],tb[4],tb[5]));
				}
			}
		}
		ret = 0;
	}else{
		xconf_error (MSG_U(E_CANTEXEC,"Can't execute the command\nrpm %s")
			,arg);
	}
	return ret;
	
}

/*
	Load the list of installed packages
*/
PUBLIC int PACKAGES::loadinstall()
{
	return load ("-qa");
}

/*
	Load the list of installed packages matching a pattern
*/
PUBLIC int PACKAGES::loadinstall(const char *pattern)
{
	int ret = loadinstall();
	if (pattern[0] != '\0'){
		regex_t reg;
		if (regcomp (&reg,pattern,REG_ICASE)!=-1){
			for (int i=0; i<getnb(); i++){
				PACKAGE *p = getitem (i);
				const char *name = p->name.get();
				regmatch_t tbm[10];
				if (regexec (&reg,name,10,tbm,0)==REG_NOMATCH){
					remove_del (p);
					i--;
				}
			}
			regfree (&reg);
		}
	}
	return ret;
}


/*
	Remove packages with the same name. Keep the "newest" one
	As a side effect, the packages will be sorted
*/
PUBLIC void PACKAGES::remove_dups()
{
	sort();
	int n = getnb()-1;
	for (int i=0; i<n; i++){
		PACKAGE *p = getitem(i);
		PACKAGE *n = getitem(i+1);
		if (p->name.cmp(n->name)==0){
			remove_del (p);
			i--;
			n--;
		}
	}
}



/*
	Load the information about a single package
*/
PUBLIC int PACKAGES::loadfrompath (const char *path)
{
	char arg[2*PATH_MAX];
	snprintf (arg,sizeof(arg)-1,"-qp %s",path);
	int ret = load (arg);
	if (ret != -1){
		remove_dups();
	}
	return ret;
}

/*
	Load the information about many packages
*/
PUBLIC int PACKAGES::loadfromdir(const char *dir, const char *wild)
{
	SSTRINGS tb;
	{
		char cmd[PATH_MAX];
		snprintf (cmd,sizeof(cmd)-1,"/bin/ls %s/%s",dir,wild);
		POPEN pop (cmd);
		if (pop.isok()){
			while (pop.wait(10)>0){
				char buf[PATH_MAX];
				while (pop.readout(buf,sizeof(buf)-1)!=-1){
					strip_end (buf);
					tb.add (new SSTRING (buf));
				}
			}
		}
	}
	int size=1;
	for (int i=0; i<tb.getnb(); i++) size += tb.getitem(i)->getlen() + 1;
	char arg[size+4];
	char *pt = stpcpy (arg,"-qp");
	for (int i=0; i<tb.getnb(); i++){
		*pt++ = ' ';
		pt = stpcpy (pt,tb.getitem(i)->get());
	}
	int oldnb = getnb();
	int ret = load (arg);
	// fill the full path of each package as a package may have
	// a different filename
	int j=0;
	for (int i=oldnb; i<getnb(); i++,j++){
		PACKAGE *p = getitem(i);
		p->fullname.setfrom (tb.getitem(j)->get());
	}
	return ret;
}


PUBLIC PACKAGE *PACKAGES::getitem(int no) const
{
	return (PACKAGE*)ARRAY::getitem(no);
}

PUBLIC PACKAGE *PACKAGES::locate (const char *name)
{
	PACKAGE *ret = NULL;
	int n = getnb();
	for (int i=0; i<n; i++){
		PACKAGE *p = getitem(i);
		if (p->name.cmp(name)==0){
			ret = p;
			break;
		}
	}
	return ret;
}

static int cmp_by_name_version(const ARRAY_OBJ *p1, const ARRAY_OBJ *p2)
{
	PACKAGE *a1 = (PACKAGE*)p1;
	PACKAGE *a2 = (PACKAGE*)p2;
	return a1->cmp(a2);
}

PUBLIC void PACKAGES::sort()
{
	ARRAY::sort(cmp_by_name_version);
}


static int mngrpm_selectupd (
	PACKAGES &installed,
	PACKAGES &newpkgs,
	bool showdup,		// Present all version of a package instead
						// of only the newest one
	bool showold,		// Present package which are older than the one
						// installed
	bool shownew,		// Present packages which are not installed
						// currently
	RPM_OPTIONS &options)	
{
	int ret = -1;
	DIALOG dia;
	newpkgs.selectall();
	int nbnew = newpkgs.getnb();
	bool tbskip[nbnew];
	memset (tbskip,0,sizeof(tbskip));
	// Remove or unselect multiple version of the same package.
	// Keep only the newest
	for (int i=1; i<nbnew; i++){
		PACKAGE *prev = newpkgs.getitem(i-1);
		PACKAGE *newp = newpkgs.getitem(i);
		if (newp->name.cmp(prev->name)==0){
			if (showdup){
				prev->selected = 0;
			}else{
				tbskip[i-1] = true;
			}
		}
	}
	dia.newf_title (MSG_U(T_PKGLST,"Packages"),1,"",MSG_R(T_PKGLST));
	for (int i=0; i<nbnew; i++){
		PACKAGE *newp = newpkgs.getitem(i);
		if (tbskip[i]){
			newp->selected = 0;
		}else{
			const char *pname = newp->name.get();
			PACKAGE *oldp = installed.locate (pname);
			if (oldp != NULL){
				int vercmp = newp->cmp(oldp);
				if (vercmp > 0 || (vercmp < 0 && showold)){
					char updstr[100];
					snprintf (updstr,sizeof(updstr)-1,"%s-%s -> %s-%s %s"
						,oldp->version.get(),oldp->release.get()
						,newp->version.get(),newp->release.get()
						,vercmp < 0 ? MSG_U(I_DOWNGRADE,"*** Downgrading ***") : "");
					dia.newf_chk (pname,newp->selected,updstr);
				}else{
					newp->selected = 0;
				}
			}else if (shownew){
				char updstr[100];
				snprintf (updstr,sizeof(updstr)-1,"%s -> %s"
					,MSG_U(F_NOTINSTALLED,"Not installed")
					,newp->version.get());
				dia.newf_chk (pname,newp->selected,updstr);
			}else{
				newp->selected = 0;
			}
		}
	}
	dia.newf_title (MSG_U(T_RPMOPT,"Options"),1,"",MSG_R(T_RPMOPT));

	dia.newf_chk ("",options.nodep,MSG_U(F_NODEPS,"No dependancy checking (--nodeps)"));
	dia.newf_chk ("",options.force,MSG_U(F_FORCE,"Force update (--force)"));
	dia.newf_chk ("",options.oldrev,MSG_U(F_OLDREV,"Allow downgrade (--oldpackages)"));
	dia.newf_chk ("",options.replace,MSG_U(F_REPLACE,"Replace files from other pkgs (--replacefiles)"));
	dia.newf_chk ("",options.noscripts,MSG_U(F_NOSCRIPTS,"Do not exec scripts (--noscripts)"));
	dia.newf_chk ("",options.notrigger,MSG_U(F_NOTRIGGER,"Do not execute triggers (--notriggers)"));
	dia.newf_chk ("",options.excludedocs,MSG_U(F_EXCLUDEDOCS,"Do not install documentation (--excludedocs)"));
	dia.newf_chk ("",options.test,MSG_U(F_TESTONLY,"Test, do not install (--test)"));

	int nol = 0;
	if (dia.getnb()==0){
		xconf_notice (MSG_U(N_NOUPDATENEEDED
			,"No package to update. %d packages compared")
				,newpkgs.getnb());
	}else if (dia.edit (MSG_U(T_LISTUPDATE
		,"List of package to update")
		,MSG_U(I_LISTUPDATE,"Uncheck the packages you do not wish to update")
		,help_updatedir
		,nol)==MENU_ACCEPT){
		ret = 0;
	}
	return ret;
}


static int mngrpm_doupdate (PACKAGES &newpkgs, const RPM_OPTIONS &options)
{
	return mngrpm_domany (newpkgs,MSG_U(T_UPDPKG,"Update packages")
		,"-Uv",options);
}
/*
	Get the list of predefined (preference) directories for package

	If none are defined, the path of the RPMS on the distribution
	CD is used.
*/
static void mngrpm_getpkgdir(SSTRINGS &tb)
{
	linuxconf_getall (K_MANAGERPM,K_DIRS,tb,true);
	if (tb.getnb()==0){
		const char *path = configf_lookuppath("rpms_on_cdrom");
		tb.add (new SSTRING(path));
	}
}

static void mngrpm_setdircombo (FIELD_COMBO *comb)
{
	SSTRINGS tb;
	mngrpm_getpkgdir(tb);
	for (int i=0; i<tb.getnb(); i++){
		comb->addopt (tb.getitem(i)->get());
	}
}

/*
	Setup a DIALOG field to pick a directory path.
	Sets a help list of known directories defined in the preference screen.
*/
void mngrpm_setdirfield (DIALOG &dia, SSTRING &dir)
{
	FIELD_COMBO *comb = dia.newf_combo (MSG_U(F_UPDATEDIR
		,"Directory containing rpms"),dir);
	mngrpm_setdircombo (comb);
	dia.last_noempty();
}

/*
	Check if a given directory exist.
	If it does not exist, try to find out if it is part of an
	unmounted file system. If this is the case, let the user mount it.

	Return true if the directory is available

	mpoint will contain the mount points if a mount was done.
	mngrpm_unmountif() must be called by the client to do the unmount
	if needed.
*/
bool mngrpm_ismounted (const char *path, SSTRING &mpoint)
{
	bool ret = true;
	FSTAB fstab;
	int lenpath = strlen (path);
	FSTAB_ENTRY *found = NULL;
	for (int i=0; i<fstab.getnb(); i++){
		FSTAB_ENTRY *ent = fstab.getitem(i);
		const char *mpt = ent->getmpoint();
		int len = strlen(mpt);
		if (strcmp(path,mpt)==0){
			// Exact match
			found = ent;
			break;
		}else if (lenpath > len
			&& strncmp(path,mpt,len)==0
			&& path[len] == '/'){
			found = ent;
			break;
		}
	}
	if (found != NULL && !found->is_mounted()){
		char buf[2000];
		snprintf (buf,sizeof(buf)-1
			,MSG_U(I_MOUNT,"The directory %s\n"
				"is part of an unmounted filesystem\n"
				"Do you want to mount it ?"),path);
		if (strcmp(found->getfs(),"iso9660")==0){
			strcat (buf,MSG_U(I_PUTCD,"\n(Do not forget to put the CDrom in)"));
		}
		if (xconf_yesno (MSG_U(Q_MOUNT,"Mounting file system")
			,buf,help_mount)==MENU_YES
			&& perm_rootaccess(MSG_U(P_MOUNT,"mount file systems"))){
			ret = found->domount() != -1;
			if (ret) mpoint.setfrom (found->getmpoint());
		}
	}
	if (ret){
		int type = file_type (path);
		if (type == -1){
			xconf_error (MSG_U(E_MISSING,"%s does not exist"),path);
			ret = false;
		}else if (type != 1){
			xconf_error (MSG_U(E_NOTDIR,"%s exists but is not a directory"),path);
			ret = false;
		}
	}
	return ret;
}
/*
	Unmount what was mounted by mngrpm_ismounted()
*/
void mngrpm_unmountif (SSTRING &mpoint)
{
	if (!mpoint.is_empty()) netconf_system_if ("umount",mpoint.get());
}

static void mngrpm_updatedir ()
{
	SSTRING dir;
	SSTRING wild;
	DIALOG dia;
	mngrpm_setdirfield(dia,dir);
	wild.setfrom ("*.rpm");
	dia.newf_str (MSG_U(F_PATTERN,"File name pattern"),wild);
	char shownew = 0,showold = 0, showdup = 0;;
	dia.newf_chk ("",showold,MSG_U(F_SHOWOLD,"Show older packages"));
	dia.newf_chk ("",shownew,MSG_U(F_SHOWNEW,"Show uninstalled packages"));
	dia.newf_chk ("",showdup,MSG_U(F_SHOWDUP,"Show all available versions"));
	int nof = 0;
	SSTRING mpoint;		// Will contain the mount point if a file
						// system was mounted	
	RPM_OPTIONS options;
	while (dia.edit (MSG_U(T_UPDATEDIR,"Updating from a directory")
		,""
		,help_updatedir
		,nof)==MENU_ACCEPT){
		if (mngrpm_ismounted(dir.get(),mpoint)){
			PACKAGES install,fromdir;
			if (install.loadinstall() != -1
				&& fromdir.loadfromdir(dir.get(),wild.get())!=-1){
				if (fromdir.getnb()==0){
					xconf_error (MSG_U(E_NOPKGDIR,"No package %s in directory %s")
						,wild.get(),dir.get());
				}else if (mngrpm_selectupd (install,fromdir,showdup
					,showold,shownew,options)!=-1){
					if (mngrpm_doupdate (fromdir,options)!=-1){
						break;
					}
				}
			}
		}
	}
	mngrpm_unmountif (mpoint);
}

static void mngrpm_updatepkg ()
{
	SSTRING pkg;
	DIALOG dia;
	FIELD_COMBO *comb = dia.newf_combo (MSG_U(F_PACKAGEPATH
		,"Path of the rpm file"),pkg);
	mngrpm_setdircombo (comb);
	dia.last_noempty();
	int nof = 0;
	RPM_OPTIONS options;
	while (dia.edit (MSG_U(T_UPDATEPKG,"Updating one package")
		,""
		,help_updatepkg
		,nof)==MENU_ACCEPT){
		PACKAGES install,fromdir;
		if (install.loadinstall() != -1
			&& fromdir.loadfrompath(pkg.get())!=-1){
			if (fromdir.getnb()==0){
				xconf_error (MSG_U(E_NOPKG,"No package %s")
					,pkg.get());
			}else if (mngrpm_selectupd (install,fromdir
				,false,true,true,options)!=-1){
				if (mngrpm_doupdate (fromdir,options) != -1) break;
			}
		}
	}
}

static void mngrpm_setpref()
{
	SSTRINGS tb;
	mngrpm_getpkgdir(tb);
	DIALOG dia;
	for (int i=0; i<3; i++) tb.add (new SSTRING);
	for (int i=0; i<tb.getnb(); i++){
		dia.newf_str (i==0
			? MSG_U(F_DIRECTORIES,"Update directories") : ""
			,*tb.getitem(i));
	}
	int nof = 0;
	if (dia.edit (MSG_U(T_PREFS,"Preferences")
		,MSG_U(I_PREFS,"Enter values you are using often here")
		,help_prefs
		,nof)==MENU_ACCEPT){
		tb.remove_empty();
		linuxconf_replace (K_MANAGERPM,K_DIRS,tb);
		linuxconf_save();
	}
}

static void mngrpm_searcharg (
	PACKAGE *p,
	SSTRINGS &words,
	bool matchall,
	bool &match,		// Will be set to true if there is a match
	bool condit,		// Should we search this criteria
	const char *arg)	// argument to rpm command
{
	if (condit){
		char buf[PATH_MAX];
		snprintf (buf,sizeof(buf)-1,"-qp %s %s",p->fullname.get(),arg);
		POPEN pop ("rpm",buf);
		if (pop.isok()){
			int nbword = words.getnb();
			bool tbmatch[nbword];
			memset (tbmatch,0,sizeof(tbmatch));
			while (pop.wait(10)>0){
				while (pop.readout(buf,sizeof(buf)-1)!=-1){
					for (int i=0; i<nbword; i++){
						if (strstr (buf,words.getitem(i)->get())!=NULL){
							tbmatch[i]=true;
						}
					}
				}
			}
			int nbmatch = 0;
			for (int i=0; i<nbword; i++){
				if (tbmatch[i]) nbmatch++;
			}
			if (matchall){
				if (nbmatch == nbword) match = true;
			}else if (nbmatch > 0){
				match = true;
			}
		}
	}
}
/*
	Search one area of a package using one --queryformat tag
*/
static void mngrpm_searchq (
	PACKAGE *p,
	SSTRINGS &words,
	bool matchall,
	bool &match,		// Will be set to true if there is a match
	bool condit,		// Should we search this criteria
	const char *tag)	// Tag for queryformat
{
	char arg[100];
	sprintf (arg,"--queryformat \"%%{%s}\\n\"",tag);
	mngrpm_searcharg (p,words,matchall,match,condit,arg);
}

/*
	Search all package for the keywords.
	Present the list in a package browser.
*/
static void mngrpm_search (
	PACKAGES &pkgs,
	SSTRING &words,
	bool matchall,
	bool in_summary,
	bool in_desc,
	bool in_files,
	bool in_requires,
	bool in_provides)
{
	PACKAGES founds;
	founds.neverdelete();
	SSTRINGS tbwords;
	{
		char word[1000];
		const char *pt = words.get();
		while (1){
			pt=str_copyword (word,pt,sizeof(word)-1);
			if (word[0] == '\0') break;
			tbwords.add (new SSTRING (word));
		}
	}
	for (int i=0; i<pkgs.getnb(); i++){
		PACKAGE *p = pkgs.getitem(i);
		bool match = false;
		mngrpm_searchq (p,tbwords,matchall,match,in_summary,"summary");
		mngrpm_searchq (p,tbwords,matchall,match,in_desc,"description");
		mngrpm_searcharg (p,tbwords,matchall,match,in_files,"-l");
		mngrpm_searcharg (p,tbwords,matchall,match,in_requires,"--requires");
		mngrpm_searcharg (p,tbwords,matchall,match,in_provides,"--provides");
		if (match) founds.add (p);
	}
	if (founds.getnb()==0){
		xconf_error (MSG_U(E_NOMATCH,"No matching packages found"));
	}else{
		browse_groups (founds,true);
	}
}
/*
	Dialog to setup the search
*/
static void mngrpm_search ()
{
	SSTRING dir;
	SSTRING wild;
	DIALOG dia;
	mngrpm_setdirfield(dia,dir);
	wild.setfrom ("*.rpm");
	dia.newf_str (MSG_R(F_PATTERN),wild);
	dia.last_noempty();
	SSTRING words;
	dia.newf_str (MSG_U(F_WORDS,"Keyword(s) to search"),words);
	dia.last_noempty();
	char matchall = 0, in_summary = 1, in_desc = 1, in_files = 1;
	char in_requires = 0, in_provides = 0;
	dia.newf_chk ("",matchall,MSG_U(F_MATCHALL,"Only pkg matching all keywords"));
	dia.newf_chk ("",in_summary,MSG_U(F_INSUMMARY,"Search in summary"));
	dia.newf_chk ("",in_desc,MSG_U(F_INDESC,"Search in description"));
	dia.newf_chk ("",in_files,MSG_U(F_INFILES,"Search in file list"));
	dia.newf_chk ("",in_requires,MSG_U(F_INREQUIRES,"Search in \"requires\""));
	dia.newf_chk ("",in_provides,MSG_U(F_INPROVIDES,"Search in \"provides\""));

	SSTRING mpoint;
	int nof = 0;
	while (1){
		MENU_STATUS code = dia.edit (MSG_U(T_SEARCH,"Searching packages")
			,MSG_U(I_SEARCH
				,"You can find packages which contain some keywords\n"
				 "in their description or file list")
			,help_search
			,nof);
		if (code == MENU_CANCEL || code == MENU_ESCAPE){
			break;
		}else{
			if (mngrpm_ismounted (dir.get(),mpoint)){
				PACKAGES fromdir;
				if (fromdir.loadfromdir(dir.get(),wild.get())!=-1){
					if (fromdir.getnb()==0){
						xconf_error (MSG_R(E_NOPKGDIR),wild.get(),dir.get());
					}else{
						mngrpm_search (fromdir,words,matchall,in_summary,in_desc
							,in_files,in_requires,in_provides);
					}
				}
			}
		}
	}
	mngrpm_unmountif (mpoint);
}


/*
	Present package which are not from the distribution vendor
*/
void mngrpm_showaddon ()
{
	PACKAGES install;
	install.loadinstall();
	/* #Specification: managerpm / showaddon / trickery with bash
		To find out the list of packages which were not part of the
		original distribution, we are cheating a bit. We are using
		the distribution and vendor tags of the bash package as
		the reference. This is pretty reliable, except if the admin
		update bash.

		The real solution would be to have "per distribution" code which
		would identify this properly. For example, on redhat, it would read
		the /etc/redhat-release. For now, most distribution do not have
		a module, so we are relying on both strategy. Note that distribution
		module are able to override the calls to function like
		linuxconf_getval() so can easily return the information we need.
	*/
	PACKAGE *bash = install.locate ("bash");
	const char *distribution = distrib_getval("rpmdistribution");
	const char *vendor = distrib_getval("rpmvendor");
	if (distribution == NULL) distribution = bash->distribution.get();
	if (vendor == NULL) vendor = bash->vendor.get();
	install.sort();
	int n = install.getnb();
	DIALOG_RECORDS dia;
	dia.newf_head ("",MSG_U(H_PKGDEF,"Name\tVersion\tVendor\tDist."));
	int lookup[install.getnb()];
	for (int i=0; i<n; i++){
		PACKAGE *p = install.getitem(i);
		if (p->vendor.icmp(vendor)!=0
			|| p->distribution.icmp(distribution)!=0){
			char line[200];
			snprintf (line,sizeof(line)-1,"%s-%s\t%s\t%s"
				,p->version.get(),p->release.get(),p->vendor.get()
				,p->distribution.get());
			lookup[dia.getnb()-1] = i;
			dia.new_menuitem (p->name.get(),line);
		}
	}
	if (dia.getnb()>1){
		int nof = 0;
		while (1){
			MENU_STATUS code = dia.editmenu (MSG_U(T_ADDONS,"Add-on packages")
			,MSG_U(I_ADDONS
				,"Here is the list of packages not supplied\n"
				 "in the orignal distribution")
				,help_addons,nof,0);
			if (code == MENU_QUIT || code == MENU_ESCAPE){
				break;
			}else{
				// Provide info for that package
				PACKAGE *p = install.getitem(lookup[nof]);
				if (p != NULL) p->showinfo();
			}
		}
	}
}

void mngrpm_menu()
{
	static const char *pref = MSG_U(M_PREFER,"Preferences");
	static const char *updatepkg = MSG_U(M_UPDATEPKG,"Install/Update one package");
	static const char *updatedir = MSG_U(M_UPDATEDIR,"Install/Update many packages");
	static const char *browseins = MSG_U(M_BROWEINS,"Browse installed packages");
	static const char *browseunins = MSG_U(M_BROWEUNINS,"Browse un-installed packages");
	static const char *alien = MSG_U(M_ALIEN,"Show add-on packages");
	static const char *search = MSG_U(M_SEARCH,"Search a package");
	static const char *snapshot = MSG_U(M_SNAPSHOT,"Take a snapshot of the packages");
	static const char *tbopt[]={
		"",	pref,
		"",	updatepkg,
		"", updatedir,
		"", browseins,
		"", browseunins,
		"",	search,
		"",	alien,
		"",	snapshot,
		NULL
	};
	DIALOG_MENU dia;
	dia.new_menuitems (tbopt);
	int nof = 0;
	while (1){
		MENU_STATUS code = dia.editmenu (MSG_R(M_managerpm)
			,MSG_U(I_managerpm
				,"You can inspect/update packages on your system either\n"
				 "one by one or in batch.\n")
			,help_managerpm
			,nof,0);
		if (code == MENU_ESCAPE || code == MENU_QUIT){
			break;
		}else if (perm_rootaccess(MSG_R(P_MNGPKG))){
			const char *sel = dia.getmenustr(nof);
			if (sel == pref){
				mngrpm_setpref();
			}else if (sel == updatepkg){
				mngrpm_updatepkg();
			}else if (sel == updatedir){
				mngrpm_updatedir();
			}else if (sel == alien){
				mngrpm_showaddon();
			}else if (sel == browseins){
				browse_installed();
			}else if (sel == browseunins){
				browse_uninstalled();
			}else if (sel == search){
				mngrpm_search();
			}else if (sel == snapshot){
			}
		}
	}
}

