/* _dict.cc 16/09/98 16.07.22 */
/* browse.cc 18/05/99 23.18.08 */
/* managerpm.cc 13/01/99 12.58.08 */
PUBLIC MODULE_managerpm::MODULE_managerpm (void);
PUBLIC void MODULE_managerpm::setmenu (DIALOG&dia,
	 MENU_CONTEXT context);
PUBLIC int MODULE_managerpm::domenu (MENU_CONTEXT context,
	 const char *key);
PUBLIC int MODULE_managerpm::dohtml (const char *key);
PUBLIC void MODULE_managerpm::usage (SSTRINGS&tb);
PUBLIC int MODULE_managerpm::execmain (int argc, char *argv[]);
/* mngrpm.cc 18/05/99 23.31.34 */
PUBLIC PACKAGE::PACKAGE (const char *_name,
	 const char *_version,
	 const char *_release,
	 const char *_group,
	 const char *_vendor,
	 const char *_distribution);
PUBLIC RPM_OPTIONS::RPM_OPTIONS (void);
PUBLIC void RPM_OPTIONS::addargs (SSTRING&args)const;
PUBLIC int PACKAGES::uninstall (void);
PUBLIC int PACKAGE::uninstall (void);
PUBLIC int PACKAGES::install (void);
PUBLIC int PACKAGE::install (void);
PUBLIC void PACKAGE::showfiles (void);
PUBLIC void PACKAGE::showinfo (void);
PUBLIC int PACKAGE::cmp (const PACKAGE *p);
PUBLIC void PACKAGES::unselectall (void);
PUBLIC void PACKAGES::selectall (void);
PUBLIC bool PACKAGES::any_selected (void);
PRIVATE int PACKAGES::load (const char *rpmarg);
PUBLIC int PACKAGES::loadinstall (void);
PUBLIC int PACKAGES::loadinstall (const char *pattern);
PUBLIC void PACKAGES::remove_dups (void);
PUBLIC int PACKAGES::loadfrompath (const char *path);
PUBLIC int PACKAGES::loadfromdir (const char *dir, const char *wild);
PUBLIC PACKAGE *PACKAGES::getitem (int no)const;
PUBLIC PACKAGE *PACKAGES::locate (const char *name);
PUBLIC void PACKAGES::sort (void);
