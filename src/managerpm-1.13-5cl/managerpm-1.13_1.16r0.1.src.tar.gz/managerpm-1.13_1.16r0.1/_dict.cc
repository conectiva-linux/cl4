#include "managerpm.m"
#include <translat.h>
DICTIONARY_REQUEST;
