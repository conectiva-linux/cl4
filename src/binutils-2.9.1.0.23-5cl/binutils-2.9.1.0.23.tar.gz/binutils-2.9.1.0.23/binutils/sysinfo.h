typedef union {
 int i;
 char *s;
} YYSTYPE;
#define	COND	258
#define	REPEAT	259
#define	TYPE	260
#define	NAME	261
#define	NUMBER	262
#define	UNIT	263


extern YYSTYPE yylval;
