extern const char **_dictionary_userinfo;
#ifndef DICTIONARY_REQUEST
	#define DICTIONARY_REQUEST \
	const char **_dictionary_userinfo;\
	TRANSLATE_SYSTEM_REQ _dictionary_req_userinfo("userinfo",_dictionary_userinfo,25,0);\
	void dummy_dict_userinfo(){}
#endif
#ifndef MSG_U
	#define MSG_U(id,m)	_dictionary_userinfo[id]
	#define MSG_B(id,m,n)	_dictionary_userinfo[id]
	#define MSG_R(id)	_dictionary_userinfo[id]
	#define P_MSG_U(id,m)	new_trans_notload(_dictionary_userinfo,id)
	#define P_MSG_B(id,m,n)	new_trans_notload(_dictionary_userinfo,id)
	#define P_MSG_R(id)	new_trans_notload(_dictionary_userinfo,id)
#endif
#define F_ID	0
#define F_TITLE	1
#define F_TYPE	2
#define F_STRINGF	3
#define I_STRINGF	4
#define F_MINIMUM	5
#define F_MAXIMUM	6
#define T_VALUES	7
#define I_DELFIELD	8
#define T_FIELD_DEF	9
#define I_FIELD_DEF	10
#define E_RANGE	11
#define E_NOSPACE	12
#define E_2ITEMS	13
#define I_STRING	14
#define I_BOOL	15
#define I_NUM	16
#define I_LIST	17
#define H_FIELDDEF	18
#define I_ADDF	19
#define T_FIELDDEFS	20
#define I_FIELDDEFS	21
#define M_userinfo	22
#define T_USAGE	23
#define T_EXTRA	24
