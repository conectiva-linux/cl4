/* #Specification: userinfo / principles
	The userinfo module allows the admin to define various fields
	that will be added to the normal user account dialog. You can
	define new fields as needed.

	The extra information is stored into a CONFDB file like
	/etc/conf.linuxconf. The file is called /etc/userinfo.conf
*/
#pragma implementation
#include <stdio.h>
#include <string.h>
#include <translat.h>
#include "userinfo.h"
#include "userinfo.m"

MODULE_DEFINE_VERSION(userinfo);

PUBLIC MODULE_userinfo::MODULE_userinfo()
	: LINUXCONF_MODULE("userinfo")
{
	linuxconf_loadmsg ("userinfo",PACKAGE_REV);
}


static const char *keymenu=NULL;

PUBLIC void MODULE_userinfo::setmenu (
	DIALOG &dia,
	MENU_CONTEXT context)
{
	if (context == MENU_USER_POLICIES){
		keymenu = MSG_U(M_userinfo,"Account extra info setup");
		dia.new_menuitem ("userinfo","",keymenu);
	}
}

PUBLIC int MODULE_userinfo::domenu (
	MENU_CONTEXT context,
	const char *key)
{
	if (context == MENU_USER_POLICIES){
		if (key == keymenu){
			config_edit();
		}
	}
	return 0;
}


PUBLIC int MODULE_userinfo::dohtml (const char *key)
{
	int ret = LNCF_NOT_APPLICABLE;
	if (strcmp(key,"userinfo")==0){
		// ### Insert any menu and dialog here
		ret = 0;
	}
	return ret;
}


static void usage()
{
	xconf_error (MSG_U(T_USAGE
		,"Module userinfo\n"
		 "\n"
		 "    Without argument, present its main menu\n")
		);
}

PUBLIC void MODULE_userinfo::usage (SSTRINGS &tb)
{
	tb.add (new SSTRING (MSG_R(T_USAGE)));
}

PUBLIC int MODULE_userinfo::execmain (int argc , char *argv[])
{
	int ret = LNCF_NOT_APPLICABLE;
	const char *pt = strrchr(argv[0],'/');
	if (pt != NULL){
		pt++;
	}else{
		pt = argv[0];
	}
	if (strcmp(pt,"userinfo")==0){
		ret = -1;
		if (argc == 1){
			config_edit();
		}else{
			// ### Add some option parsing for the module
			::usage();
		}
	}
	return ret;
}


static MODULE_userinfo userinfo;

