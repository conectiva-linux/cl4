#ifndef userinfo_h
#define userinfo_h
#ifndef MISC_H
    #include <misc.h>
#endif
#ifndef MODULE_H
    #include <module.h>
#endif

#include <modapi_def.h>
#include <modapi.h>
class MODULE_userinfo: public LINUXCONF_MODULE{
    /*~PROTOBEG~ MODULE_userinfo */
public:
	MODULE_userinfo (void);
	int dohtml (const char *key);
	int domenu (MENU_CONTEXT context,
		 const char *key);
	int execmain (int argc, char *argv[]);
	void setmenu (DIALOG&dia,
		 MENU_CONTEXT context);
	void usage (SSTRINGS&tb);
    /*~PROTOEND~ MODULE_userinfo */
};

#define FLD_TYPE_STRING	0
#define FLD_TYPE_BOOL	1
#define FLD_TYPE_NUM	2
#define FLD_TYPE_LIST	3

class CONFDB;

class FIELD_DEF: public ARRAY_OBJ{
public:
	SSTRING id;
	SSTRING title;
	int type;
	int minimum,maximum;	// Limits for numeric field
	char must_fill;			// The string field must be filled (not empty)
	SSTRINGS values;		// Possible list values
	// Variables for the edit process
	struct {
		SSTRING str;
		int num;
		char sel;
	} val;
	int field_num;		// Field number in the dialog for error
						// reporting
	/*~PROTOBEG~ FIELD_DEF */
public:
	FIELD_DEF (void);
	void delval (CONFDB&conf, const char *user);
	int edit (void);
	void loadval (CONFDB&conf, const char *user);
	void saveval (CONFDB&conf, const char *user);
	/*~PROTOEND~ FIELD_DEF */
};

class FIELD_DEFS: public ARRAY{
public:
	/*~PROTOBEG~ FIELD_DEFS */
public:
	FIELD_DEFS (void);
	void delval (CONFDB&conf, const char *user);
	int edit (void);
	FIELD_DEF *getitem (int no)const;
	void loadval (CONFDB&conf, const char *user);
	void saveval (CONFDB&conf, const char *user);
	int write (void);
	/*~PROTOEND~ FIELD_DEFS */
};


class USERACCT_COMNG;
class DICTIONARY;

#include "userinfo.p"

#endif
