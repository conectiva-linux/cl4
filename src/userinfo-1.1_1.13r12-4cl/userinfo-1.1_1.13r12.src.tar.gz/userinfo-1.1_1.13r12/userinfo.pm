/* _dict.cc 11/11/98 00.09.26 */
/* comng.cc 11/11/98 01.59.22 */
PUBLIC USERINFO_COMNG::USERINFO_COMNG (DICTIONARY&_dict);
PUBLIC USERINFO_COMNG::~USERINFO_COMNG (void);
PUBLIC void USERINFO_COMNG::setupdia (DIALOG&dia);
PUBLIC int USERINFO_COMNG::save (PRIVILEGE *priv);
PUBLIC int USERINFO_COMNG::validate (DIALOG&, int &nof);
PUBLIC int USERINFO_COMNG::deluser (PRIVILEGE *);
/* config.cc 11/11/98 01.57.52 */
PUBLIC FIELD_DEF::FIELD_DEF (void);
PUBLIC int FIELD_DEF::edit (void);
PUBLIC void FIELD_DEF::loadval (CONFDB&conf, const char *user);
PUBLIC void FIELD_DEF::saveval (CONFDB&conf, const char *user);
PUBLIC void FIELD_DEF::delval (CONFDB&conf, const char *user);
PUBLIC FIELD_DEF *FIELD_DEFS::getitem (int no)const;
PUBLIC void FIELD_DEFS::loadval (CONFDB&conf, const char *user);
PUBLIC void FIELD_DEFS::saveval (CONFDB&conf, const char *user);
PUBLIC void FIELD_DEFS::delval (CONFDB&conf, const char *user);
PUBLIC FIELD_DEFS::FIELD_DEFS (void);
PUBLIC int FIELD_DEFS::write (void);
PUBLIC int FIELD_DEFS::edit (void);
/* userinfo.cc 13/01/99 13.29.00 */
PUBLIC MODULE_userinfo::MODULE_userinfo (void);
PUBLIC void MODULE_userinfo::setmenu (DIALOG&dia,
	 MENU_CONTEXT context);
PUBLIC int MODULE_userinfo::domenu (MENU_CONTEXT context,
	 const char *key);
PUBLIC int MODULE_userinfo::dohtml (const char *key);
PUBLIC void MODULE_userinfo::usage (SSTRINGS&tb);
PUBLIC int MODULE_userinfo::execmain (int argc, char *argv[]);
