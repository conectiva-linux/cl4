#include <stdlib.h>
#include "userinfo.h"
#include "userinfo.m"
#include <confdb.h>

static HELP_FILE help_field ("userinfo","field");


static const char K_USERINFO[]="userinfo";
static const char K_ID[]="id";
static const char K_TITLE[]="title";
static const char K_TYPE[]="type";
static const char K_MINIMUM[]="minimum";
static const char K_MAXIMUM[]="maximum";
static const char K_MUSTFILL[]="mustfill";
static const char K_VALUE[]="value";


PUBLIC FIELD_DEF::FIELD_DEF()
{
	type = FLD_TYPE_STRING;
	minimum = 0;
	maximum = 8000000;
	must_fill = 0;
	val.sel = 0;
	val.num = 0;
}

static const char *tbtype[4];


/*
	Edit a field definition.
	Return -1 if edit cancelled, 0 if accepted, 1 if the field
	must be deleted
*/
PUBLIC int FIELD_DEF::edit()
{
	int ret = -1;
	DIALOG dia;
	dia.newf_str (MSG_U(F_ID,"Field ID"),id);
	dia.last_noempty();
	dia.newf_str (MSG_U(F_TITLE,"Field title"),title);
	dia.last_noempty();
	FIELD_ENUM *fenum = dia.newf_enum (MSG_U(F_TYPE,"Field type"),type);
	for (int i=0; i<4; i++) fenum->addopt(tbtype[i]);
	dia.newf_chk (MSG_U(F_STRINGF,"String field"),must_fill
		,MSG_U(I_STRINGF,"must be filled"));
	dia.newf_num (MSG_U(F_MINIMUM,"Minimum value"),minimum);
	int field_maximum = dia.getnb();
	dia.newf_num (MSG_U(F_MAXIMUM,"Maximum value"),maximum);
	dia.newf_title ("",MSG_U(T_VALUES,"List values"));
	int field_value = dia.getnb();
	{
		// Make sure there are at least 4 empty value entries
		int nb_empty = 0;
		for (int i=0; i<values.getnb(); i++){
			if (values.getitem(i)->is_empty()) nb_empty++;
		}
		for (int i=nb_empty; i<4; i++) values.add (new SSTRING);
		for (int i=0; i<values.getnb(); i++){
			dia.newf_str ("",*values.getitem(i));
		}
	}
	int nof = 0;
	dia.delwhat (MSG_U(I_DELFIELD,"the field definition"));
	while (1){
		MENU_STATUS code = dia.edit (MSG_U(T_FIELD_DEF,"Field definition")
			,MSG_U(I_FIELD_DEF,"You must describe one input field")
			,help_field
			,nof,MENUBUT_DEL|MENUBUT_CANCEL|MENUBUT_ACCEPT);
		if (code == MENU_CANCEL || code == MENU_ESCAPE){
			break;
		}else if (code == MENU_DEL){
			if (xconf_delok()){
				ret = 1;
				break;
			}
		}else if (minimum > maximum){
			xconf_error (MSG_U(E_RANGE,"Maximum must be greater than minimum"));
			nof = field_maximum;
		}else if (id.strchr(' ')!=NULL){
			xconf_error (MSG_U(E_NOSPACE,"No space allowed in ID"));
			nof = 0;
		}else{
			int nb_empty = 0;
			for (int i=0; i<values.getnb(); i++){
				if (values.getitem(i)->is_empty()) nb_empty++;
			}
			if (values.getnb() - nb_empty < 2
				&& type == FLD_TYPE_LIST){
				xconf_error (MSG_U(E_2ITEMS
					,"You must define minimally 2 values\n"
					 "for an enumeration field"));
				nof = field_value;
			}else{
				values.remove_empty();
				ret = 0;
				break;
			}
		}
	}
	return ret;
}

/*
	Load the value of a field for a given user
*/
PUBLIC void FIELD_DEF::loadval(CONFDB &conf, const char *user)
{
	const char *s = conf.getval (user,id.get());
	if (s != NULL){
		if (type == FLD_TYPE_STRING){
			val.str.setfrom (s);
		}else if (type == FLD_TYPE_BOOL){
			val.sel = atoi(s);
		}else if (type == FLD_TYPE_NUM || type == FLD_TYPE_LIST){
			val.num = atoi(s);
		}
	}
}
/*
	Save the value of a field for a given user
*/
PUBLIC void FIELD_DEF::saveval(CONFDB &conf, const char *user)
{
	const char *ptid = id.get();
	if (type == FLD_TYPE_STRING){
		conf.replace (user,ptid,val.str);
	}else if (type == FLD_TYPE_BOOL){
		conf.replace (user,ptid,val.sel);
	}else if (type == FLD_TYPE_NUM || type == FLD_TYPE_LIST){
		conf.replace (user,ptid,val.num);
	}
}

/*
	Delete the value of a field for a given user
*/
PUBLIC void FIELD_DEF::delval(CONFDB &conf, const char *user)
{
	conf.removeall (user,id.get());
}

PUBLIC FIELD_DEF *FIELD_DEFS::getitem(int no) const
{
	return (FIELD_DEF*)ARRAY::getitem(no);
}

PUBLIC void FIELD_DEFS::loadval(CONFDB &conf, const char *user)
{
	for (int i=0; i<getnb(); i++) getitem(i)->loadval(conf,user);
}
PUBLIC void FIELD_DEFS::saveval(CONFDB &conf, const char *user)
{
	for (int i=0; i<getnb(); i++) getitem(i)->saveval(conf,user);
}

PUBLIC void FIELD_DEFS::delval(CONFDB &conf, const char *user)
{
	for (int i=0; i<getnb(); i++) getitem(i)->delval(conf,user);
}

PUBLIC FIELD_DEFS::FIELD_DEFS()
{
	SSTRINGS tb;
	linuxconf_getall (K_USERINFO,K_ID,tb,false);
	for (int i=0; i<tb.getnb(); i++){
		FIELD_DEF *d = new FIELD_DEF;
		add (d);
		const char *id = tb.getitem(i)->get();
		d->id.setfrom (id);
		char key[100];
		snprintf (key,sizeof(key)-1,"%s_%s",K_USERINFO,id);
		d->title.setfrom (linuxconf_getval (key,K_TITLE));
		d->type = linuxconf_getvalnum (key,K_TYPE,FLD_TYPE_STRING);
		d->must_fill = linuxconf_getvalnum (key,K_MUSTFILL,0);
		d->minimum = linuxconf_getvalnum (key,K_MINIMUM,0);
		d->maximum = linuxconf_getvalnum (key,K_MAXIMUM,8000000);
		linuxconf_getall (key,K_VALUE,d->values,true);
	}
}

/*
	Update /etc/conf.linuxconf
*/
PUBLIC int FIELD_DEFS::write()
{
	SSTRINGS tb;
	linuxconf_getall (K_USERINFO,K_ID,tb,false);
	for (int i=0; i<tb.getnb(); i++){
		char key[100];
		snprintf (key,sizeof(key)-1,"%s_%s",K_USERINFO,tb.getitem(i)->get());
		linuxconf_removeall (key,K_TITLE);
		linuxconf_removeall (key,K_TYPE);
		linuxconf_removeall (key,K_MUSTFILL);
		linuxconf_removeall (key,K_MINIMUM);
		linuxconf_removeall (key,K_MAXIMUM);
		linuxconf_removeall (key,K_VALUE);
	}
	linuxconf_removeall (K_USERINFO,K_ID);
	for (int i=0; i<getnb(); i++){
		FIELD_DEF *d = getitem(i);
		linuxconf_add (K_USERINFO,K_ID,d->id);
		char key[100];
		snprintf (key,sizeof(key)-1,"%s_%s",K_USERINFO,d->id.get());
		linuxconf_add (key,K_TITLE,d->title);
		linuxconf_add (key,K_TYPE,d->type);
		linuxconf_add (key,K_MUSTFILL,d->must_fill);
		linuxconf_add (key,K_MINIMUM,d->minimum);
		linuxconf_add (key,K_MAXIMUM,d->maximum);
		linuxconf_replace (key,K_VALUE,d->values);
	}
	return linuxconf_save();
}


PUBLIC int FIELD_DEFS::edit()
{
	tbtype[0] = MSG_U(I_STRING,"Character string");
	tbtype[1] = MSG_U(I_BOOL,"Checkbox");
	tbtype[2] = MSG_U(I_NUM,"Numeric value");
	tbtype[3] = MSG_U(I_LIST,"Enumeration");

	DIALOG_RECORDS *dia = NULL;
	int nof = 0;
	while (1){
		if (dia == NULL){
			dia = new DIALOG_RECORDS;
			dia->newf_head ("",MSG_U(H_FIELDDEF,"Title\tType"));
			for (int i=0; i<getnb(); i++){
				FIELD_DEF *d = getitem(i);
				dia->new_menuitem (d->title.get(),tbtype[d->type]);
			}
			dia->addwhat (MSG_U(I_ADDF,"a new field"));
		}
		bool must_delete = false;
		MENU_STATUS code = dia->editmenu (MSG_U(T_FIELDDEFS
			,"Field definitions")
			,MSG_U(I_FIELDDEFS,"You define here all the extra fields\n"
				"of the user account dialog")
			,help_field
			,nof,MENUBUT_ADD);
		if(code == MENU_QUIT || code == MENU_ESCAPE){
			break;
		}else if (code == MENU_ADD){
			FIELD_DEF *d = new FIELD_DEF;
			if (editone(d)==0) must_delete = true;
		}else{
			if (editone(nof)!= -1) must_delete = true;
		}
		if (must_delete){
			delete dia;
			dia = NULL;
		}
	}
	delete dia;
	return 0;
}
			
void config_edit()
{
	FIELD_DEFS defs;
	defs.edit();
}

