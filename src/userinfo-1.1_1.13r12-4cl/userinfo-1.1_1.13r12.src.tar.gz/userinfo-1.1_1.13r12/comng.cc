#include <usercomng.h>
#include "userinfo.h"
#include "userinfo.m"
#include <subsys.h>
#include <confdb.h>

static HELP_FILE help_config ("userinfo","config");
static CONFIG_FILE f_config ("/etc/userinfo.conf",help_config
	,CONFIGF_MANAGED|CONFIGF_OPTIONAL
	,"root","root",0600
	,subsys_useraccounts);

static CONFDB *conf = NULL;

class USERINFO_COMNG: public USERACCT_COMNG{
	FIELD_DEFS defs;
	/*~PROTOBEG~ USERINFO_COMNG */
public:
	USERINFO_COMNG (DICTIONARY&_dict);
	int deluser (PRIVILEGE *);
	int save (PRIVILEGE *priv);
	void setupdia (DIALOG&dia);
	int validate (DIALOG&, int &nof);
	~USERINFO_COMNG (void);
	/*~PROTOEND~ USERINFO_COMNG */
};

PUBLIC USERINFO_COMNG::USERINFO_COMNG(
	DICTIONARY &_dict)
	: USERACCT_COMNG (_dict)
{
	if (conf == NULL) conf = new CONFDB (f_config);
	if (!dict.get_bool ("is_new")){
		defs.loadval (*conf,dict.get_str("name"));
	}
}

PUBLIC USERINFO_COMNG::~USERINFO_COMNG()
{
}


PUBLIC void USERINFO_COMNG::setupdia (
	DIALOG &dia)
{
	dia.newf_title (MSG_U(T_EXTRA,"Extra"),1
			,"",MSG_R(T_EXTRA));
	for (int i=0; i<defs.getnb(); i++){
		FIELD_DEF *d = defs.getitem(i);
		int type = d->type;
		const char *title = d->title.get();
		d->field_num = dia.getnb();
		if (type == FLD_TYPE_STRING){
			dia.newf_str (title,d->val.str);
			if (d->must_fill) dia.last_noempty();
		}else if (type == FLD_TYPE_BOOL){
			dia.newf_chk (title,d->val.sel,"");
		}else if (type == FLD_TYPE_NUM){
			dia.newf_num (title,d->val.num);
		}else if (type == FLD_TYPE_LIST){
			FIELD_ENUM *fenum = dia.newf_enum (title,d->val.num);
			for (int j=0; j<d->values.getnb(); j++){
				fenum->addopt (d->values.getitem(j)->get());
			}
		}
	}
}	

PUBLIC int USERINFO_COMNG::save(
	PRIVILEGE *priv)
{
	defs.saveval (*conf,dict.get_str("name"));
	return conf->save(NULL);
}

PUBLIC int USERINFO_COMNG::validate(
	DIALOG &,
	int &nof)
{
	int ret = 0;
	return ret;
}

PUBLIC int USERINFO_COMNG::deluser (
	PRIVILEGE *)
{
	int ret = 0;
	if (!dict.get_bool("is_new")){
		defs.delval(*conf,dict.get_str("name"));
		ret = conf->save(NULL);
	}
	return ret;
}

USERACCT_COMNG *userinfo_newcomng(
	const char *key,
	DICTIONARY &dict)
{
	USERACCT_COMNG *ret = NULL;
	if (strcmp(key,"user")==0){
		ret = new USERINFO_COMNG (dict);
	}
	return ret;
}

static REGISTER_USERACCT_COMNG xxx (userinfo_newcomng);

