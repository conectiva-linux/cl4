package URI::URL::whois;
require URI::URL::_generic;
@ISA = qw(URI::URL::_generic);

sub default_port { 43 }
1;
