#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>      
#include <netdb.h>
#include <time.h>

#include <unistd.h>
#include <stdio.h>
#include <string.h>

/* difference between Unix time and net time */
#define BASE1970	2208988800L

time_t
RemoteDate(char *host)
{
	struct	hostent *him;		/* host table entry */
	struct	servent *timeServ;	/* sevice file entry */
	struct	sockaddr_in sin;	/* socket address */
	int	fd;			/* network file descriptor */
	time_t	unixTime;		/* time in Unix format */
	u_char  netTime[4];		/* time in network format */
	int	i;			/* loop variable */

	if ((him = gethostbyname(host)) == NULL) {
		fprintf(stderr, "rdate: Unknown host %s\n", host);
		return(-1);
	}

        if ((timeServ = getservbyname("time","tcp")) == NULL) {
                fprintf(stderr, "rdate: time/tcp: unknown service\n");
                return(-1);
        }

	if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("rdate");
		return(-1);
	}

        sin.sin_family = him->h_addrtype;      
        memcpy(&sin.sin_addr, him->h_addr, him->h_length);
        sin.sin_port = timeServ->s_port;

        if (connect(fd, &sin, sizeof(sin)) < 0) {
		perror("rdate");
		close(fd);
		return(-1);
	}

	/* read in the response */
	for (i = 0; i < 4; ) {
		int l = read(fd, &netTime[i], 4-i);
		if (l <= 0) {
			perror("rdate");
			close(fd);
			return(-1);
		}
		i += l;
	}

	close(fd);

	unixTime = ((time_t)netTime[0] << 24 |
		    (time_t)netTime[1] << 16 |
		    (time_t)netTime[2] << 8  |
		    (time_t)netTime[3] << 0  ) - BASE1970;

	return unixTime;
}

int 
main(int argc, char *argv[])
{
	int o, mode = 0;
	time_t t;

	while ((o = getopt(argc, argv, "sp")) != EOF)
		switch (o) {
		  case 'p':
			mode |= 1;
			break;
		  case 's':
			mode |= 2;
			break;
		  default:
		  usage:
			fprintf(stderr, "Usage: rdate [-s] [-p] <host> ...\n");
			return 1;
		}
	if (optind >= argc)
		goto usage;
	if (!mode)
		mode = 1;

	for (o = optind; o < argc; ++o) {
		t = RemoteDate(argv[o]);
		if (t == (time_t)-1)
			continue;
		if (mode & 1)
			printf("[%s]\t%s", argv[o], ctime(&t));
		if (mode & 2)
			if (stime(&t) < 0) {
				perror("rdate");
				return 1;
			}
	}

	return 0;
}
