CREATE SEQUENCE codigo_cadastro start 3147 increment 1 maxvalue 2147483647 minvalue 1  cache 1 ;
CREATE TABLE cadastro_ (
	nome char(60),
	razaosocial char(60),
	endereco char(50),
	bairro char(30), 
	cep char(9), 
	cidade char(30), 
	uf char(2), 
	fone char(20), 
	fax char(20), 
	cgc char(18), 
	inscricao char(18), 
	contato char(40), 
	email char(30), 
	observacoes text, 
	data date, 
	pais char(15),
	codigo int4 DEFAULT nextval ( 'codigo_cadastro' ));
grant all on cadastro_ to nobody;
grant all on codigo_cadastro to nobody;

insert into cadastro_ values('Marcelo Tosatti','','Rua X','Parolin','121212','Curitiba','duh','36636636','3443434','','12','marcelo@conectiva.com.br','marcelo@conectiva.com.br','Forte, alto, inteligente e bonito','12/12/12','Brasil');
insert into cadastro_ values('Maria','','Rua Marechal Deodoro','Centro','12/3/99','Curitiba','duh','2332328','34433334','','12','maria@yahoo.com','http://www.marialegal.com.br','','12/12/12','Brasil');
insert into cadastro_ values('Conectiva Informatica','XXXX','Rua Professor Rubens Elke Braga','Parolin','121212','Curitiba','duh','36636636','3443434','','12','marcelo@conectiva.com.br','info@conectiva.com.br','Guarani 3.0','12/12/12','Brasil');
insert into cadastro_ values('Wanderlei Antonio','','Rua Professor Rubens Elke Braga','Parolin','121212','Curitiba','duh','36636636','3443434','','12','wanderlei@conectiva.com.br','www.conectiva.com.br','','18/5/99','Brasil');

