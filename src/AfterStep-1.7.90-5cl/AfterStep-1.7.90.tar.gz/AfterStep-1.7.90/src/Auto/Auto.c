/*
 * Copyright (C) 1996 Frank Fejes
 * Copyright (C) 1994 Robert Nation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define TRUE 1
#define FALSE

#include "../../configure.h"
#ifdef ISC
#include <sys/bsdtypes.h>	/* Saul */
#endif

#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>
#if defined ___AIX || defined _AIX || defined __QNX__ || defined ___AIXV3 || defined AIXV3 || defined _SEQUENT_
#include <sys/select.h>
#endif
#include <unistd.h>
#include <ctype.h>
#include <stdlib.h>
#include "../../include/aftersteplib.h"
#include "../../include/module.h"

int fd_width;
int fd[2];
int timeout, t_secs, t_usecs;
char *MyName;
Display *dpy;			/* which display are we talking to */
int screen;

/*************************************************************************
 *
 * Subroutine Prototypes
 * 
 *************************************************************************/
void Loop (int *fd);
void DeadPipe (int nonsense);

#ifdef BROKEN_SUN_HEADERS
#include "../../src/sun_headers.h"
#endif

#ifdef NEEDS_ALPHA_HEADER
#include "../../src/alpha_header.h"
#endif /* NEEDS_ALPHA_HEADER */

void version(void)
{
  printf("%s version %s\n", MyName, VERSION);
  exit(0);
}

void usage(void)
{
  printf("Usage:\n"
	 "%s [--version] [--help] delay\n", MyName);
  exit(0);
}

/***********************************************************************
 *
 *  Procedure:
 *	main - start of module
 *
 ***********************************************************************/
int
main (int argc, char **argv)
{
  int i;
  char *temp, mask_mesg[80];
  char *global_config_file = NULL;

  /* Save our program name - for error messages */
  temp = strrchr (argv[0], '/');
  MyName = temp ? temp + 1 : argv[0];

  for (i = 1 ; i < argc && *argv[i] == '-' ; i++)
    {
      if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))
	usage ();
      else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--version"))
	version ();
      else if (!strcmp(argv[i], "-w") || !strcmp(argv[i], "--window"))
	i++;
      else if (!strcmp(argv[i], "-c") || !strcmp(argv[i], "--context"))
	i++;
      else if (!strcmp(argv[i], "-f") && i + 1 < argc)
	global_config_file = argv[++i];
    }

  if (i == argc)
    usage();

  timeout = atoi(argv[i++]);

  /* Dead pipes mean afterstep died */
  signal (SIGPIPE, DeadPipe);

  dpy = XOpenDisplay("");
  screen = DefaultScreen(dpy);

  /* connect to AfterStep */
  temp = module_get_socket_property(RootWindow(dpy, screen));
  fd[0] = fd[1] = module_connect (temp);
  XFree (temp);
  if (fd[0] < 0)
    {
      fprintf (stderr, "%s: unable to establish connection to AfterStep\n", MyName);
      exit (1);
    }
  temp = safemalloc (9 + strlen(MyName) + 1);
  sprintf (temp, "SET_NAME %s", MyName);
  SendInfo (fd, temp, None);
  free (temp);

  t_secs = timeout / 1000;
  t_usecs = (timeout - t_secs * 1000) * 1000;

  fd_width = GetFdWidth ();
  sprintf (mask_mesg, "SET_MASK %lu\n", (unsigned long) (M_FOCUS_CHANGE));
  SendInfo (fd, mask_mesg, 0);
  Loop (fd);

  return 0;
}


/***********************************************************************
 *
 *  Procedure:
 *	Loop - wait for data to process
 *
 ***********************************************************************/
unsigned long focus_win = 0;

void
Loop (int *fd)
{
  unsigned long header[HEADER_SIZE], *body;
  fd_set in_fdset;
  struct itimerval value;
  int retval;
  int Raised = 0;

  while (1)
    {
      FD_ZERO (&in_fdset);
      FD_SET (fd[1], &in_fdset);

      /* set up a time-out, in case no packets arrive before we have to
       * iconify something */
      value.it_value.tv_usec = t_usecs;
      value.it_value.tv_sec = t_secs;

#ifdef __hpux
      if ((timeout > 0) && (Raised == 0))
	retval = select (fd_width, (int *) &in_fdset, 0, 0, &value.it_value);
      else
	retval = select (fd_width, (int *) &in_fdset, 0, 0, NULL);
#else
      if ((timeout > 0) && (Raised == 0))
	retval = select (fd_width, &in_fdset, 0, 0, &value.it_value);
      else
	retval = select (fd_width, &in_fdset, 0, 0, NULL);
#endif

      if (FD_ISSET (fd[1], &in_fdset))
	{
	  /* read a packet */
	  if (ReadASPacket (fd[1], header, &body) > 0)
	    {
	      if (header[1] == M_FOCUS_CHANGE)
		{
		  focus_win = body[0];
		  if (focus_win != 0)
		    Raised = 0;
		  if (timeout == 0)
		    {
		      if (focus_win != 0)
			SendInfo (fd, "Raise", focus_win);
		      Raised = 1;
		    }
		}
	      free (body);
	    }
	}
      else
	{
	  /* Raise the current focus window */
	  Raised = 1;
	  if (focus_win != 0)
	    {
	      SendInfo (fd, "Raise", focus_win);
	    }
	}
    }
}



/***********************************************************************
 *
 *  Procedure:
 *	SIGPIPE handler - SIGPIPE means afterstep is dying
 *
 ***********************************************************************/
void
DeadPipe (int nonsense)
{
  exit (0);
}
