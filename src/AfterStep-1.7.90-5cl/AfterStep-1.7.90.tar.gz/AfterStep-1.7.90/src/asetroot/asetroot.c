/*****************************************************************************
 * This software is Copyright (C) 1998 by Rafal Wierzbicki. I accept no
 * responsibility for anything this software may or may not do to your system
 * - you use it completely at your own risk. This software comes under the GPL
 * licence. See the COPYING file for full legal details.
 * $Id: asetroot.c,v 1.14 1999/02/10 08:27:41 rafal Exp $
 *****************************************************************************/

#include <X11/Intrinsic.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/cursorfont.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include "../../configure.h"
#include "../../include/module.h"
#include "../../include/aftersteplib.h"
#include "../../include/loadimg.h"
#include "../../include/XImage_utils.h"

static void ReadASPipe ();
static void ProcessMessage (unsigned long type, unsigned long *body);
static int put_image_on_root (char *path, int style, int desk);
void DeadPipe (int nothing);
static void tile (Pixmap tmp, Pixmap *pix);
static void scale (Pixmap tmp, Pixmap *pix);
static void aspect (Pixmap tmp, Pixmap *pix);
static void center (Pixmap tmp, Pixmap *pix);
static int setprop (Pixmap pix);

Cursor sleep_cursor;

#define CENTER 1
#define TILE 2
#define SCALE 3
#define STRETCH 4
#define MAXDESKS 12

char *MyName;
static Pixmap DeskPix[MAXDESKS];
static int CurrentDesk=0;
static int busy=0;

/* these are needed only when linking with libafterstep.so */
Display *dpy;
int screen;
Atom _XROOTPMAP_ID;

static int width, height, rgb_width, rgb_height;

typedef struct
{
  Window root;
  int rheight;
  int rwidth;
  int screen;
  Display *display;
  int depth;
  int fd_width;
  int fd[2];
  int x_fd;
}as_data;

typedef struct
{
  char *bg_image[MAXDESKS];
  char *app_name;
  char *configfile;
  char *base_config;
  char *pixmap_path;
  char *icon_path;
  int style[MAXDESKS];
  int entries;
}conf_data;

static as_data *asroot;
static conf_data *conf;

static void
shutdown ()
{
  Pixmap xpix;

  xpix = XCreatePixmap (asroot->display, asroot->root,
			asroot->rwidth, asroot->rheight, asroot->depth);
  tile (DeskPix[CurrentDesk], &xpix);
  setprop (xpix);
  XSetWindowBackgroundPixmap (asroot->display, asroot->root, xpix);
  XSetCloseDownMode (asroot->display, RetainPermanent);  
  XClearWindow (asroot->display, asroot->root);
  XFlush (asroot->display);
  XSync (asroot->display, False);
  XFreePixmap (asroot->display, xpix);
}

static int
error_handler (Display *disp, XErrorEvent *event)
{
  if ( event->request_code == X_KillClient)
    {
      fprintf (stderr, "%s: error clearing old _XROOTPMAP_ID\n", conf->app_name);
    }
  else
    fprintf (stderr, "%s: internal error, error code %d, request code %d, minor code %d\n  . Please email rafal@mcss.mcmaster.ca with te above information\n", conf->app_name, event->error_code, event->request_code, event->minor_code);
  return 0;
}

static int
get_style (char *strng)
{
  
  while (isspace(*strng))
    strng++;

  if (!mystrncasecmp (strng, "scale", 5))
    {
      return SCALE;
    }
  else if (!mystrncasecmp (strng, "tile", 4))
    {
      return TILE;
    }
  else if (!mystrncasecmp (strng, "center", 6))
    {
      return CENTER;
    }
  else if (!mystrncasecmp (strng, "aspect", 6))
    {
      return STRETCH;
    }
  else
    {
      fprintf (stderr, "%s: style %s unknown, defaulting to tile\n", conf->app_name, strng);
      return TILE;
    }
}

static void
write_conf ()
{
  FILE *fp;
  int i;
  char tmp[255];
  char style[10];

  fp = fopen (conf->configfile, "w");
  if (!fp)
    {
      fprintf (stderr, "%s: could not write to config file\n", conf->app_name);
      return;
    }

  for (i=0; i < MAXDESKS; i++)
    {
      memset (tmp, '\0', 255);
      memset (style, '\0', 255);
      if ( conf->bg_image[i] )
	{
	  switch (conf->style[i])
	    {
	    case SCALE:
	      strcpy (style, "scale");
	      break;
	    case STRETCH:
	      strcpy (style, "aspect");
	      break;
	    case TILE:
	      strcpy (style, "tile");
	      break;
	    case CENTER:
	      strcpy (style, "center");
	      break;
	    }
	  sprintf (tmp, "*%sImage%d %s %s\n", conf->app_name, i+1, 
		   conf->bg_image[i], style);
	  fputs (tmp, fp);
	}
    }
  fclose (fp);
}
  

static char 
*get_image (char *tline)
{
  char *retval;
  char *tmp;
   
  while (isspace(*tline))
    tline++;
  tmp = tline;
  while (!isspace(*tline))
    tline++;
  retval = safemalloc (tline - tmp + 1);
  memset (retval, '\0', tline - tmp + 1);
  strncat (retval, tmp , tline - tmp);
  return (retval);
}

/* ParseBaseOptions - parse the appropriate base.xxbpp file
 * sets pixmap and icon paths to appropriate values
 * based on ParseOptions, Rafal Wierzbicki 1998.
 */
static void
parse_base_options (char *file)
{
  char line[MAXLINELENGTH];
  char *tline;
  FILE *ptr;

  if ((ptr = fopen (file, "r")) == NULL)
    {
      fprintf (stderr, "%s: can\'t open config file %s", conf->app_name, file);
      exit (1);
    }

  tline = fgets (line, sizeof (line), ptr);
  while (tline != NULL)
    {
      while (isspace (*tline))
	tline++;
      if (strlen (tline) > 1)
	{
	  if (!mystrncasecmp (tline, "IconPath", 8))
	    CopyString (&conf->icon_path, tline + 8);
	  else if (!mystrncasecmp (tline, "PixmapPath", 10))
	    CopyString (&conf->pixmap_path, tline + 10);
	}
      tline = fgets (line, sizeof (line), ptr);
    }
  fclose (ptr);
}

static void
parse_options (conf_data *pconf)
{
  char *line, *tline, *tmp;
  FILE *ptr;
  int len, no;
  if ((ptr = fopen (pconf->configfile, "r")) == NULL)
    {
      fprintf (stderr, "%s, can\'t open config file %s", pconf->app_name, pconf->configfile);
      exit (1);
    }

  line = (char *) safemalloc (MAXLINELENGTH);
  len = strlen (pconf->app_name);

  pconf->entries = 0;

  while ((tline = fgets (line, MAXLINELENGTH, ptr)) != NULL)
    {     
      while (isspace (*tline))
        tline++;
      if ((*tline == '*') && (!mystrncasecmp (tline + 1, pconf->app_name, len)))
        { 
          tline += len + 1;  
          if (!mystrncasecmp (tline, "Image", 5))
	    {
	      no = atoi (tline + 5) - 1;
	      if (no > MAXDESKS +1)
		{
		  fprintf (stderr, "%s supports %d desks, out of range\n", conf->app_name,
			   MAXDESKS);
		  break;
		}
	      tmp = tline + 6;
	      while (isspace(*tmp))
		tmp++;
	      pconf->bg_image[no] = get_image (tmp);
	      tmp = tmp + strlen(pconf->bg_image[no]);
	      pconf->style[no] = get_style (tmp);
	      pconf->entries++;
	    }
	}
    }
  free (line);
  fclose (ptr);
}

static void
init_wallp()
{
  Screen *scr;
  
  asroot = (as_data *)safemalloc (sizeof(as_data));  

  if (!asroot || !conf)
    {
      fprintf (stderr, "Error allocating memory\n");
      exit (-1);
    }

  asroot->display = XOpenDisplay(NULL);
  if (!asroot->display)
    {
      fprintf (stderr, "Can't open display\nCheck your DISPLAY variable\n");
      exit (1);
    }
  asroot->screen = DefaultScreen (asroot->display);
  asroot->depth = DefaultDepth (asroot->display, asroot->screen);
  asroot->root = RootWindow(asroot->display, asroot->screen);
  scr = ScreenOfDisplay (asroot->display, asroot->screen);
  asroot->rwidth = scr->width;
  asroot->rheight = scr->height;
  sleep_cursor = XCreateFontCursor (asroot->display, XC_watch);
  _XROOTPMAP_ID = XInternAtom (asroot->display, "_XROOTPMAP_ID", False);
}

static int 
kill_prop ()
{
  Atom root_prop;
  Atom type;
  unsigned long length, after;
  int format;
  unsigned char *data;
  
  root_prop = XInternAtom (asroot->display, "_XROOTPMAP_ID", False);
  
  if (root_prop != None)
    {
      XGetWindowProperty (asroot->display, asroot->root, root_prop, 0L, 1L,
			  False, AnyPropertyType,&type,&format,&length,
			  &after,&data);
      if (type == XA_PIXMAP && data)
	{
	  XKillClient (asroot->display, *((Pixmap *)data));
	}
      return 1;
    }
  return 0;
}

/* Most of this function based on code from Esetroot
 * by Nat Friedman <ndf@mit.edu> with modifications by Gerald Britton
 * <gbritton@mit.edu> and Michael Jennings <mej@tcserv.com>
 */

static int
setprop (Pixmap pix)
{
  Atom root_prop;

  XSelectInput (asroot->display, asroot->root, NoEventMask);
  root_prop = XInternAtom (asroot->display, "_XROOTPMAP_ID", False);
  if (root_prop != None)
    {
      XChangeProperty (asroot->display, asroot->root, root_prop, XA_PIXMAP, 32,
		       PropModeReplace, (unsigned char *) &pix, 1);
      XFlush (asroot->display);
      XSelectInput (asroot->display, asroot->root, PropertyChangeMask);
      return True;
    }
  else
    {
      return False;
      XSelectInput (asroot->display, asroot->root, PropertyChangeMask);
    }
}

static void
pix_size (Pixmap pmap, unsigned int *w, unsigned int *h)
{
  Window root;
  int dummys;
  unsigned int dummy;

  XGetGeometry (asroot->display, pmap, &root, &dummys, &dummys, w, h, 
                &dummy, &dummy);
}

static void 
scale (Pixmap image, Pixmap *pix)
{
  XImage *src, *target;
  GC gc;
 
  src = XGetImage (asroot->display, image, 0, 0, rgb_width, rgb_height,
                   AllPlanes, ZPixmap);

  target = ScaleXImageToSize (src, width, height);

  gc = XCreateGC (asroot->display, image, 0, NULL);
  XPutImage (asroot->display, *pix, gc, target, 0, 0, 0, 0, width, height);
  XFreeGC (asroot->display, gc);
  XDestroyImage (target);
  XDestroyImage (src);
  XFreePixmap (asroot->display, image);
}

void
aspect (Pixmap image, Pixmap *pix)
{
  XImage *src, *target;
  GC gc;
  XGCValues gcv;
  int x, y, w, h;
  float math;
  
  if (rgb_height > rgb_width)
    {
      h = height;
      math = (float)h * ((float)rgb_width /
			 (float)rgb_height);
      w = (int)math;
      if (w > width)
	{
	  w = width;
	  math = (float) w * ((float)rgb_height / 
			      (float)rgb_width);
	  h=(int)math;
	}
    }
  else
    {
      w = width;
      math = (float)w * ((float)rgb_height /
			 (float)rgb_width);
      h = (int)math;
      if (h > height)
	{
	  h = height;
	  math = (float)h * ((float)rgb_width /
			     (float)rgb_height);
	  w = (int)math;
	}
    }
  
  x = width/2 - w/2;
  y = height/2 -  h/2;
  
  src = XGetImage (asroot->display, image, 0, 0, rgb_width, rgb_height,
                   AllPlanes, ZPixmap);
  target = ScaleXImageToSize (src, w, h);

  gcv.foreground=gcv.background=BlackPixel(asroot->display, asroot->screen);
  gc = XCreateGC(asroot->display, *pix, (GCForeground | GCBackground), &gcv);
  XFillRectangle (asroot->display, *pix, gc, 0, 0, width, height);

  XPutImage (asroot->display, *pix, gc, target, 0, 0, x, y, width, height);
  XFreeGC (asroot->display, gc);
  XDestroyImage (target);
  XDestroyImage (src);
  XFreePixmap (asroot->display, image);
}

static void
tile (Pixmap tmp, Pixmap *pix)
{
  GC gc;
  XGCValues gcv;

  gc = XCreateGC (asroot->display, *pix, 0, &gcv);	
  XFillRectangle (asroot->display, *pix, gc, 0, 0,
		  width, height);
  
  XSetTile (asroot->display, gc, tmp);
  XSetTSOrigin (asroot->display, gc, 0, 0);
  XSetFillStyle (asroot->display, gc, FillTiled);
  XFillRectangle (asroot->display, *pix, gc, 0, 0,
		  width, height);
  XFreeGC (asroot->display, gc);
  XFreePixmap (asroot->display, tmp);
  return;
}

static void
center (Pixmap tmp, Pixmap *pix)
{
  GC gc;
  XGCValues gcv;
  int x,y;

  x = width/2 - rgb_width/2;
  y = height/2 - rgb_height/2;

  gcv.foreground=gcv.background=BlackPixel(asroot->display, asroot->screen);
  gc = XCreateGC(asroot->display, *pix, (GCForeground | GCBackground), &gcv);
  XFillRectangle (asroot->display, *pix, gc, 0, 0, width, height);

  XSetTile (asroot->display, gc, tmp);
  XSetTSOrigin (asroot->display, gc, x, y);
  XSetFillStyle (asroot->display, gc, FillTiled);
  XFillRectangle (asroot->display, *pix, gc, x, y, rgb_width, rgb_height);
  XFreeGC (asroot->display, gc);
  XFreePixmap (asroot->display, tmp);
  return;
}

static int
put_image_on_root (char *path, int style, int desk)
{
  Pixmap image = None;
  char *tmp_path = NULL;

  if (path == NULL)
    return 0;

  tmp_path = findIconFile (path, conf->pixmap_path, R_OK);

  /* the image is not in pixmap path */
  if (!tmp_path)
    {
      /* that failed, let's if the path has been specified with the image */
      if (!CheckFile (path))
	{
	  /* this failed too, maybe ~ is has been specified with the path */
	  tmp_path = PutHome (path);
	  if (!CheckFile(tmp_path))
	    /* give up on this entry */
	    {
	      free (tmp_path);
	      return 0; 
	    }
	}
    }

  fprintf (stderr, "pior: image %s, style %d, desk %d\n", tmp_path, style, desk);

  if (DeskPix[desk] == None)
    {
      DeskPix[desk] = XCreatePixmap (asroot->display, asroot->root,
				     asroot->rwidth, asroot->rheight, asroot->depth);
      if (DeskPix[desk] == None)
	{
	  fprintf (stderr, "Failed to create pixmap for desk %d\n", desk);
	  exit (0);
	}
    }

  width = asroot->rwidth;
  height = asroot->rheight;

  image = LoadImage (asroot->display, asroot->root, -1, tmp_path);
  if (image == None)
    {
      fprintf (stderr, "Failed to load %s\n", tmp_path);
      return (0);
    }

  pix_size (image, &rgb_width, &rgb_height);

  if (width == rgb_width && height == rgb_height)
    style = TILE;

  switch (style)
  {
    case TILE:
      tile (image, &DeskPix[desk]);
      break;
    case SCALE:
      scale (image, &DeskPix[desk]);
      break;
    case CENTER:
      center (image, &DeskPix[desk]);
      break;
  case STRETCH:
    aspect (image, &DeskPix[desk]);
    break;
  default:
    conf->style[desk] = TILE;
    tile (image, &DeskPix[desk]);
    break;
  }
	
  if (DeskPix[desk] != None)
  {
    XSetWindowBackgroundPixmap (asroot->display, asroot->root, DeskPix[desk]);
    setprop (DeskPix[desk]);
    XClearWindow (asroot->display, asroot->root);
    XFlush (asroot->display);
    XSync (asroot->display, False);
    return 0;			
  }
  free (tmp_path);
  return 1;
}

/* ASPipe etc */
void
DeadPipe (int nothing)
{
  int i;
  write_conf ();
  for (i=0;i<MAXDESKS;i++)
    {
      if (conf->bg_image[i])
	free (conf->bg_image[i]);      
      if (i != CurrentDesk && DeskPix[i] != None)
	{
	  XFreePixmap (asroot->display, DeskPix[i]);
	}
    }
  XFreeCursor (asroot->display, sleep_cursor);
  shutdown();
  free (conf->pixmap_path);
  free (conf->icon_path);
  free (conf->configfile);
  free (conf->base_config);
  free (conf);
  free (asroot);
#ifdef DEBUG_ALLOCS
 print_unfreed_mem();
#endif 
  exit(0);
}
static void
event_handler ()
{
  XEvent Event;

  while (XPending (asroot->display))
    {
      XNextEvent (asroot->display, &Event);
      switch (Event.type)
	{
	case PropertyNotify:
	  if (Event.xproperty.atom == _XROOTPMAP_ID && 
	      Event.xproperty.window == asroot->root)
	    {
	      fprintf (stderr, "%s: another program is accessing the root pixmap, aborting\n",
		       conf->app_name);
	      DeadPipe (0);
	    }
	  break;
	}
    }
}
/******************************************************************************
  EndLessLoop -  Read and redraw until we get killed, blocking when can't read
******************************************************************************/
static void
EndLessLoop ()
{
  fd_set readset;
  struct timeval tv;

  while (1)
    {
      FD_ZERO (&readset);
      FD_SET (asroot->fd[1], &readset);
      FD_SET (asroot->x_fd, &readset);
      tv.tv_sec = 0;
      tv.tv_usec = 0;
#ifdef __hpux
      if (!select (asroot->fd_width, (int *) &readset, NULL, NULL, &tv))
	{
	  XPending (asroot->display);
	  FD_ZERO (&readset);
	  FD_SET (asroot->fd[1], &readset);
	  FD_SET (asroot->x_fd, &readset);
	  select (asroot->fd_width, (int *) &readset, NULL, NULL, NULL);
	}
#else
      if (!select (asroot->fd_width, &readset, NULL, NULL, &tv))
	{
	  XPending (asroot->display);
	  FD_ZERO (&readset);
	  FD_SET (asroot->fd[1], &readset);
	  FD_SET (asroot->x_fd, &readset);
	  select (asroot->fd_width, &readset, NULL, NULL, NULL);
	}
#endif
      if (FD_ISSET (asroot->x_fd, &readset))
	event_handler ();
      if (!FD_ISSET (asroot->fd[1], &readset))
	continue;
      ReadASPipe ();
    }
}

/******************************************************************************
  ReadASPipe - Read a single message from the pipe from AfterStep
    Originally Loop() from Ident:
      Copyright 1994, Robert Nation and Nobutaka Suzuki.
******************************************************************************/
static void
ReadASPipe ()
{
  unsigned long header[3], *body;
  if (ReadASPacket (asroot->fd[1], header, &body) > 0)
    {
      if (!busy)
        ProcessMessage (header[1], body);
      else
	fprintf (stderr, "I'm busy\n");
      free (body);
    }
}

static void
ProcessMessage (unsigned long type, unsigned long *body)
{
  static int OldDesk= 0;  
  char tmp[255];

  switch (type)
    {
    case M_NEW_DESK:
      if (body[0] != 10000)
	{	  
	  OldDesk = CurrentDesk;
	  CurrentDesk = (int)body[0];

	  if (CurrentDesk >= MAXDESKS)
	    break;
	  if (OldDesk != CurrentDesk)
	    {	      
	      if (DeskPix[CurrentDesk] == None)
		{
		  if (!conf->bg_image[CurrentDesk])
		    {
		      fprintf (stderr, "No image for desk %d, not updating\n", CurrentDesk);
		      return;
		    }
		  if (!busy)
		    {
		      XGrabPointer (asroot->display, asroot->root, True,
				      ButtonPressMask | ButtonReleaseMask,
				      GrabModeAsync, GrabModeAsync,
				      asroot->root, sleep_cursor, CurrentTime);
		      busy = 1;
		      put_image_on_root (conf->bg_image[CurrentDesk], 
					 conf->style[CurrentDesk], CurrentDesk);
		      XSync (asroot->display, True);
		      busy = 0;
		      XUngrabPointer (asroot->display, CurrentTime);
		    }
		}
	      else
		{
		  XSetWindowBackgroundPixmap (asroot->display, asroot->root, 
					      DeskPix[CurrentDesk]);
		  setprop (DeskPix[CurrentDesk]);
		  XClearWindow (asroot->display, asroot->root);
		  XFlush (asroot->display);
		}
	    }
	}
      break;
    case M_NEW_BACKGROUND:
      /* not implemented properly yet, works but the config file is not updated */
      memset (tmp, '\0', 255);
      sprintf (tmp, "%s/non-configurable/%d_background", AFTER_DIR, CurrentDesk);
      free (conf->bg_image[CurrentDesk]);
      conf->bg_image[CurrentDesk] = PutHome(tmp);
      conf->style[CurrentDesk] = TILE;
      conf->entries++;
      XGrabPointer (asroot->display, asroot->root, True,
		    ButtonPressMask | ButtonReleaseMask,
		    GrabModeAsync, GrabModeAsync,
		    asroot->root, sleep_cursor, CurrentTime);
      put_image_on_root (conf->bg_image[CurrentDesk], 
			 conf->style[CurrentDesk], CurrentDesk);
      XFlush (asroot->display);
      XSync (asroot->display, True);
      XUngrabPointer (asroot->display, CurrentTime);
      break;
    }
}

/******************************************************************************
  SendASPipe - Send a message back to AfterStep 
    Based on SendInfo() from Ident:
      Copyright 1994, Robert Nation and Nobutaka Suzuki.
******************************************************************************/
static void
SendASPipe (char *message, unsigned long window)
{
  int w;
  char *hold, *temp, *temp_msg;
  hold = message;

  while (1)
    {
      temp = strchr (hold, ',');
      if (temp != NULL)
	{
	  temp_msg = safemalloc (temp - hold + 1);
	  strncpy (temp_msg, hold, (temp - hold));
	  temp_msg[(temp - hold)] = '\0';
	  hold = temp + 1;
	}
      else
	temp_msg = hold;

      write (asroot->fd[0], &window, sizeof (unsigned long));
      w = strlen (temp_msg);
      write (asroot->fd[0], &w, sizeof (int));
      write (asroot->fd[0], temp_msg, w);

      /* keep going */
      w = 1;
      write (asroot->fd[0], &w, sizeof (int));

      if (temp_msg != hold)
	free (temp_msg);
      else
	break;
    }
}

void version(void)
{
  printf("%s version %s\n", MyName, VERSION);
  exit(0);
}

void usage(void)
{
  printf("Usage:\n"
	 "%s [--version] [--help]\n", MyName);
  exit(0);
}

int main (int argc, char **argv)
{
  char tmp[128];
  FILE *fp;
  char *temp;
  int i, fd[2];
  char *global_config_file = NULL;

  /* Save our program name - for error messages */
  temp = strrchr (argv[0], '/');
  MyName = temp ? temp + 1 : argv[0];

  for (i = 1 ; i < argc && *argv[i] == '-' ; i++)
    {
      if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))
	usage ();
      else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--version"))
	version ();
      else if (!strcmp(argv[i], "-w") || !strcmp(argv[i], "--window"))
	i++;
      else if (!strcmp(argv[i], "-c") || !strcmp(argv[i], "--context"))
	i++;
      else if (!strcmp(argv[i], "-f") && i + 1 < argc)
	global_config_file = argv[++i];
    }

  /* Dead pipe == dead AfterStep */
  signal (SIGPIPE, DeadPipe);

  if ((dpy = XOpenDisplay ("")) == NULL)
    {
      fprintf (stderr, "%s: couldn't open display %s\n",
	       MyName, XDisplayName (""));
      exit (1);
    }
  screen = DefaultScreen (dpy);

  /* connect to AfterStep */
  temp = module_get_socket_property(RootWindow(dpy, screen));
  fd[0] = fd[1] = module_connect (temp);
  XFree (temp);
  if (fd[0] < 0)
    {
      fprintf (stderr, "%s: unable to establish connection to AfterStep\n", MyName);
      exit (1);
    }
  temp = safemalloc (9 + strlen(MyName) + 1);
  sprintf (temp, "SET_NAME %s", MyName);
  SendInfo (fd, temp, None);
  free (temp);
  
  conf = (conf_data *)safemalloc (sizeof(conf_data));
  if (!conf)
    {
      fprintf (stderr, "Error allocating memory\n");
      return (-1);
    }
  conf->app_name = MyName;

  /* find out whether we're using the system wide config file
   * or ~/G/L/A
   * abort program if config file not found
   */

  /* this is for the old style config file .steprc */
  if (global_config_file != NULL)
    {
      conf->configfile = PutHome(global_config_file);
      
      if ( (fp = fopen(conf->configfile, "r"))==NULL)
	{
	  fprintf (stderr, "%s: config file %s not found\n", conf->app_name,
		   conf->configfile);
	  return (-1);
	}
      conf->base_config = mystrdup(conf->configfile);
    }
  /* new style config, ~/G/L/A/asetroot or /u/l/s/a/asetroot */
  else
    {
      memset (tmp, 128, '\0');
      sprintf (tmp, "%s/base.%dbpp", AFTER_DIR, DefaultDepth (dpy, screen));
      conf->base_config = PutHome (tmp);
      if ( (fp = fopen(conf->base_config, "r"))==NULL)
	{
	  sprintf (tmp, "%s/base.%dbpp", AFTER_SHAREDIR, DefaultDepth (dpy, screen));
	  free (conf->base_config);
	  conf->base_config = PutHome (tmp);
	  if ( (fp = fopen(conf->base_config, "r")) == NULL)
	    {
	      fprintf (stderr, "%s: base config file not found\n", conf->app_name);
	      return (-1);
	    }
	}   

      memset (tmp, 128, '\0');
      sprintf (tmp, "%s/asetroot", AFTER_DIR);
      conf->configfile = PutHome (tmp);
      if ( (fp = fopen(conf->configfile, "r"))==NULL)
	{
	  sprintf (tmp, "%s/asetroot", AFTER_SHAREDIR);
	  free (conf->configfile);
	  conf->configfile = PutHome (tmp);
	  if ( (fp = fopen(conf->configfile, "r")) == NULL)
	    {
	      fprintf (stderr, "%s: config file not found\n", conf->app_name);
	      return (-1);
	    }
	}   
    }
  fclose (fp);
   
  /* initialize X stuff */
  init_wallp ();

  for (i = 0 ; i < MAXDESKS ; i++)
    conf->bg_image[i] = NULL;

  /* read in the options from the config file */
  parse_options (conf);

  /* pixmap path and icon path */
  parse_base_options (conf->base_config);

  /* this will make sure the config file will be created in ~/g/l/a */
  free (conf->configfile);
  sprintf (tmp, "%s/asetroot", AFTER_DIR);
  conf->configfile = PutHome (tmp);

  /* fd's */
  asroot->fd[0] = fd[0];
  asroot->fd[1] = fd[1];
  asroot->x_fd = XConnectionNumber (asroot->display);
  asroot->fd_width = GetFdWidth ();
  
  /* let AS know we want to know what's happening to the desks*/
  SendASPipe ("Desk", 0);

  XSetErrorHandler (error_handler);

  kill_prop ();
  /* I'm assuming that asetroot is started by afterstep, so the initial desk is 0*/
  XGrabPointer (asroot->display, asroot->root, True,
		ButtonPressMask | ButtonReleaseMask,
		GrabModeAsync, GrabModeAsync,
		asroot->root, sleep_cursor, CurrentTime);
  put_image_on_root (conf->bg_image[CurrentDesk], 
		     conf->style[CurrentDesk], CurrentDesk);
  XSync (asroot->display, True);
  XUngrabPointer (asroot->display, CurrentTime);
  EndLessLoop ();
  
  return 0;
}
