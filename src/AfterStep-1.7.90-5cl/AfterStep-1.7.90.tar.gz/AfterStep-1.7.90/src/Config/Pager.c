/*
 * Copyright (c) 1998 Sasha Vasko <sashav@sprintmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.   See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */


#include "../../configure.h"

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>

#include <stdlib.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xatom.h>
#include <X11/Intrinsic.h>

#include "../../include/aftersteplib.h"
#include "../../include/afterstep.h"
#include "../../include/menus.h"
#include "../../include/style.h"
#include "../../include/mystyle.h"
#include "../../include/parser.h"
#include "../../include/confdefs.h"

/*****************************************************************************
 * 
 * This routine is responsible for reading and parsing the config file
 *
 ****************************************************************************/

TermDef PagerTerms[] = 
{
{0,"Geometry"    ,  	 8, TT_GEOMETRY,    	PAGER_GEOMETRY_ID, 	NULL },
{0,"IconGeometry", 	12, TT_GEOMETRY,    	PAGER_ICON_GEOMETRY_ID, NULL },
{0,"Align",         	 5, TT_INTEGER, 	PAGER_ALIGN_ID, 	NULL },
{0,"DontDrawBg",    	 8, TT_FLAG, 		PAGER_DRAW_BG_ID, 	NULL },
{0,"FastStartup",  	11, TT_FLAG, 		PAGER_FAST_STARTUP_ID, 	NULL },
{0,"SetRootOnStartup", 	16, TT_FLAG,	 	PAGER_SET_ROOT_ID, 	NULL },
{0,"SmallFont",    	 9, TT_FONT, 		PAGER_SMALL_FONT_ID, 	NULL },
{0,"StartIconic",  	11, TT_FLAG, 		PAGER_START_ICONIC_ID, 	NULL },
{0,"Rows",          	 4, TT_INTEGER, 	PAGER_ROWS_ID, 		NULL },
{0,"Columns",       	 7, TT_INTEGER, 	PAGER_COLUMNS_ID, 	NULL },
{0,"StickyIcons",  	11, TT_FLAG, 		PAGER_STICKY_ICONS_ID, 	NULL },
{TF_INDEXED,"Label"       ,  	 5, TT_TEXT,    PAGER_LABEL_ID, 	NULL },
{TF_INDEXED,"Style"       ,  	 5, TT_TEXT, 	PAGER_STYLE_ID, 	NULL },
{TF_INDEXED,"DesktopImage", 	12, TT_FILENAME,PAGER_DESKTOP_IMAGE_ID, NULL },
{TF_DONT_SPLIT,"XImageLoaderArgs", 15, TT_TEXT, PAGER_LOADER_ARGS_ID, 	NULL },
/* now special cases that should be processed by it's own handlers */ 
{TF_SPECIAL_PROCESSING|TF_DONT_REMOVE_COMMENTS,"Decoration"  , 	10, TT_SPECIAL, PAGER_DECORATION_ID, NULL },
{TF_SPECIAL_PROCESSING|TF_DONT_REMOVE_COMMENTS,"MyStyle", 	 7, TT_SPECIAL, PAGER_MYSTYLE_ID, NULL },
{TF_SPECIAL_PROCESSING|TF_DONT_REMOVE_COMMENTS,"Balloons", 	 8, TT_FLAG, 	PAGER_BALLOONS_ID, NULL },
{TF_SPECIAL_PROCESSING|TF_DONT_REMOVE_COMMENTS,"BalloonFore", 	11, TT_COLOR,  	PAGER_BALLOONS_ID, NULL },
{TF_SPECIAL_PROCESSING|TF_DONT_REMOVE_COMMENTS,"BalloonBack", 	11, TT_COLOR, 	PAGER_BALLOONS_ID, NULL },
{TF_SPECIAL_PROCESSING|TF_DONT_REMOVE_COMMENTS,"BalloonFont",	11, TT_FONT, 	PAGER_BALLOONS_ID, NULL },
{TF_SPECIAL_PROCESSING|TF_DONT_REMOVE_COMMENTS,"BalloonBorderWidth", 18, TT_INTEGER, PAGER_BALLOONS_ID, NULL },
{TF_SPECIAL_PROCESSING|TF_DONT_REMOVE_COMMENTS,"BalloonBorderColor", 18, TT_COLOR,   PAGER_BALLOONS_ID, NULL },
{TF_SPECIAL_PROCESSING|TF_DONT_REMOVE_COMMENTS,"BalloonYOffset",14, TT_INTEGER, PAGER_BALLOONS_ID, NULL },
{TF_SPECIAL_PROCESSING|TF_DONT_REMOVE_COMMENTS,"BalloonDelay", 	12, TT_INTEGER, PAGER_BALLOONS_ID, NULL },
{0,NULL,0,0,0 }
};

SyntaxDef PagerSyntax = 
{
'\n',
'\0',
PagerTerms
};

TermDef PagerDecorationTerms[] = 
{
{TF_NO_MYNAME_PREPENDING,"NoDeskLabel", 	11,TT_FLAG,	PAGER_DECOR_NOLABEL_ID 		,NULL },
{TF_NO_MYNAME_PREPENDING,"NoPageSeparator", 	15,TT_FLAG,	PAGER_DECOR_NOSEPARATOR_ID 	,NULL },
{TF_NO_MYNAME_PREPENDING,"NoSelection", 	11,TT_FLAG,	PAGER_DECOR_NOSELECTION_ID 	,NULL },
{TF_NO_MYNAME_PREPENDING,"SelectionColor", 	14,TT_COLOR,	PAGER_DECOR_SEL_COLOR_ID 	,NULL },
{TF_NO_MYNAME_PREPENDING,"GridColor", 	 9,TT_COLOR,	PAGER_DECOR_GRID_COLOR_ID 	,NULL },
{TF_NO_MYNAME_PREPENDING,"DeskBorderWidth", 	15,TT_INTEGER,	PAGER_DECOR_BORDER_WIDTH_ID 	,NULL },
{TF_NO_MYNAME_PREPENDING,"DeskBorderColor", 	15,TT_COLOR,	PAGER_DECOR_BORDER_COLOR_ID	,NULL },
{TF_NO_MYNAME_PREPENDING,"LabelBelowDesk", 	14,TT_FLAG,	PAGER_DECOR_LABEL_BELOW_ID	,NULL },
{TF_NO_MYNAME_PREPENDING,"HideInactiveLabels",18,TT_FLAG,	PAGER_DECOR_HIDE_INACTIVE_ID 	,NULL },
{0,NULL,0,0,0 }
};

SyntaxDef PagerDecorationSyntax = 
{
',',
'\n',
PagerDecorationTerms
};

int PagerSpecialFunc (ConfigDef* conf_def, FreeStorageElem** storage)
{
    switch( conf_def->current_term->id )
    {
	case PAGER_DECORATION_ID :
	    {
	      ConfigDef* DecorConfig = InitConfigReader( conf_def->myname, &PagerDecorationSyntax, CDT_Data, (void*)(conf_def->current_data), TERM_HASH_SIZE, NULL );
	        PrintConfigReader(DecorConfig);
    		ParseConfig(DecorConfig, storage); 
		PrintFreeStorage( *storage ); 
		DestroyConfig( DecorConfig );
	    }
	    break ;
	case PAGER_MYSTYLE_ID	 :
	    mystyle_parse (conf_def->tline + 7, conf_def->fp, &pixmapPath, NULL);
	    break ;
	case PAGER_BALLOONS_ID	 :
	    balloon_parse (conf_def->tline, conf_def->fp);	
	    FlushConfigBuffer(conf_def);
	    break ;
    }

    return 1 ;
}

PagerConfig* CreatePagerConfig( int ndesks )
{
  PagerConfig *config = (PagerConfig*) safemalloc( sizeof(PagerConfig));
    /* let's initialize Pager's config with some nice values: */
    InitMyGeometry( &(config->icon_geometry));
    InitMyGeometry( &(config->geometry));
    config->labels = CreateStringArray(ndesks);
    config->styles = CreateStringArray(ndesks); 
    config->desktop_images = CreateStringArray(ndesks);
    config->loader_args = CreateStringArray(ndesks); 
    config->align = 0;
    config->flags = PAGER_FLAGS_DEFAULT;
    config->small_font_name = NULL;
    config->rows = 1 ;
    config->columns = ndesks ;
    config->selection_color = NULL;
    config->grid_color = NULL;
    config->border_width = 1;
    config->border_color = NULL;
    
    config->more_stuff = NULL ;
    
    return config ;
}

void DestroyPagerConfig(PagerConfig* config)
{
    free( config->labels );
    free( config->styles );
    free( config->desktop_images );
    free( config->loader_args );
    DestroyFreeStorage (&(config->more_stuff));
    free( config );
}

PagerConfig * ParsePagerOptions( const char* filename, char* myname, int desk1, int desk2)
{    
  ConfigDef * PagerConfigReader = InitConfigReader( myname, &PagerSyntax, CDT_Filename, (void*)filename, TERM_HASH_SIZE, PagerSpecialFunc );
  PagerConfig *config = CreatePagerConfig( (desk2-desk1)+1 );

  FreeStorageElem *Storage = NULL, *pCurr;
  ConfigItem item ;
    
    if( !PagerConfigReader ) return config ;

    item.memory = NULL ;
    PrintConfigReader(PagerConfigReader);
    ParseConfig(PagerConfigReader, &Storage); 
    PrintFreeStorage( Storage );

    /* getting rid of all the crap first */
    StorageCleanUp( &Storage, &(config->more_stuff), FS_DISABLED ); 
    
    for( pCurr = Storage ; pCurr ; pCurr = pCurr->next )
    {
	if( pCurr->term == NULL ) continue ;

	if( pCurr->term->type == TT_FLAG )
	    switch( pCurr->term->id )
	    {
		case PAGER_DRAW_BG_ID	:
			config->flags &= ~REDRAW_BG ;
			break ;
		case PAGER_START_ICONIC_ID:
			config->flags |= START_ICONIC;
			break ;
		case PAGER_FAST_STARTUP_ID	:
			config->flags |= FAST_STARTUP;
	      		break ;
		case PAGER_SET_ROOT_ID	:
			config->flags |= SET_ROOT_ON_STARTUP;
			break ;
    		case PAGER_STICKY_ICONS_ID	:	
			config->flags |= STICKY_ICONS;
			break ;	
		/* rest comes from PagerDecoration */
    		case PAGER_DECOR_NOLABEL_ID :
		        config->flags &= ~USE_LABEL;
			break ;		
		case PAGER_DECOR_NOSEPARATOR_ID:
		        config->flags &= ~PAGE_SEPARATOR;
			break ;
		case PAGER_DECOR_NOSELECTION_ID:
		        config->flags &= ~SHOW_SELECTION;
			break ;	
    		case PAGER_DECOR_LABEL_BELOW_ID:
			config->flags |= LABEL_BELOW_DESK ;
			break ;
		case PAGER_DECOR_HIDE_INACTIVE_ID:
			config->flags |= HIDE_INACTIVE_LABEL ; 
			break ; 	
	    }
	else
	{	
	    if( !ReadConfigItem( &item, pCurr )) continue ;
	    if( (pCurr->term->flags & TF_INDEXED)&&
		(item.index < desk1 || item.index > desk2) )
	    {
	        item.ok_to_free = 1 ;
	        continue ;
	    }
	    
	    switch( pCurr->term->id )
	    {
		case PAGER_GEOMETRY_ID :
			config->geometry = item.data.geometry ;
			break ;
    		case PAGER_ICON_GEOMETRY_ID:
			config->icon_geometry = item.data.geometry ;
			break ;
		case PAGER_ALIGN_ID	:
			config->align = (int)item.data.integer ;		    
			break ;	
		case PAGER_SMALL_FONT_ID:
			config->small_font_name = item.data.string ;
			break ;	
		case PAGER_ROWS_ID	:
			config->rows = (int)item.data.integer ;		    
			break ;	
		case PAGER_COLUMNS_ID:
			config->columns = (int)item.data.integer ;		    		    
			break ;
		case PAGER_LABEL_ID :
			config->labels[item.index-desk1] = item.data.string ;		    
			break ;	
		case PAGER_STYLE_ID	:
    			config->styles[item.index-desk1] = item.data.string ;		    
			break ;	
		case PAGER_DESKTOP_IMAGE_ID:
			config->desktop_images[item.index-desk1] = item.data.string ;		    
			break ;
		case PAGER_LOADER_ARGS_ID:
			config->loader_args[item.index-desk1] = item.data.string ;		    
			break ;	
		case PAGER_DECOR_SEL_COLOR_ID :
			config->selection_color = item.data.string ;		    
			config->flags |=SHOW_SELECTION ;
			break ;
		case PAGER_DECOR_GRID_COLOR_ID:
			config->grid_color = item.data.string ;		    		    
			config->flags |= DIFFERENT_GRID_COLOR ;
			break ;
		case PAGER_DECOR_BORDER_WIDTH_ID:
			config->border_width = item.data.integer ;		    
			break ; 	
	        case PAGER_DECOR_BORDER_COLOR_ID:
			config->border_color = item.data.string ;		    
			config->flags |= DIFFERENT_BORDER_COLOR;
			break ;	
	        default : item.ok_to_free = 1 ;
	    }
        }
    }
    
    DestroyConfig( PagerConfigReader );
    DestroyFreeStorage( &Storage ); 

    return config ;

}

/* returns:
 *		0 on success
 *		1 if data is empty
 *		2 if ConfigWriter cannot be initialized
 *
 */
int WritePagerOptions(  const char* filename, char* myname, int desk1, int desk2, PagerConfig *config, unsigned long flags )
{
  ConfigDef *PagerConfigWriter = NULL;
  FreeStorageElem *Storage = NULL;
  char* Decorations = NULL;
      
    if( config == NULL ) return 1;
    if( (PagerConfigWriter = InitConfigWriter( myname, &PagerSyntax,CDT_Filename, (void*)filename, TERM_HASH_SIZE ))== NULL ) 
	return 2;
    
    CopyFreeStorage( &Storage, config->more_stuff );
    
    /* building free storage here */
    /* geometry */
    Geometry2FreeStorage( &PagerSyntax, &Storage, &(config->geometry), PAGER_GEOMETRY_ID ) ;
    /* icon_geometry*/
    Geometry2FreeStorage( &PagerSyntax, &Storage, &(config->icon_geometry), PAGER_ICON_GEOMETRY_ID ) ;
    /* labels*/
    StringArray2FreeStorage( &PagerSyntax, &Storage, config->labels, desk1, desk2, PAGER_LABEL_ID ) ;
    /* styles*/ 
    StringArray2FreeStorage( &PagerSyntax, &Storage, config->styles, desk1, desk2, PAGER_STYLE_ID ) ;
    /* desktop_images*/
    StringArray2FreeStorage( &PagerSyntax, &Storage, config->desktop_images, desk1, desk2, PAGER_DESKTOP_IMAGE_ID ) ;
    /* loader_args */
    StringArray2FreeStorage( &PagerSyntax, &Storage, config->loader_args, desk1, desk2, PAGER_LOADER_ARGS_ID ) ;
    /* align */
    Integer2FreeStorage( &PagerSyntax, &Storage, config->align, PAGER_ALIGN_ID ) ;
    /* flags */
    if( !(config->flags&REDRAW_BG) )
	Flag2FreeStorage( &PagerSyntax, &Storage, PAGER_DRAW_BG_ID );
    if( config->flags&START_ICONIC )
	Flag2FreeStorage( &PagerSyntax, &Storage, PAGER_START_ICONIC_ID );
    if(	config->flags&FAST_STARTUP )
	Flag2FreeStorage( &PagerSyntax, &Storage, PAGER_FAST_STARTUP_ID	);
    if( config->flags&SET_ROOT_ON_STARTUP )
	Flag2FreeStorage( &PagerSyntax, &Storage, PAGER_SET_ROOT_ID	);
    if(	config->flags&STICKY_ICONS )
    	Flag2FreeStorage( &PagerSyntax, &Storage, PAGER_STICKY_ICONS_ID	);

    /* small_font_name*/
    String2FreeStorage( &PagerSyntax, &Storage, config->small_font_name, PAGER_SMALL_FONT_ID ) ;
    /* rows*/
    Integer2FreeStorage( &PagerSyntax, &Storage, config->rows, PAGER_ROWS_ID ) ;
    /* columns */
    Integer2FreeStorage( &PagerSyntax, &Storage, config->columns, PAGER_COLUMNS_ID ) ;
    
    /* now storing PagerDecorations */
    {
      ConfigDef* DecorConfig = InitConfigWriter( myname, &PagerDecorationSyntax, CDT_Data, NULL, TERM_HASH_SIZE );
      FreeStorageElem *DecorStorage = NULL ;

	/* flags */
        if( !(config->flags&~USE_LABEL) )
    	    Flag2FreeStorage( &PagerDecorationSyntax, &DecorStorage, PAGER_DECOR_NOLABEL_ID );
        if( !(config->flags&PAGE_SEPARATOR) )
	    Flag2FreeStorage( &PagerDecorationSyntax, &DecorStorage, PAGER_DECOR_NOSEPARATOR_ID );
        if( !(config->flags&SHOW_SELECTION) )
    	    Flag2FreeStorage( &PagerDecorationSyntax, &DecorStorage, PAGER_DECOR_NOSELECTION_ID );
	if( config->flags&LABEL_BELOW_DESK )
    	    Flag2FreeStorage( &PagerDecorationSyntax, &DecorStorage, PAGER_DECOR_LABEL_BELOW_ID );
	if( config->flags&HIDE_INACTIVE_LABEL ) 
    	    Flag2FreeStorage( &PagerDecorationSyntax, &DecorStorage, PAGER_DECOR_HIDE_INACTIVE_ID );
	
	/* selection_color */
        String2FreeStorage( &PagerDecorationSyntax, &DecorStorage, config->selection_color, PAGER_DECOR_SEL_COLOR_ID ) ;
	/* border_width*/
        Integer2FreeStorage( &PagerDecorationSyntax, &DecorStorage, config->border_width, PAGER_DECOR_BORDER_WIDTH_ID ) ;
	/* grid_color*/
        String2FreeStorage( &PagerDecorationSyntax, &DecorStorage, config->grid_color, PAGER_DECOR_GRID_COLOR_ID ) ;
	/* border_color*/
        String2FreeStorage( &PagerDecorationSyntax, &DecorStorage, config->border_color, PAGER_DECOR_BORDER_COLOR_ID ) ;

	WriteConfig(DecorConfig, &DecorStorage, CDT_Data, (void**)&Decorations, 0 ); 
	DestroyConfig( DecorConfig );
	if( DecorStorage )
    	    DestroyFreeStorage( &DecorStorage ); 
    
        String2FreeStorage( &PagerSyntax, &Storage, Decorations, PAGER_DECORATION_ID ) ;
	if( Decorations )
	{
		free( Decorations );
		Decorations = NULL ;
	}
    }
    
    /* writing config into the file */
    WriteConfig( PagerConfigWriter, &Storage,  CDT_Filename, (void**)&filename, flags );
    DestroyConfig( PagerConfigWriter );

    if( Storage )
    {
	fprintf( stderr, "\n%s:Config Writing warning: Not all Free Storage discarded! Trying again...", myname);
	DestroyFreeStorage( &Storage ); 
        fprintf( stderr, (Storage!=NULL)?" failed.":" success.");
    }
    return 0 ;
}
