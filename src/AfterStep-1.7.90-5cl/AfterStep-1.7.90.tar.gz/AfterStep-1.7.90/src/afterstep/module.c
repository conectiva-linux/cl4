/*
 * Copyright (c) 1999 Ethan Fischer <allanon@crystaltokyo.com>
 * Copyright (C) 1998 Guylhem Aznar
 * Copyright (C) 1993 Robert Nation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/***********************************************************************
 *
 * code for launching afterstep modules.
 *
 ***********************************************************************/

#include "../../configure.h"

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <stdarg.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h> /* for struct sockaddr_un */

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/Xatom.h>

#include "../../include/aftersteplib.h"
#include "../../include/afterstep.h"
#include "../../include/menus.h"
#include "../../include/parse.h"
#include "../../include/misc.h"
#include "../../include/style.h"
#include "../../include/screen.h"
#include "../../include/module.h"

int module_fd;
int npipes;
int *module_pipe;
int *pipeOn;
char **pipeName;

unsigned long *PipeMask;
struct queue_buff_struct **pipeQueue;
extern char *global_base_file;

AFTER_INLINE int PositiveWrite (int module, unsigned long *ptr, int size);
void DeleteQueueBuff (int module);
void AddToQueue (int module, unsigned long *ptr, int size, int done);

int module_setup_socket (Window w, const char* display_string)
{
  char* str;
  char* tmp;

  tmp = safemalloc(strlen(AFTER_NONCF) + 9 + strlen(display_string) + 1);
  sprintf(tmp, "%s/connect.%s", AFTER_NONCF, display_string);
  str = PutHome(tmp);
  free (tmp);
  XChangeProperty (dpy, w, _AS_MODULE_SOCKET, XA_STRING, 8, 
		   PropModeReplace, (unsigned char*)str, strlen(str));
  module_fd = module_listen(str);
  free(str);

  XSync(dpy, 0);

  return (module_fd >= 0);
}

/* create a named UNIX socket, and start watching for connections */
int module_listen(const char* socket_name)
{
  int fd;

  /* create an unnamed socket */
  if ((fd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
    fprintf(stderr, "%s: unable to create UNIX socket: ", MyName);
    perror("");
  }

  /* remove the socket file */
  if (fd >= 0) {
    if (unlink(socket_name) == -1 && errno != ENOENT) {
      fprintf(stderr, "%s: unable to delete file '%s': ", MyName, socket_name);
      perror("");
      close(fd);
      fd = -1;
    }
  }

  /* bind the socket to a name */
  if (fd >= 0) {
    struct sockaddr_un name;

    name.sun_family = AF_UNIX;
    strcpy(name.sun_path, socket_name);

    if (bind(fd, (struct sockaddr *)&name, sizeof(struct sockaddr_un)) == -1) {
      fprintf(stderr, "%s: unable to bind socket to name '%s': ", MyName, socket_name);
      perror("");
      close(fd);
      fd = -1;
    }
  }

  /* start listening for incoming connections */
  if (fd >= 0) {
    if (listen(fd, 254) == -1) {
      fprintf(stderr, "%s: unable to listen on socket: ", MyName);
      perror("");
      close(fd);
      fd = -1;
    }
  }

  /* set non-blocking I/O mode */
  if (fd >= 0) {
    if (fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK) == -1) {
      fprintf(stderr, "%s: unable to set non-blocking I/O: ", MyName);
      perror("");
      close(fd);
      fd = -1;
    }
  }

  /* mark as close-on-exec so other programs won't inherit the socket */
  if (fd >= 0) {
    if (fcntl (fd, F_SETFD, 1) == -1) {
      fprintf(stderr, "%s: unable to set close-on-exec for socket: ", MyName);
      perror("");
      close(fd);
      fd = -1;
    }
  }

  return fd;
}

int module_accept(int socket_fd)
{
  int fd;
  int len = sizeof(struct sockaddr_un);
  struct sockaddr_un name;

  fd = accept(socket_fd, (struct sockaddr *)&name, &len);

  if (fd < 0 && errno != EWOULDBLOCK) {
    fprintf(stderr, "%s: error accepting connection: ", MyName);
    perror("");
  }

  /* mark as close-on-exec so other programs won't inherit the socket */
  if (fd >= 0) {
    if (fcntl (fd, F_SETFD, 1) == -1) {
      fprintf(stderr, "%s: unable to set close-on-exec for socket: ", MyName);
      perror("");
      close(fd);
      fd = -1;
    }
  }

  if (fd >= 0) {
    int i;
    /* Look for an available pipe slot */
    i = 0;
    while ((i < npipes) && (module_pipe[i] >= 0))
      i++;
    if (i >= npipes)
      {
        fprintf (stderr, "afterstep: Too many Accessories!\n");
        close(fd);
        return -1;
      }

    /* add pipe to afterstep's active pipe list */
    pipeName[i] = mystrdup("unknown module");
    module_pipe[i] = fd;
    pipeOn[i] = -1;
    PipeMask[i] = MAX_MASK;
    pipeQueue[i] = NULL;
  }

  return fd;
}

void
initModules (void)
{
  int i;

  npipes = GetFdWidth ();

  module_pipe = (int *) safemalloc (sizeof (int) * npipes);
  pipeOn = (int *) safemalloc (sizeof (int) * npipes);
  PipeMask = (unsigned long *) safemalloc (sizeof (unsigned long) * npipes);
  pipeName = (char **) safemalloc (sizeof (char *) * npipes);
  pipeQueue = (struct queue_buff_struct **)
    safemalloc (sizeof (struct queue_buff_struct *) * npipes);

  for (i = 0; i < npipes; i++)
    {
      module_pipe[i] = -1;
      pipeOn[i] = -1;
      PipeMask[i] = MAX_MASK;
      pipeQueue[i] = (struct queue_buff_struct *) NULL;
      pipeName[i] = NULL;
    }
}

void
ClosePipes (void)
{
  int i;
  for (i = 0; i < npipes; i++)
    {
      if (module_pipe[i] > 0)
	{
	  close (module_pipe[i]);
	}
      if (pipeName[i] != NULL)
	{
	  free (pipeName[i]);
	  pipeName[i] = 0;
	}
      while (pipeQueue[i] != NULL)
	{
	  DeleteQueueBuff (i);
	}
    }
}

void
executeModule (char *action, FILE * fd, char **win, int *context)
{
  int val;
  char command[256];
  char *cptr;
  char *aptr = NULL;
  char *end;
  char *arg0;
  extern char *ModulePath;

  if (action == NULL)
    return;

  sprintf (command, "%.255s", action);
  command[255] = '\0';

  for (cptr = command ; isspace (*cptr) ; cptr++);

  for (end = cptr ; !isspace (*end) && *end != '\0' ; end++);

  if (*end != '\0')
    {
      for (*end++ = '\0' ; isspace (*end) ; end++);
      if (*end != '\0')
        aptr = end;
    }

  arg0 = findIconFile (cptr, ModulePath, X_OK);
  if (arg0 == NULL)
    {
      fprintf (stderr, "AfterStep: No such module %s %s\n", ModulePath, cptr);
      return;
    }

  val = fork ();
  if (val == 0)
    {
      /* this is the child */
      extern Bool shall_override_config_file;
      int i = 0;
      char *args[10];
      char arg1[40];
      char arg2[40];

      args[i++] = arg0;

      args[i++] = "--window";
      sprintf (arg1, "%lx", (unsigned long) win);
      args[i++] = arg1;

      args[i++] = "--context";
      sprintf (arg2, "%lx", (unsigned long) context);
      args[i++] = arg2;

      if (shall_override_config_file)
	{
	  args[i++] = "-f";
	  args[i++] = global_base_file;
	}

      if (aptr != NULL)
	args[i++] = aptr;

      args[i++] = NULL;

      execvp (arg0, args);
      fprintf (stderr, "%s: execution of module '%s' failed: ", MyName, arg0);
      perror ("");
      exit (1);
    }

  free(arg0);
}

int
HandleModuleInput (Window w, int channel)
{
  char text[256];
  int size;
  int cont, n;
  char *newaction = NULL;

  /* Already read a (possibly NULL) window id from the pipe,
   * Now read an afterstep bultin command line */
  n = read (module_pipe[channel], &size, sizeof (int));
  if (n < sizeof (int))
    {
      KillModule (channel, 1);
      return -1;
    }
  if (size > 255)
    {
      fprintf (stderr, "Module command is too big (%d)\n", size);
      size = 255;
    }
  pipeOn[channel] = 1;

  n = read (module_pipe[channel], text, size);
  if (n == -1)
    perror (MyName);
  if (n < size)
    {
      KillModule (channel, 2);
      return -1;
    }
  text[n] = 0;
  n = read (module_pipe[channel], &cont, sizeof (int));
  if (n < sizeof (int))
    {
      KillModule (channel, 3);
      return -1;
    }
  if (!cont)
    KillModule (channel, 4);

  if (strlen (text))
    {
      char function[256], *ptr;
      MenuRoot *mr = 0;
      char *item = NULL;
      extern int func_val_1, func_val_2, func, Context;
      extern struct config func_config[];
      ASWindow *tmp_win;
      extern char *orig_tline;
      int n, unit_val_1, unit_val_2;
      char unit_1, unit_2;
      Bool update = False;

      orig_tline = text;
      Event.xany.type = ButtonRelease;
      Event.xany.window = w;

      func_val_1 = 0;
      func_val_2 = 0;
      unit_1 = 's';
      unit_2 = 's';
      n = sscanf (text, "%s %d %d", function, &func_val_1, &func_val_2);
      if (n != 3)
	n = sscanf (text, "%s %d%c %d%c", function, &func_val_1, &unit_1, &func_val_2, &unit_2);

      if (mystrcasecmp (function, "SET_MASK") == 0)
	{
	  PipeMask[channel] = func_val_1;
	  return 0;
	}
      else if (mystrcasecmp (function, "SET_NAME") == 0)
	{
	  char* ptr;

	  if (pipeName[channel] != NULL)
	    free (pipeName[channel]);

	  for (ptr = text + strlen(text) - 1 ; ptr >= text && isspace(*ptr) ; *ptr-- = '\0');
	  for (ptr = text ; isspace(*ptr) ; ptr++);
	  for ( ; *ptr != '\0' && !isspace(*ptr) ; ptr++);
	  for ( ; isspace(*ptr) ; ptr++);
	  pipeName[channel] = mystrdup(ptr);
	  return 0;
	}
      else if (mystrcasecmp (function, "UNLOCK") == 0)
	return 66;
      else if (mystrcasecmp (function, "SET_FLAGS") == 0)
	{
	  int xorflag;
	  if (XFindContext (dpy, w, ASContext, (caddr_t *) & tmp_win) == XCNOENT)
	    return 0;
	  xorflag = tmp_win->flags ^ func_val_1;
	  /*if (xorflag & STICKY)
	    Stick (tmp_win);*/
	  if (xorflag & WINDOWLISTSKIP)
	    {
	      tmp_win->flags ^= WINDOWLISTSKIP;
	      update_windowList();
              update = True;
	    }
          if (xorflag & AVOID_COVER)
            {
              tmp_win->flags ^= AVOID_COVER;
              update = True;
            }
          if (xorflag & TRANSIENT)
            {
              tmp_win->flags ^= TRANSIENT;
              update = True;
            }
          if (xorflag & CIRCULATESKIP)
          {
            tmp_win->flags ^= CIRCULATESKIP;
            update = True;
          }
          if (xorflag & NOFOCUS)
          {
            tmp_win->flags ^= NOFOCUS;
            if (tmp_win->flags & NOFOCUS)
              tmp_win->focus_var = 1;
            else
              tmp_win->focus_var = 0;
            update = True;
          }
          if (update)
            BroadcastConfig (M_CONFIGURE_WINDOW, tmp_win);
	  return 0;
	}

      func = F_NOP;
      match_string (func_config, function, "bad module function:", NULL);
      if ((func == F_POPUP) || (func == F_FUNCTION))
	{
	  ptr = stripcpy2 (text, 0);
	  if (ptr != NULL)
	    for (mr = Scr.first_menu; mr != NULL; mr = (*mr).next)
	      if (mystrcasecmp ((*mr).name, ptr) == 0)
		break;
	  if (!mr)
	    {
	      no_popup (ptr);
	      func = F_NOP;
	    }
	}
      else if (func == F_EXEC || func == F_RESTART || func == F_QUICKRESTART || 
	       func == F_CIRCULATE_UP || func == F_CIRCULATE_DOWN ||
	       func == F_WARP_F || func == F_WARP_B ||
	       func == F_MODULE || func == F_CHANGE_BACKGROUND)
	{
	  if (func == F_EXEC || func == F_RESTART || func == F_QUICKRESTART || 
	      func == F_MODULE || func == F_CHANGE_BACKGROUND)
	    {
	      item = stripcpy2 (text, 0);
	      newaction = stripcpy3 (text, True);
	      free (item);
	    }
	  else
	    {
	      item = stripcpy2 (text, 0);
	      newaction = stripcpy3 (text, False);
	      free (item);
	    }
	}
      if (XFindContext (dpy, w, ASContext, (caddr_t *) & tmp_win) == XCNOENT)
	{
	  tmp_win = NULL;
	  w = None;
	}
      if (tmp_win)
	{
	  Event.xbutton.button = 1;
	  Event.xbutton.x_root = tmp_win->frame_x;
	  Event.xbutton.y_root = tmp_win->frame_y;
	  Event.xbutton.x = 0;
	  Event.xbutton.y = 0;
	  Event.xbutton.subwindow = None;
	}
      else
	{
	  Event.xbutton.button = 1;
	  Event.xbutton.x_root = 0;
	  Event.xbutton.y_root = 0;
	  Event.xbutton.x = 0;
	  Event.xbutton.y = 0;
	  Event.xbutton.subwindow = None;
	}
      if (unit_1 == 'p')
	unit_val_1 = 100;
      else
	unit_val_1 = Scr.MyDisplayWidth;
      if (unit_2 == 'p')
	unit_val_2 = 100;
      else
	unit_val_2 = Scr.MyDisplayHeight;

      Context = GetContext (tmp_win, &Event, &w);
      ExecuteFunction (func, newaction, w, tmp_win, &Event, Context,
	       func_val_1, func_val_2, unit_val_1, unit_val_2, mr, channel);

      if (newaction != NULL)
	{
	  free (newaction);
	  newaction = NULL;
	}
    }
  return 0;
}


void
DeadPipe (int nonsense)
{
  signal (SIGPIPE, DeadPipe);
}


void
KillModule (int channel, int place)
{
  close (module_pipe[channel]);
  close (module_pipe[channel]);

  module_pipe[channel] = -1;
  module_pipe[channel] = -1;
  pipeOn[channel] = -1;
  while (pipeQueue[channel] != NULL)
    {
      DeleteQueueBuff (channel);
    }
  if (pipeName[channel] != NULL)
    {
      free (pipeName[channel]);
      pipeName[channel] = NULL;
    }
  return;
}

void
KillModuleByName (char *name)
{
  int i;

  if (name == NULL)
    return;

  for (i = 0; i < npipes; i++)
    {
      if (module_pipe[i] > 0)
	{
	  if ((pipeName[i] != NULL) && (strcmp (name, pipeName[i]) == 0))
	    KillModule (i, 20);
	}
    }
  return;
}

void
Broadcast (unsigned long event_type, unsigned long num_datum, ...)
{
  int i;
  va_list ap;
  unsigned long* body;

  body = safemalloc((3 + num_datum) * sizeof(unsigned long));

  body[0] = START_FLAG;
  body[1] = event_type;
  body[2] = 3 + num_datum;

  va_start (ap, num_datum);
  for (i = 0 ; i < num_datum ; i++)
    body[3 + i] = va_arg (ap, unsigned long);
  va_end (ap);

  for (i = 0; i < npipes; i++)
    PositiveWrite (i, body, body[2] * sizeof (unsigned long));

  free (body);
}

void
SendPacket (int module, unsigned long event_type, unsigned long num_datum, ...)
{
  int i;
  va_list ap;
  unsigned long* body;

  body = safemalloc((3 + num_datum) * sizeof(unsigned long));

  body[0] = START_FLAG;
  body[1] = event_type;
  body[2] = 3 + num_datum;

  va_start (ap, num_datum);
  for (i = 0 ; i < num_datum ; i++)
    body[3 + i] = va_arg (ap, unsigned long);
  va_end (ap);

  PositiveWrite (module, body, body[2] * sizeof (unsigned long));

  free (body);
}

void
SendConfig (int module, unsigned long event_type, ASWindow * t)
{
  MyStyle* style;
  unsigned long icon_w = None;
  
#ifdef NO_ICON_BACKGROUND
  icon_w = t->icon_w;
#endif /* NO_ICON_BACKGROUND */
  if (t == Scr.Hilite)
    style = t->style_focus;
  else if (t->flags & STICKY)
    style = t->style_sticky;
  else
    style = t->style_unfocus;

  SendPacket (module, event_type, 24, t->w, t->frame, (unsigned long) t, 
	      t->frame_x, t->frame_y, t->frame_width, t->frame_height, 
	      t->Desk, t->flags, t->title_height, t->boundary_width, 
	      t->hints.base_width, t->hints.base_height, t->hints.width_inc, 
	      t->hints.height_inc, t->hints.min_width, t->hints.min_height, 
	      t->hints.max_width, t->hints.max_height, icon_w, t->icon_pixmap_w, 
	      t->hints.win_gravity, style->colors.fore, style->colors.back);
}


void
BroadcastConfig (unsigned long event_type, ASWindow * t)
{
  MyStyle* style;
  unsigned long icon_w = None;
  
#ifdef NO_ICON_BACKGROUND
  icon_w = t->icon_w;
#endif /* NO_ICON_BACKGROUND */
  if (t == Scr.Hilite)
    style = t->style_focus;
  else if (t->flags & STICKY)
    style = t->style_sticky;
  else
    style = t->style_unfocus;

  Broadcast (event_type, 24, t->w, t->frame, (unsigned long) t, 
	     t->frame_x, t->frame_y, t->frame_width, t->frame_height, 
	     t->Desk, t->flags, t->title_height, t->boundary_width, 
	     t->hints.base_width, t->hints.base_height, t->hints.width_inc, 
	     t->hints.height_inc, t->hints.min_width, t->hints.min_height, 
	     t->hints.max_width, t->hints.max_height, icon_w, t->icon_pixmap_w, 
	     t->hints.win_gravity, style->colors.fore, style->colors.back);
}

void
BroadcastName (unsigned long event_type, unsigned long data1,
	       unsigned long data2, unsigned long data3, char *name)
{
  int l, i;
  unsigned long *body;


  if (name == NULL)
    return;
  l = (strlen (name) + 1) / (sizeof (unsigned long)) + 7;

  body = (unsigned long *) safemalloc (l * sizeof (unsigned long));

  body[0] = START_FLAG;
  body[1] = event_type;
  body[2] = l;

  body[3] = data1;
  body[4] = data2;
  body[5] = data3;
  strcpy ((char *) &body[6], name);


  for (i = 0; i < npipes; i++)
    PositiveWrite (i, (unsigned long *) body, l * sizeof (unsigned long));

  free (body);

}


void
SendName (int module, unsigned long event_type,
	  unsigned long data1, unsigned long data2,
	  unsigned long data3, char *name)
{
  int l;
  unsigned long *body;

  if (name == NULL)
    return;
  l = strlen (name) / (sizeof (unsigned long)) + 7;
  body = (unsigned long *) safemalloc (l * sizeof (unsigned long));

  body[0] = START_FLAG;
  body[1] = event_type;
  body[2] = l;

  body[3] = data1;
  body[4] = data2;
  body[5] = data3;
  strcpy ((char *) &body[6], name);

  PositiveWrite (module, (unsigned long *) body, l * sizeof (unsigned long));

  free (body);
}



#include <sys/errno.h>
AFTER_INLINE int
PositiveWrite (int module, unsigned long *ptr, int size)
{
  if ((pipeOn[module] < 0) || (!((PipeMask[module]) & ptr[1])))
    return -1;

  AddToQueue (module, ptr, size, 0);

  if (PipeMask[module] & M_LOCKONSEND)
    {
      Window targetWindow;
      int e;

      FlushQueue (module);

      while ((e = read (module_pipe[module], &targetWindow, sizeof (Window))) > 0)
	{
	  if (HandleModuleInput (targetWindow, module) == 66)
	    break;
	}

      if (e <= 0)
	KillModule (module, 10);
    }

  return size;
}

void
AddToQueue (int module, unsigned long *ptr, int size, int done)
{
  struct queue_buff_struct *c, *e;
  unsigned long *d;

  c = (struct queue_buff_struct *) safemalloc (sizeof (struct queue_buff_struct));
  c->next = NULL;
  c->size = size;
  c->done = done;
  d = (unsigned long *) safemalloc (size);
  c->data = d;
  memcpy (d, ptr, size);

  e = pipeQueue[module];
  if (e == NULL)
    {
      pipeQueue[module] = c;
      return;
    }
  while (e->next != NULL)
    e = e->next;
  e->next = c;
}

void
DeleteQueueBuff (int module)
{
  struct queue_buff_struct *a;

  if (pipeQueue[module] == NULL)
    return;
  a = pipeQueue[module];
  pipeQueue[module] = a->next;
  free (a->data);
  free (a);
  return;
}

void
FlushQueue (int module)
{
  char *dptr;
  struct queue_buff_struct *d;
  int a;
  extern int errno;

  if ((pipeOn[module] <= 0) || (pipeQueue[module] == NULL))
    return;

  while (pipeQueue[module] != NULL)
    {
      int fd = module_pipe[module];
      d = pipeQueue[module];
      dptr = (char *) d->data;
      fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
      for (a = 0 ; d->done < d->size ; d->done += a)
	{
	  a = write (fd, &dptr[d->done], d->size - d->done);
	  if (a < 0)
	    break;
	}
      fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) & ~O_NONBLOCK);
      /* the write returns EWOULDBLOCK or EAGAIN if the pipe is full.
       * (This is non-blocking I/O). SunOS returns EWOULDBLOCK, OSF/1
       * returns EAGAIN under these conditions. Hopefully other OSes
       * return one of these values too. Solaris 2 doesn't seem to have
       * a man page for write(2) (!) */
      if (a < 0 && (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR))
	return;
      else if (a < 0)
	{
	  KillModule (module, 123);
	  return;
	}
      DeleteQueueBuff (module);
    }
}
