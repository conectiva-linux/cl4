#!/usr/bin/perl -w

#
# Copyright (C) 1998 Ethan Fischer <allanon@crystaltokyo.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#

require 5.002;
use Socket;
use strict;

# AfterStep module packet format
# ------------------------------
#
# Packets are arrays of unsigned long, with a header of three elements.
# header[0] == START_FLAG (== 0xffffffff)
# header[1] == event type (as defined in include/module.h, and requested 
#                          with a SET_MASK module command)
# header[2] == number of elements in the body of the packet
#
# The content of the body of the packet is variable, depending on the 
# event type.

my $module_socket;

# connect to AfterStep via a UNIX-domain socket

sub module_connect {
  my $socket_name;
  local *SOCKET;

  $socket_name = "$ENV{'HOME'}/GNUstep/Library/AfterStep/non-configurable/connect.DISPLAY=$ENV{'DISPLAY'}";
  socket(SOCKET, PF_UNIX, SOCK_STREAM, 0)       || warn "socket: $!";
  connect(SOCKET, sockaddr_un($socket_name))    || warn "connect: $!";

  # set unbuffered I/O
  select(SOCKET);
  $| = 1;
  select(STDOUT);

  return *SOCKET;
}

# send an AfterStep module command
# $_[0] == socket to write command to
# $_[1] == message to send

sub module_send {
  my ($fh, $linelen, $sendstruct) = ($_[0], length($_[2]));
  $sendstruct = pack("LLa${linelen}L", $_[1], $linelen, $_[2], 1);
  print $fh "$sendstruct";
}

# read an AfterStep module packet
# $_[0] == socket to read packet from
# returns packet

sub module_read {
  my ($line, @packet, $packetlen);
  for ($line = "" ; length($line) < 12 ; ) {
    my $subline;
    if (read($_[0], $subline, 12 - length($line)) > 0) {
      $line = join("", $line, $subline);
    }
  }
  @packet = unpack("L3", $line);
  $packetlen = $packet[2] - 3;
  for ($line = "" ; length($line) < 4 * $packetlen ; ) {
    my $subline;
    if (read($_[0], $subline, 4 * $packetlen - length($line)) > 0) {
      $line = join("", $line, $subline);
    }
  }
  splice(@packet, 3, 0, unpack("L$packetlen", $line));
  return @packet;
}

# an example of how to write a function that watches the module socket 
# for AfterStep events
# $_[0] == module socket to communicate with
# this function never returns

sub watch_configure_notify {
  module_send($module_socket, 0, 'SET_MASK 64');
  while (1) {
    my $i;
    my @packet = module_read($module_socket);
    printf("%08x %08x %08x\n", $packet[0], $packet[1], $packet[2]);
    for ($i = 0 ; $i < $packet[2] ; $i++) {
      if (defined($packet[3+$i])) {
        printf("%08x ", $packet[3+$i]);
      }
    }
    printf("\n");
  }
}

# local variables
my $version = "1.1";
my $window_id;

sub version {
  print "ascommand.pl version $version\n";
}

sub usage {
  print "Usage:\n";
  print "$0 [-h] [-v] [-w id] [--] command\n";
  print "  -h --help        this help\n";
  print "  -v --version     print version information\n";
  print "  -w --window-id   window id to send to AfterStep (in hex)\n";
  print "  --               end parsing of command line options\n";
  print "  command          command to send to AfterStep\n";
}

# check dependencies
if (!defined($ENV{'DISPLAY'})) {
  die "$0: DISPLAY environment variable must be set (and valid)";
}

# get options
$window_id = 0;
while (defined $ARGV[0]) {
  my $arg = shift;
  if ($arg eq "-h" || $arg eq "--help") {
    version();
    usage();
    exit 0;
  } elsif ($arg eq "-v" || $arg eq "--version") {
    version();
    exit 0;
  } elsif (($arg eq "-w" || $arg eq "--window-id") && scalar(@ARGV) > 0) {
    $window_id = hex shift;
  } elsif ($arg eq "--") {
    last;
  } elsif ($arg =~ "-.*") {
    print "$0: unknown option '$arg'\n";
    exit 1;
  } else {
    unshift(@ARGV, $arg);
    last;
  }
}

# we need a message to send to AfterStep
if (!defined $ARGV[0]) {
  usage();
  exit 1;
}

# connect to AfterStep
$module_socket = module_connect();

# report our name
module_send($module_socket, 0, "SET_NAME $0");

# send the user-requested command
module_send($module_socket, $window_id, $ARGV[0]);

#watch_configure_notify($module_socket);

exit;
