/*
 * Copyright (C) 1999 Ethan Fischer <allanon@crystaltokyo.com>
 * Copyright (C) 1998 Pierre Clerissi <clerissi@pratique.fr>
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "../configure.h"
#include "../include/aftersteplib.h"

void
replaceEnvVar (char **path)
{
  char *ptr = *path, *var_start;
  for (ptr = *path ; (var_start = strchr (ptr, '$')) != NULL ; )
    {
      char *var_end, *name_start, *name_end, ch, *value;
      if (var_start[1] == '{')
        {
          name_start = var_start + 2;
          if ((name_end = strchr (name_start + 2, '}')) == NULL)
            break;
          var_end = name_end + 1;
        }
      else
        {
          name_start = var_start + 1;
          for (name_end = name_start ; isalnum(*name_end) || *name_end == '_' ; name_end++);
          var_end = name_end;
        }
      ch = *name_end;
      *name_end = '\0';
      if ((value = getenv (name_start)) != NULL)
        {
          char* tmp;
          *name_end = ch;
          tmp = safemalloc(strlen(*path) - (var_end - var_start) + strlen(value) + 1);
          sprintf(tmp, "%.*s%s%s", var_start - *path, *path, value, var_end);
          ptr = tmp + (ptr - *path) + strlen(value);
          free (*path);
          *path = tmp;
        }
      else
        {
          *name_end = ch;
          ptr = var_end;
        }
    }
}
