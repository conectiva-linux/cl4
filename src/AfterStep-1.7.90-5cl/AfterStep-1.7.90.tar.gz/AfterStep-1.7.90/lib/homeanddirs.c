/*
 * Handle directories & files
 *
 * Copyright (c) 1998 Ethan Ficher <allanon@crystaltokyo.com>
 * Copyright (c) 1998 Michael Vitecek <M.Vitecek@sh.cvut.cz>
 * Copyright (c) 1998 Chris Ridd <c.ridd@isode.com>
 * Copyright (c) 1997 Guylhem AZNAR <guylhem@oeil.qc.ca>
 *
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

#include "../configure.h"
#include "../include/aftersteplib.h"

time_t FileModifiedTime (const char *filename);

/*
 * get the date stamp on a file
 */
time_t
FileModifiedTime (const char *filename)
{
  struct stat st;
  time_t stamp = 0;
  if (stat (filename, &st) != -1)
    stamp = st.st_mtime;
  return stamp;
}

int
HomeCreate (const char *filename)
{
  int c;
  char *target, *source;
  char *path;
  FILE *targetfile, *sourcefile;

  target = (char *) safemalloc (strlen (AFTER_DIR) + strlen (filename) + 2);
  sprintf (target, "%s/%s", AFTER_DIR, filename);

  source = (char *) safemalloc (strlen (AFTER_SHAREDIR) + strlen (filename) + 2);
  sprintf (source, "%s/%s", AFTER_SHAREDIR, filename);

  path = PutHome (target);
  if ((targetfile = fopen (path, "w")) == NULL)
    {
      free (path);
      fprintf (stderr, "can't open %s !\n", target);
      return (-1);
    }
  free (path);
  path = PutHome (source);
  if ((sourcefile = fopen (path, "r")) == NULL)
    {
      free (path);
      fprintf (stderr, "can't open %s !\n", source);
      return (-2);
    }
/* free memory allocated for the filenames */
  free (path);
  free (target);
  free (source);

/* copy the source file to the target file */
  while ((c = getc (sourcefile)) != EOF)
    putc (c, targetfile);


  fclose (targetfile);
  fclose (sourcefile);

  return 0;
}

int
CheckFile (const char *file)
{
  struct stat st;

  if ((stat (file, &st) == -1) || (st.st_mode & S_IFMT) != S_IFREG)
    return (-1);
  else
    return (0);
}

int
CheckDir (const char *directory)
{
  struct stat st;

  if ((stat (directory, &st) == -1) || (st.st_mode & S_IFMT) != S_IFDIR)
    return (-1);
  else
    return (0);
}

char *
CheckOrShare (const char *directory, const char *homedir, const char *sharedir, const int share)
{
  char *result_dir;

  result_dir = (char *) safemalloc (PATH_MAX + 1);
  sprintf (result_dir, "%s/%s", homedir, directory);

  if (CheckDir (result_dir) != 0)
    {
/* the home directory doesn't exist or there's a problem with accessing it */
      if (!share)
	{
	  /* try it with the system directory */
	  sprintf (result_dir, "%s/%s", sharedir, directory);
	  if (CheckDir (result_dir) != 0)
	    {
	      /* problems with accessing the system directory */
	      free (result_dir);
	      return (NULL);
	    }
	  else
	    return (result_dir);
	}
      else
	{
	  /* ahh - it already was the system directory! */
	  free (result_dir);
	  return (NULL);

	}
    }
  return (result_dir);
}

char *
PutHome (const char *path_with_home)
{
  const char *home;		/* the HOME environment variable */
  char *str;

  /* home dir ? */
  if (!strncmp (path_with_home, "~/", 2))
    {
      /* get home */
      if ((home = getenv ("HOME")) == NULL)
	home = "./";
      /* alloc it */
      str = safemalloc (strlen (home) + 1 + (strlen (path_with_home) - 2) + 1);
      sprintf (str, "%s/%s", home, path_with_home + 2);
    }
  else
    str = mystrdup(path_with_home);

  return str;
}

int
CheckOrCreate (const char *what)
{
  char *checkdir;
  mode_t perms = 0755;

  checkdir = PutHome (what);

  if (CheckDir (checkdir) != 0)
    {
      fprintf (stderr, "Creating %s ... ", what);
      if (mkdir (checkdir, perms))
	{
	  free (checkdir);
	  fprintf (stderr, "ERROR !\n AfterStep depends on %s directory !\nPlease check permissions or contact your sysadmin !\n", what);
	  return (-1);
	}
      else
	fprintf (stderr, "done\n");
    }
  free (checkdir);
  return (0);
}

int
CheckOrCreateFile (const char *what)
{
  char *checkfile;
  FILE *touch;

  checkfile = PutHome (what);
  if (CheckFile (checkfile) != 0)
    {
      fprintf (stderr, "Creating %s ... ", what);
      if ((touch = fopen (checkfile, "w")) == NULL)
	{
	  free (checkfile);
	  fprintf (stderr, "ERROR !\n Cannot open file %s for writing!\n"
	    " Please check permissions or contact your sysadmin !\n", what);
	  return (-1);
	}
      else
	{
	  fclose (touch);
	  fprintf (stderr, "done\n");
	}

    }
  free (checkfile);
  return (0);
}
