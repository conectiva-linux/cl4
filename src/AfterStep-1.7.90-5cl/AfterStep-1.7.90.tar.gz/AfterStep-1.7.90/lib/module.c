/*
 * Copyright (C) 1999 Ethan Fischer <allanon@crystaltokyo.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>

#include <X11/Xlib.h>
#include <X11/Xatom.h>

#include "../configure.h"
#include "../include/aftersteplib.h"
#include "../include/module.h"

char* module_get_socket_property(Window w)
{
  char* data;
  int actual_format;
  Atom name, actual_type;
  unsigned long junk;

  name = XInternAtom (dpy, "_AS_MODULE_SOCKET", False);

  if (XGetWindowProperty(dpy, w, name, 0, ~0, False, AnyPropertyType, &actual_type, &actual_format, &junk, &junk, (unsigned char**) &data) != Success)
    return NULL;

  if (actual_type != XA_STRING || actual_format != 8)
    {
      XFree (data);
      return NULL;
    }

  return data;
}

int module_connect(const char* socket_name)
{
  int fd;

  /* create an unnamed socket */
  if ((fd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
    fprintf(stderr, "%s: unable to create UNIX socket: ", MyName);
    perror("");
  }

  /* connect to the named socket */
  if (fd >= 0) {
    struct sockaddr_un name;

    name.sun_family = AF_UNIX;
    strcpy(name.sun_path, socket_name);

    if (connect(fd, (struct sockaddr *)&name, sizeof(struct sockaddr_un))) {
      fprintf(stderr, "%s: unable to connect to socket '%s': ", MyName, name.sun_path);
      perror("");
      close(fd);
      fd = -1;
    }
  }

  return fd;
}
