#ifndef AFTERSTEP_LIB_HEADER_FILE_INCLUDED
#define AFTERSTEP_LIB_HEADER_FILE_INCLUDED

#include <X11/Xlib.h>
#ifdef I18N
#include <X11/Xlocale.h>
#endif
#include <stdio.h>

typedef struct gradient_t
  {
    int from[3];
    int to[3];
  }
gradient_t;

#include "general.h" /* because misc.h is already taken */
#include "font.h"
#include "timer.h"
#include "balloon.h"
#include "mystyle.h"
#include "mystyle_property.h"

/* from getcolor.c */
unsigned long GetColor(char *);
unsigned long GetShadow (unsigned long);
unsigned long GetHilite (unsigned long);

int mystrcasecmp (const char *, const char *);
int mystrncasecmp (const char *, const char *, size_t);

/* from mystrdup.c */
char* mystrdup (const char* str);
char* mystrndup (const char* str, size_t n);

char *CatString3 (const char *, const char *, const char *);

/* from gethostname.c */
int mygethostname (char *, size_t);

/* from sendinfo.c */
void SendInfo (int *, char *, unsigned long);

/* from safemalloc.c */
void *safemalloc (size_t);

/* from findiconfile.c */
char *findIconFile (const char *, const char *, int);

/* from wild.c */
int matchWildcards (const char *, const char *);

void replaceEnvVar (char **);
int ReadASPacket (int, unsigned long *, unsigned long **);
void CopyString (char **, char *);
void sleep_a_little (int);
int GetFdWidth (void);
int CheckFile (const char *);
int CheckDir (const char *);
char *CheckOrShare (const char *, const char *, const char *, const int);
char *PutHome (const char *);
int HomeCreate (const char *);
int CheckOrCreate (const char *);
int CheckOrCreateFile (const char *);

#include "audit.h"

#endif /* #ifndef AFTERSTEP_LIB_HEADER_FILE_INCLUDED */
