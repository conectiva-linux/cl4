#ifndef PARSER_HEADER_FILE_INCLUDED
#define PARSER_HEADER_FILE_INCLUDED

/*#define DEBUG_PARSER*/
/* put it in here for now - later should probably be moved
   into configure stuff */
#define WITH_CONFIG_WRITER

typedef struct term_definition {
    /* the following needs to be defined by module */
#define TF_DONT_REMOVE_COMMENTS (1<<0) /* indicates that comments sould not be */ 
                                       /* removed from the end of this term */
#define TF_SPECIAL_PROCESSING 	(1<<1) /* supplied special processing procedure */
                                       /* needs to be called for this one */
#define TF_NO_MYNAME_PREPENDING	(1<<2) /* has effect only when writing this back to */
                                       /* config file */
#define TF_DONT_SPLIT           (1<<3) /* if it is desired to preserv data intact */
                                       /* vs. splitting it into space separated words */
#define TF_INDEXED              (1<<4) /* if it we have array of indexed items of the same */
				       /* type and ID */
    unsigned long flags ; 	/* combination of any of above values */
    char* keyword ;         
    unsigned int keyword_len ;
#define TT_ANY		0
#define TT_FLAG		1
#define TT_INTEGER  	2
#define TT_COLOR    	3
#define TT_FONT    	4
#define TT_FILENAME 	5
#define TT_PATHNAME 	6
#define TT_GEOMETRY 	7
#define TT_TEXT     	8
#define TT_SPECIAL     	9
#define TT_CUSTOM   	64      /* modules can define custom types starting */
                                /* with this one */
    int type ;                  /* term's type */

/* that is done for some global config id's */
 /* all module's custom ID's should start from here */
#define ID_ANY			0
#define TT_CUSTOM_ID_START    	1024
    int id ;                    /* term's id */
    
    /* the following will be initialized automatically */
    struct term_definition* brother ; /* next term with the same hash key in hash table */
} TermDef ;

typedef struct syntax_definition {
    char terminator ;          /* character, terminating this term */
    char file_terminator ;     /* character, terminating configuration */
    TermDef* terms ;        /* array of Term definitions */ 
} SyntaxDef ;

/* that is not supposed to be used outside of this code */
/* making it available just in case */ 
#define DISABLED_KEYWORD        "#~~DISABLED~~#"
#define DISABLED_KEYWORD_SIZE	14

typedef struct freestorage_elem {
    TermDef* term ;          
#define FS_DISABLED		(1<<1)    
    unsigned long flags ; 
    
    char**   argv ;           /* space separated words from the source data will
                                 be placed here unless DONT_SPLIT_WORDS defined 
				 for the term*/
    int      argc ;           /* number of words */
    struct freestorage_elem* next ;
} FreeStorageElem ;

#define TERM_HASH_SIZE 		61
#define MAX_CONFIG_LINE 	MAXLINELENGTH

typedef unsigned short int HashValue ;

struct config_definition ;
typedef int (*SpecialFunc)(struct config_definition* conf_def, FreeStorageElem** storage) ;

typedef struct config_definition {
    char *myname ; /* prog name */
    SyntaxDef* syntax ;
    TermDef**   term_hash ;
    HashValue   term_hash_size ;

    SpecialFunc special;
    int   fd ;
    FILE* fp ; /* this one for compatibility with some old code - most
                * notably balloons and MyStyle 
		* when they'll be converted on new style - that should go away
		*/
    int bNeedToCloseFile ;
    /* allocated to store lines read from the file */
    char* buffer ;
    long buffer_size ;
    /* this is the current parsing information */
    char* tline, *tline_start ;     
    TermDef* current_term ;
    char* current_data;
    long current_data_size;
    int current_data_len ;
    
    char* cursor ;

} ConfigDef ;

typedef enum
{
    CDT_Filename,
    CDT_FilePtr,
    CDT_FileDesc,    
    CDT_Data
}ConfigDataType ;

ConfigDef* InitConfigReader( char *myname, SyntaxDef* syntax, ConfigDataType type, void* source, HashValue hash_size, SpecialFunc special );
int ParseConfig( ConfigDef* config, FreeStorageElem** storage );

ConfigDef* InitConfigWriter( char *myname, SyntaxDef* syntax, ConfigDataType type, void* source, HashValue hash_size );
#define WF_DISCARD_COMMENTS 	(1<<1)
#define WF_DISCARD_UNKNOWN	(1<<2)
#define WF_DISCARD_EVERYTHING   0xFFFFFFFF
long WriteConfig( ConfigDef* config, FreeStorageElem** storage, ConfigDataType target_type, void** target, unsigned long flags);
/* Note: WriteConfig discards FreeStorage if everything is fine, 
 *       in which case *storage will be set to NULL 
 */

void DestroyConfig(ConfigDef* config);

/* debugging stuff */
#ifdef DEBUG_PARSER
void PrintConfigReader(ConfigDef* config);
void PrintFreeStorage(FreeStorageElem* storage);
#else
#define PrintConfigReader(a)
#define PrintFreeStorage(b)
#endif

#define COMMENTS_CHAR '#'
#define MYNAME_CHAR   '*'

/* utility functions for writing config */
FreeStorageElem* DupFreeStorageElem( FreeStorageElem* source );
FreeStorageElem* AddFreeStorageElem( SyntaxDef* syntax, FreeStorageElem** storage, TermDef* pterm, int id );
void CopyFreeStorage( FreeStorageElem** to, FreeStorageElem* from );
void DestroyFreeStorage(FreeStorageElem** storage );
void StorageCleanUp( FreeStorageElem** storage, FreeStorageElem** garbadge_bin, unsigned long mask );

/* freestorage post processing stuff */
typedef struct {
    int flags, x, y;
    unsigned width, height ;
}MyGeometry ;

typedef struct {
    void* memory ; /* this one holds pointer to entire block of allocated memory */
    int ok_to_free ; /* must be set in order to free memory allocated before and 
			stored in [memory] member */
    int type ;
    int index ;    /* valid only for those that has TF_INDEXED set */
    union{
	MyGeometry geometry;
	long       integer ;
	char*      string ; 
    } data ;
}ConfigItem;
int ReadConfigItem( ConfigItem* item, FreeStorageElem *stored );

/* utility functions */
void FlushConfigBuffer(ConfigDef* config);
char** CreateStringArray(size_t elem_num);
size_t GetStringArraySize( int argc, char** argv );
char** DupStringArray(int argc, char** argv );
void InitMyGeometry(MyGeometry *geometry);

#define Flag2FreeStorage(syntax,storage,id) AddFreeStorageElem(syntax,storage,NULL,id)
void Integer2FreeStorage( SyntaxDef* syntax, FreeStorageElem** storage, int value, int id );
void String2FreeStorage( SyntaxDef* syntax, FreeStorageElem** storage, char* string, int id );
void Geometry2FreeStorage( SyntaxDef* syntax, FreeStorageElem** storage, MyGeometry* geometry, int id );
void StringArray2FreeStorage( SyntaxDef* syntax, FreeStorageElem** storage, char** strings, int index1, int index2, int id  );

#endif


