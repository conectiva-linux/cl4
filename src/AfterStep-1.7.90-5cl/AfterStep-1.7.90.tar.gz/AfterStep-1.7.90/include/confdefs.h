#ifndef CONF_DEFS_H_FILE_INCLUDED
#define CONF_DEFS_H_FILE_INCLUDED

/***************************************************************************/
/*                        Base file pasring definitions                    */
/***************************************************************************/
#define TT_BASE_ID_START        0
#define BASE_MODULE_PATH_ID     TT_BASE_ID_START
#define BASE_ICON_PATH_ID     	TT_BASE_ID_START+1
#define BASE_PIXMAP_PATH_ID	TT_BASE_ID_START+2
#define BASE_MYNAME_PATH_ID	TT_BASE_ID_START+3
#define BASE_DESKTOP_SIZE_ID	TT_BASE_ID_START+4
#define BASE_DESKTOP_SCALE_ID	TT_BASE_ID_START+5

typedef struct {
    char* module_path ;
    char* icon_path ;    
    char* pixmap_path ;    
    char* myname_path ;    
    MyGeometry desktop_size ;
    int desktop_scale ;
    
    FreeStorageElem* more_stuff;
}BaseConfig;

BaseConfig * ParseBaseOptions( const char* filename, char* myname);
/* 
 * all data members that has been used from BaseConfig structure, returned
 * by this call must be set to NULL, or memory allocated for them will be
 * deallocated by the following DestroyBaseConfig function !
 */

void DestroyBaseConfig(BaseConfig* config);


/***************************************************************************/
extern char* pixmapPath ;
/****************************************************************************/
/*                             Pager                                        */
/****************************************************************************/
/* flags used in configuration */
#define USE_LABEL   		(1<<0)
#define START_ICONIC		(1<<1)
#define REDRAW_BG		(1<<2)
#define STICKY_ICONS		(1<<3)
#define LABEL_BELOW_DESK 	(1<<4)
#define HIDE_INACTIVE_LABEL	(1<<5)
#define PAGE_SEPARATOR		(1<<6)
#define DIFFERENT_GRID_COLOR	(1<<7)
#define DIFFERENT_BORDER_COLOR	(1<<8)
#define SHOW_SELECTION          (1<<9)
#define FAST_STARTUP		(1<<10)
#define SET_ROOT_ON_STARTUP	(1<<11)
#define PAGER_FLAGS_DEFAULT	(USE_LABEL|REDRAW_BG|PAGE_SEPARATOR|SHOW_SELECTION)

/* ID's used in our config */
#define PAGER_GEOMETRY_ID 	(TT_CUSTOM_ID_START)
#define PAGER_ICON_GEOMETRY_ID  (TT_CUSTOM_ID_START+1) 
#define PAGER_ALIGN_ID		(TT_CUSTOM_ID_START+2)
#define PAGER_DRAW_BG_ID	(TT_CUSTOM_ID_START+3)
#define PAGER_FAST_STARTUP_ID	(TT_CUSTOM_ID_START+4)
#define PAGER_SET_ROOT_ID	(TT_CUSTOM_ID_START+5)
#define PAGER_SMALL_FONT_ID	(TT_CUSTOM_ID_START+6)
#define PAGER_START_ICONIC_ID	(TT_CUSTOM_ID_START+7)
#define PAGER_ROWS_ID		(TT_CUSTOM_ID_START+8)
#define PAGER_COLUMNS_ID	(TT_CUSTOM_ID_START+9)
#define PAGER_STICKY_ICONS_ID	(TT_CUSTOM_ID_START+10)
#define PAGER_LABEL_ID 		(TT_CUSTOM_ID_START+11)
#define PAGER_STYLE_ID		(TT_CUSTOM_ID_START+12)
#define PAGER_DESKTOP_IMAGE_ID	(TT_CUSTOM_ID_START+13)
#define PAGER_LOADER_ARGS_ID	(TT_CUSTOM_ID_START+14)

#define PAGER_DECORATION_ID	(TT_CUSTOM_ID_START+20)
#define PAGER_MYSTYLE_ID	(TT_CUSTOM_ID_START+21)
#define PAGER_BALLOONS_ID	(TT_CUSTOM_ID_START+22)

#define PAGER_DECOR_NOLABEL_ID 		(TT_CUSTOM_ID_START+30)
#define PAGER_DECOR_NOSEPARATOR_ID 	(TT_CUSTOM_ID_START+31)
#define PAGER_DECOR_NOSELECTION_ID 	(TT_CUSTOM_ID_START+32)
#define PAGER_DECOR_SEL_COLOR_ID 	(TT_CUSTOM_ID_START+33)
#define PAGER_DECOR_GRID_COLOR_ID 	(TT_CUSTOM_ID_START+34)
#define PAGER_DECOR_BORDER_WIDTH_ID 	(TT_CUSTOM_ID_START+35)
#define PAGER_DECOR_BORDER_COLOR_ID	(TT_CUSTOM_ID_START+36)
#define PAGER_DECOR_LABEL_BELOW_ID	(TT_CUSTOM_ID_START+37)
#define PAGER_DECOR_HIDE_INACTIVE_ID 	(TT_CUSTOM_ID_START+38)

/* config data structure */

typedef struct {
    MyGeometry geometry, icon_geometry ;
    char** labels ;
    char** styles ; 
    char** desktop_images ;
    char** loader_args ;
    int align ;
    unsigned short flags ;
    char* small_font_name;
    int rows, columns ;
    char* selection_color ;
    char* grid_color ;
    int border_width ;
    char* border_color ;
    FreeStorageElem* more_stuff;
}PagerConfig;

PagerConfig* CreatePagerConfig( int ndesks );
PagerConfig * ParsePagerOptions( const char* filename, char* myname, int desk1, int desk2);
int WritePagerOptions(  const char* filename, char* myname, int desk1, int desk2, PagerConfig *config, unsigned long flags );
void DestroyPagerConfig(PagerConfig* config);

/**************************************************************************/



#endif  /* CONF_DEFS_H_FILE_INCLUDED */

