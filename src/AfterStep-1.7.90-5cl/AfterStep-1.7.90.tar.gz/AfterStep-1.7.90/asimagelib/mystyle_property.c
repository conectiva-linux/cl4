/*
 * Copyright (c) 1999 Ethan Fischer <allanon@crystaltokyo.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include "../configure.h"

#include <stdio.h>
#include <malloc.h>
#include <X11/X.h>
#include <X11/Xatom.h>

#include "../include/aftersteplib.h"
#include "../include/mystyle.h"
#include "../include/mystyle_property.h"

#ifdef I18N
#define MAX_FONTSET_NAME_LENGTH  256
#endif

/*
 * NOTE: everything in the style_prop_t structure must be of type 
 * "unsigned long"!!  some X types that are defined to be unsigned long: 
 * Atom, Font, Pixmap, XID
 */
typedef struct style_prop_t
{
	unsigned long set_flags;

	unsigned long flags;
	Atom name;
	unsigned long text_style;
#ifndef I18N
	Font font_id;
#else
	char fontset_name[MAX_FONTSET_NAME_LENGTH];
#endif
	unsigned long color_fore;
	unsigned long color_back;
	unsigned long relief_fore;
	unsigned long relief_back;
	unsigned long texture_type;
	unsigned long max_colors;
	Pixmap back_icon_pixmap;
	Pixmap back_icon_mask;
	unsigned long gradient_from[3];
	unsigned long gradient_to[3];
	unsigned long tint[3];
} style_prop_t;

void mystyle_set_property(Display* dpy, Window w, Atom name, Atom type)
{
	MyStyle* style;
	unsigned long* data;
	style_prop_t* prop;
	int i, nelements;

	for (nelements = 0, style = mystyle_first ; style != NULL ; style = style->next, nelements++);

	data = (unsigned long*)safemalloc(2 * sizeof(unsigned long) + sizeof(style_prop_t) * nelements);

	/* set the property version to 1.0 */
	data[0] = (1 << 8) + 0;

	/* the number of styles in the property */
	data[1] = nelements;

	/* fill in the properties */
	prop = (style_prop_t*)(data + 2);
	for (i = 0, style = mystyle_first ; style != NULL ; style = style->next, i++)
	{
		prop[i].set_flags = style->set_flags;
		prop[i].name = XInternAtom(dpy, style->name, False);
		prop[i].text_style = style->text_style;
#ifndef I18N
		prop[i].font_id = style->font.font->fid;
#else
		strcpy (prop[i].fontset_name, style->font.name);
#endif
		prop[i].color_fore = style->colors.fore;
		prop[i].color_back = style->colors.back;
		prop[i].relief_fore = style->relief.fore;
		prop[i].relief_back = style->relief.back;
		prop[i].texture_type = style->texture_type;
#ifndef NO_TEXTURE
		prop[i].max_colors = style->max_colors;
		prop[i].back_icon_pixmap = style->back_icon.pix;
		prop[i].back_icon_mask = style->back_icon.mask;
		prop[i].gradient_from[0] = style->gradient.from[0];
		prop[i].gradient_from[1] = style->gradient.from[1];
		prop[i].gradient_from[2] = style->gradient.from[2];
		prop[i].gradient_to[0] = style->gradient.to[0];
		prop[i].gradient_to[1] = style->gradient.to[1];
		prop[i].gradient_to[2] = style->gradient.to[2];
		prop[i].tint[0] = style->tint.red;
		prop[i].tint[1] = style->tint.green;
		prop[i].tint[2] = style->tint.blue;
#else /* NO_TEXTURE */
		prop[i].max_colors = ~0;
		prop[i].back_icon_pixmap = None;
		prop[i].back_icon_mask = None;
		prop[i].gradient_from[0] = 0;
		prop[i].gradient_from[1] = 0;
		prop[i].gradient_from[2] = 0;
		prop[i].gradient_to[0] = 0;
		prop[i].gradient_to[1] = 0;
		prop[i].gradient_to[2] = 0;
		prop[i].tint[0] = 0;
		prop[i].tint[1] = 0;
		prop[i].tint[2] = 0;
#endif /* NO_TEXTURE */
	}

	XChangeProperty(dpy, w, name, type, 32, PropModeReplace, (unsigned char*)data, 2 + nelements * sizeof(style_prop_t) / sizeof(unsigned long));

	free(data);
}

void mystyle_get_property(Display* dpy, Window w, Atom name, Atom type)
{
	unsigned long* data;
	style_prop_t* prop;
	int i, n, actual_format;
	Atom actual_type;
	unsigned long version, junk;

	/* try to get the property version and number of styles */
	if (XGetWindowProperty(dpy, w, name, 0, 2, False, AnyPropertyType, &actual_type, &actual_format, &junk, &junk, (unsigned char**) &data) != Success)
		return;

	if (actual_type != type)
		{
		XFree(data);
		return;
		}

	version = data[0];
	n = data[1];
	XFree(data);

	/* do we know how to handle this version? */
	if (version != (1 << 8) + 0)
	{
		fprintf(stderr, "%s: style property has unknown version %d.%d\n", MyName, (int)version >> 8, (int)version & 0xff);
		return;
	}

	/* try to get the actual style information */
	if (XGetWindowProperty(dpy, w, name, 2, n * sizeof(style_prop_t) / sizeof(unsigned long), False, AnyPropertyType, &actual_type, &actual_format, &junk, &junk, (unsigned char**) &prop) != Success)
		return;

	for (i = 0 ; i < n ; i++)
	{
		MyStyle* style;
		char* name;

		name = XGetAtomName(dpy, prop[i].name);
		if ((style = mystyle_find(name)) == NULL)
			style = mystyle_new_with_name(name);
		XFree(name);

		/* free up any resources that are already in use */
		if (style->user_flags & F_FONT)
			unload_font(&style->font);
#ifndef NO_TEXTURE
		if (style->user_flags & F_BACKPIXMAP)
		{
			if (style->back_icon.pix != None)
				XFreePixmap (dpy, style->back_icon.pix);
			if (style->back_icon.mask != None)
				XFreePixmap (dpy, style->back_icon.mask);
		}
#endif /* NO_TEXTURE */

		style->user_flags = 0;
		style->inherit_flags = prop[i].set_flags;
		style->set_flags = prop[i].set_flags;
		style->text_style = prop[i].text_style;
		if (prop[i].set_flags & F_FONT)
		{
#ifndef I18N
			XFontStruct* font = XQueryFont(dpy, prop[i].font_id);
			style->font.name = NULL;
			style->font.font = font;
			if (font != NULL)
			{
				style->font.width = font->max_bounds.rbearing + font->min_bounds.lbearing;
				style->font.height = font->ascent + font->descent;
				style->font.y = font->ascent;
			}
#else
			load_font (prop[i].fontset_name, &style->font);
#endif
		}
		style->colors.fore = prop[i].color_fore;
		style->colors.back = prop[i].color_back;
		style->relief.fore = prop[i].relief_fore;
		style->relief.back = prop[i].relief_back;
		style->texture_type = prop[i].texture_type;
#ifndef NO_TEXTURE
		style->max_colors = prop[i].max_colors;
		style->back_icon.pix = prop[i].back_icon_pixmap;
		style->back_icon.mask = prop[i].back_icon_mask;
		style->gradient.from[0] = prop[i].gradient_from[0];
		style->gradient.from[1] = prop[i].gradient_from[1];
		style->gradient.from[2] = prop[i].gradient_from[2];
		style->gradient.to[0] = prop[i].gradient_to[0];
		style->gradient.to[1] = prop[i].gradient_to[1];
		style->gradient.to[2] = prop[i].gradient_to[2];
		style->tint.red = prop[i].tint[0];
		style->tint.green = prop[i].tint[1];
		style->tint.blue = prop[i].tint[2];
		/* if there's a backpixmap, make sure it's valid and get its geometry */
		if (style->back_icon.pix != None)
		{
			Window junk_w;
			int junk;
			if (!XGetGeometry (dpy, style->back_icon.pix, &junk_w, &junk, &junk, &style->back_icon.width, &style->back_icon.height, &junk, &junk))
			{
				style->texture_type = 0;
				style->back_icon.pix = None;
				style->back_icon.mask = None;
			}
		}
#endif /* NO_TEXTURE */
	}

	/* force update of global gcs */
	mystyle_fix_styles();
	mystyle_set_global_gcs (NULL);

	XFree(prop);
}

