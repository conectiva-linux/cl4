#ifndef SUN_PROBE_H
#define SUN_PROBE_H

#define SUN_PS2_MOUSE	1
#define SUN_SUNMOUSE	2
int find_first_mouse(int *mouse, char **port);
                                                        
#endif
