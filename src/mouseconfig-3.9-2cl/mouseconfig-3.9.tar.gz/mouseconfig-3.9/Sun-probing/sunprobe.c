/* $Id: sunprobe.c,v 1.3 1999/03/10 08:32:45 msw Exp $
 * sun.c: Probe for Sun Mouse using OpenPROM.
 *
 * Copyright (C) 1998 Jakub Jelinek (jj@ultra.linux.cz)
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the
 *  Free Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software Foundation,
 *  Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <sys/sysmacros.h>

#include "sunprobe.h"

#ifdef __sparc__

#include <asm/openpromio.h>

static char *promdev = "/dev/openprom";
static int promfd;
static int prom_root_node, prom_current_node;
#define MAX_PROP	128
#define MAX_VAL		(4096-128-4)
static char buf[4096];
#define DECL_OP(size) struct openpromio *op = (struct openpromio *)buf; op->oprom_size = (size)

static int prom_getsibling(int node)
{
	DECL_OP(sizeof(int));
	
	if (node == -1) return 0;
	*(int *)op->oprom_array = node;
	if (ioctl (promfd, OPROMNEXT, op) < 0)
		return 0;
	prom_current_node = *(int *)op->oprom_array;
	return *(int *)op->oprom_array;
}

static int prom_getchild(int node)
{
	DECL_OP(sizeof(int));
	
	if (!node || node == -1) return 0;
	*(int *)op->oprom_array = node;
	if (ioctl (promfd, OPROMCHILD, op) < 0)
		return 0;
	prom_current_node = *(int *)op->oprom_array;
	return *(int *)op->oprom_array;
}

static char *prom_getproperty(char *prop, int *lenp)
{
	DECL_OP(MAX_VAL);
	
	strcpy (op->oprom_array, prop);
	if (ioctl (promfd, OPROMGETPROP, op) < 0)
		return 0;
	if (lenp) *lenp = op->oprom_size;
	return op->oprom_array;
}

int find_first_mouse(int *mouse, char **port)
{
	int node;
	int len;
	int fd = 0;
	char *prop;
	char twelve = 12;
	struct stat s;
	FILE *f;
	char buf[128];

	/* Test for serial console */
	if (fstat (0, &s) < 0)
		return -1;
	/* If this is a pseudo terminal, we try /dev/console, otherwise we try our stdin */
	if (major (s.st_rdev) == 3)
		fd = open("/dev/console", O_RDONLY);
	if (ioctl (fd, TIOCLINUX, &twelve) < 0) {
		if (fd) close(fd);
		return -1; /* We are probably on a serial console, so it is highly probable there is no mouse */
	}
	if (fd) close(fd);
	promfd = open(promdev, O_RDONLY);
	if (promfd == -1)
		return -1;
	prom_root_node = prom_getsibling(0);
	if (!prom_root_node) {
		close(promfd);
		return -1;
	}
		
	node = prom_getchild(prom_root_node);
	while (node) {
		prop = prom_getproperty("name", &len);
		if (!prop || len < 0)
			break;
		if (!strcmp(prop, "aliases")) {
			/* As many machines don't have mouse property, we check keyboard... */
			prop = prom_getproperty("keyboard", &len);
			if (prop && len > 0) {
				if (strstr(prop, "kb_ps2")) {
					*mouse = SUN_PS2_MOUSE;
					*port = strdup("psaux");
				} else {
					*mouse = SUN_SUNMOUSE;
					*port = strdup("sunmouse");
				}
				close(promfd);
				return 1;
			}
		}
		node = prom_getsibling(node);
	}
	close(promfd);

	if (f = fopen("/proc/cpuinfo", "r")) {
	    while (fgets(buf, sizeof(buf) - 1, f) != NULL) {
		if (strstr(buf, "sun4c") || strstr(buf, "sun4m")) {
		    *mouse = SUN_SUNMOUSE;
		    *port = strdup("sunmouse");
		    fclose(f);
		    return 1;
		}
	    }
	}
	fclose(f);	

	return -1;
}

#else

int find_first_mouse(int *mouse, char **port)
{
	return -1;
}

#endif
