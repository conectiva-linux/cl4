/* tiny stub program to call the pnp_probe_parport() function 
 *
 * Michael Fulbright (msf@redhat.com)
 *
 * Copyright 1997 Red Hat Software
 *
 * This software may be freely redistributed under the terms of the GNU
 * public license.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <stdio.h>

#include "pnp_probe_parport.h"


int main(int argc, char **argv) {

    struct devprobe *t=NULL;

    if (argc < 2) {
	fprintf(stderr,"Usage:   pnp_probe_port <port dev>\n");
	fprintf(stderr,"   where  <port dev> is /dev/lp[012]\n\n");
	exit(1);
    }

    if (pnp_probe_parport( &t, argv[1] )) {
	fprintf(stderr,"ERROR - could not probe port %s\n",argv[1]);
	exit(1);
    }

    /* it worked! */
    devprobe_print(t, stdout);
    devprobe_destroy(t);

    exit(0);
}

