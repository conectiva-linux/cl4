/* simple program to probe serial port requested 
 *
 * Michael Fulbright (msf@redhat.com)
 *
 * Copyright 1997 Red Hat Software
 *
 * This software may be freely redistributed under the terms of the GNU
 * public license.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
*/

#include <stdio.h>
#include <string.h>

#include "pnp_probe_com.h"


int main (int argc, char **argv) {
    char *port;
    struct devprobe *t=NULL;

    if (argc <2)
	port = strdup("/dev/modem");
    else
	port = strdup(argv[1]);

    if (pnp_probe_com( &t, port)) {
	fprintf(stderr,"ERROR - could not probe port %s\n",port);
	exit(1);
    }
    else
	devprobe_print(t,stdout);
    
    exit(0);
}
