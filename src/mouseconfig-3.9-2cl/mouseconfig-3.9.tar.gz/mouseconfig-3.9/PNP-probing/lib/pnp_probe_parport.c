/* super simple code to detect printer type                    */
/* based heavily upon the parport driver for the linux kernel  */
/* see http://www.cyberelk.demon.co.uk/parport.html            */
/*
 * Michael Fulbright (msf@redhat.com)
 *
 * Copyright 1997 Red Hat Software
 *
 * This software may be freely redistributed under the terms of the GNU
 * public license.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
  

/* define to use nanosleep() instead of usleep() */
#define USE_NSLEEP

/* NOTE ON DELAYS IN THIS CODE */
/* The operations we are doing in this code are best done at the kernel */
/* level, since delays of tens of milleseconds are involvled. However,  */
/* the devices I have tested the code with seem to be forgiving about   */
/* the actual delays. I have some hard coded values for now (search for */
/* 'nanosleep' to see them. I played with values a little, but saw no   */
/* real speedup in the transfer of the data from the printer.           */


#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>
#include <linux/lp.h>
#include <sys/io.h>

#include "utils.h"
#include "devprobe.h"

/* simplified parport structure than used by kernel driver */
struct parport {
    unsigned int base;
    unsigned int size;
    char *name;
    int  irq;
    unsigned int modes;
};

/* some helpful functions to communicate with a port */
static inline void w_ctrl(struct parport *port, int val) 
{
	outb(val, port->base+2);
}

static inline int r_ctrl(struct parport *port)
{
	return inb(port->base+2);
}

static inline void w_data(struct parport *port, int val)
{
	outb(val, port->base);
}

static inline int r_data(struct parport *port)
{
	return inb(port->base);
}

static inline int r_status(struct parport *port)
{
	return inb(port->base+1);
}




/* The following read funktions are an implementation of a status readback
 * and device id request confirming to IEEE1284-1994.
 */

/* Wait for Status line(s) to change in 35 ms - see IEEE1284-1994 page 24 to
 * 25 for this. After this time we can create a timeout because the
 * peripheral doesn't conform to IEEE1284. We want to save CPU time: we are
 * waiting a maximum time of 500 us busy (this is for speed). If there is
 * not the right answer in this time, we call schedule and other processes
 * are able "to eat" the time up to 30ms.  So the maximum load avarage can't
 * get above 5% for a read even if the peripheral is really slow. (but your
 * read gets very slow then - only about 10 characters per second. This
 * should be tuneable). Thanks to Andreas who pointed me to this and ordered
 * the documentation.
 */ 

static int wait_peripheral(struct parport *port, unsigned char mask, 
	unsigned char result)
{
	int counter=0;
	unsigned char status;

#ifdef USE_NSLEEP
	struct timespec t;
#endif

	do {
		status=r_status(port);
#ifdef USE_NSLEEP
		t.tv_sec  = 0;
		t.tv_nsec = 1000000; /* originally 25000000 */
		nanosleep(&t, NULL);
#else
		usleep(25);
#endif
		counter++;

	} while ( ((status & mask) != result) && (counter < 20) );
	if ( (counter == 20) && ((status & mask) != result) ) { 
		status=r_status(port);
		if ((status & mask) != result) return 1; /* timeout */
	}
	return 0; /* okay right response from device */
}		


/* Test if nibble mode for status readback is okay. Returns the value false
 * if the printer doesn't support readback at all. If it supports readbacks
 * and printer data is available the function returns 1, otherwise 2. The
 * only valid values for "mode" are 0 and 4. 0 requests normal nibble mode,
 * 4 is for "request device id using nibble mode". The request for the
 * device id is best done in an ioctl (or at bootup time).  There is no
 * check for an invalid value, the only function using this call at the
 * moment is lp_read and the ioctl LPGETDEVICEID both fixed calls from
 * trusted kernel.
 */
static int nibble_mode_ok(struct parport *port, unsigned char mode) 
{
	int reply=1;

#ifdef	USE_NSLEEP
	struct timespec t;
#endif

	w_data(port, mode);

#ifdef USE_NSLEEP
	t.tv_sec  = 0;
	t.tv_nsec = LP_DELAY*1000;
	nanosleep(&t, NULL);
#else
	usleep(LP_DELAY);		
#endif

	w_ctrl(port, r_ctrl(port) & ~8);  /* SelectIN low */
	w_ctrl(port, r_ctrl(port) | 2); /* AutoFeed high */
	if (wait_peripheral(port, 0x78, 0x38)) { /* timeout? */
		w_ctrl(port, (r_ctrl(port) & ~2) | 8);
		return 0; /* first stage of negotiation failed, 
                           * no IEEE1284 compliant device on this port 
                           */ 
	}
	w_ctrl(port, r_ctrl(port) | 1);              /* Strobe high */
	t.tv_sec  = 0;
	t.tv_nsec = 5000000;
#ifdef USE_NSLEEP
	nanosleep(&t, NULL);
#else
	usleep(5);	 			     /* Strobe wait */
#endif
	w_ctrl(port, r_ctrl(port) & ~1);             /* Strobe low */

#ifdef USE_NSLEEP
	t.tv_sec  = 0;
	t.tv_nsec = LP_DELAY*1000;
	nanosleep(&t, NULL);
#else
	usleep(LP_DELAY);		
#endif

	w_ctrl(port, r_ctrl(port) & ~2);             /* AutoFeed low */
	if ( wait_peripheral(port, 0x20, 0) ) reply=2; 
						/* wait for PErr going low */
#ifdef LP_READ_DEBUG
	printf("lp%d: lp_nibble_ok: reply: %d\n", minor, reply);
#endif
	return reply;
}

static inline int read_nibble(struct parport *port) 
{
	unsigned char i;
	i=r_status(port)>>3;
	i&=~8;
	if ( ( i & 0x10) == 0) i|=8;
	return(i & 0x0f);
}


static void read_terminate(struct parport *port) {
	w_ctrl(port, (r_ctrl(port) & ~2) | 8);
	/* SelectIN high, AutoFeed low */
	if (wait_peripheral(port, 0x80, 0)) 
		/* timeout, SelectIN high, Autofeed low */
		return;
	w_ctrl(port, r_ctrl(port) | 2);
	/* AutoFeed high */
	wait_peripheral(port, 0x80, 0x80);
	/* no timeout possible, Autofeed low, SelectIN high */
	w_ctrl(port, (r_ctrl(port) & ~2) | 8);
	return;
}

static long read_polled(struct parport *port, char *buf, 
			   unsigned long length)
{
	int i;
	char *temp=buf;
	int count = 0;
	unsigned char z=0;
	unsigned char Byte=0;

	for (i=0; ; i++) {
		w_ctrl(port, r_ctrl(port) | 2);  /* AutoFeed high */
		if (wait_peripheral(port, 0x40, 0)) {
			w_ctrl(port, r_ctrl(port) & ~2);
			break;
		}
		z=read_nibble(port);
		w_ctrl(port, r_ctrl(port) & ~2);  /* AutoFeed low */
		if (wait_peripheral(port, 0x40, 0x40))
			break;
		if (( i & 1) != 0) {
			Byte= (Byte | z<<4);
			if (temp) 
				*(temp++) = Byte; 
			if (count++ == length)
				temp = NULL;
			/* Does the error line indicate end of data? */
			if ( (r_status(port) & LP_PERRORP ) == LP_PERRORP) 
				break;
		} else Byte=z;
	}
	read_terminate(port);
	return count; 
}


/* very simple interface for now - give it /dev/lp? and it probes the port */
/* NOTE - assumes the simple mapping of port address to lp? */
/*        0x3bc     /dev/lp0 */
/*        0x378     /dev/lp1 */
/*        0x278     /dev/lp2 */
	  
int pnp_probe_parport(struct devprobe **t, char *lport) {

    int i;
    int count;
    int fd;
    struct parport port;
    char lpport[10];
    unsigned char buffer[256];

    int flen, vlen, nleft;
    unsigned char *p, *q, *r;
    char *field, *value;

    /* see which port they picked */
    strncpy(lpport, lport, 8);
    lpport[8] = 0;
    if (!strncmp(lpport, "/dev/lp0", 8))
	port.base=0x3bc;
    else if (!strncmp(lpport, "/dev/lp1", 8))
	port.base=0x378;
    else if (!strncmp(lpport, "/dev/lp2", 8))
	port.base=0x278;
    else {
	return -1;
    }

    /* try and open port, make sure it isn't locked by another process */
    fd = open(lpport, O_RDWR | O_NONBLOCK);
    if (fd < 0) {
	return -1;
    }
    
    ioperm(port.base, 8, 1);
    
    i=nibble_mode_ok(&port, 4);

    if (i) {
	count=read_polled(&port, buffer, 256);
#ifdef DEBUG_LP
	printf("read_polled  = %d\n",i);
	printf("Count        = 0x%x\n",count);
	printf("Length bytes = 0x%x 0x%x\n",buffer[0],buffer[1]);
	printf("\n");
	print_hex_data(buffer, count);
	printf("\n");
	for  (i=2; i<count; i++)
	    if (buffer[i] == ';')
		printf("\n");
	    else
		printf("%c",buffer[i]);
	printf("\n");
#endif

	/* we need to break the PnP string returned by the printer */
	/* into a series of field/value pairs                      */
	/* ';' separate these pairs                                */
	*t=devprobe_create();
	if (!*t) {
	    close(fd);
	    ioperm(port.base, 8, 0);
	    exit(1);
	}
	devprobe_setinfo(*t, DEVPROBE_GENPNP);
	devprobe_insert(*t, "LINUX DEVICE", lpport);
	devprobe_insert(*t, "BUS", "PARALLEL");
	for (r=buffer+2; r<buffer+count; ) {
	    /* find the end of the field */
	    nleft = count - (r-buffer);
	    p = memchr(r, ':', nleft);
	    if (p) {
		flen = p-r;
		field = alloca(flen+1);
		field[flen] = 0;
		memcpy(field, r, flen);

		q = memchr(p+1, ';', nleft-flen+1);
		if (q) {
		    vlen = q-p-1;
		    value = alloca(vlen+1);
		    value[vlen] = 0;
		    memcpy(value, p+1, vlen);
		} else
		    value = NULL;

		devprobe_insert(*t, field, value);
		r = q+1;
	    } else {
		devprobe_destroy(*t);
		return -1;
	    }
	}
    } else {
	ioperm(port.base, 8, 0);
	return -1;
    }
    
    ioperm(port.base, 8, 0);
    return 0;
}

