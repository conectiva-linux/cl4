/* the devprobe structure                 */
/* contains the results of a device probe */

#ifndef DEVPROBE_H
#define DEVPROBE_H

struct devfield {
    char *name;       
    char *value;
};

struct devprobe {
    int              probe_info;     /* info on how probe was performed */
    int              nfields;        /* number of fields of probe data  */
    struct devfield  **fields;       /* actual data for fields */
};

/* values that the probe_info field can have (may be or'd together) */
/* by no means are all implemented                                  */
/* and these values are subject to change on a whim                 */
#define DEVPROBE_NONE    0  /* no information available */
#define DEVPROBE_LEGACY  1  /* used a legacy method for probing old hw */
#define DEVPROBE_PCI     2  /* PCI probe (/proc/pci for example)       */
#define DEVPROBE_ISAPNP  4  /* isapnp probe (?)                        */
#define DEVPROBE_GENPNP  8  /* Generic PnP probe (parallel, serial probes)  */
#define DEVPROBE_SCSI   16  /* /proc/scsi                              */
#define DEVPROBE_IDE    32  /* IDE/ATAPI devices                       */
#define DEVPROBE_PSAUX  64  /* PS/2 devices                            */

/* function prototypes */
struct devprobe *devprobe_create( void );
void   devprobe_destroy( struct devprobe *s );
int devprobe_insert( struct devprobe *s, char *fieldname, char *value );
int devprobe_delete( struct devprobe *s, char *fieldname);
char *devprobe_match( struct devprobe *s, char *fieldname );
int devprobe_setinfo( struct devprobe *s, int flag );
int devprobe_getinfo( struct devprobe *s );
void devprobe_print( struct devprobe *s, FILE *f );
void devprobe_sprint( struct devprobe *s, char **buf );
char *devprobe_infotoasc( struct devprobe *s );
int devprobe_guess_pnp_class( struct devprobe *s );

#endif
