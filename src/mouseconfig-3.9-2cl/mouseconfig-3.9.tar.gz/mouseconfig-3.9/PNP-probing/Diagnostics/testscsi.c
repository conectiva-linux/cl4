#include <stdio.h>
#include <string.h>

main() {

    FILE *f;
    int host, channel, id, lun;
    char buf[100];

    f=fopen("/proc/scsi/scsi", "r");
    if (!f)
	exit(1);

    while (1) {
	if (!fgets(buf,100,f))
	    break; 

	printf("buf=|%s|\n",buf);

	if (strstr(buf, "Host:") && strstr(buf, "Id:")) {
	    /* found it, now parse out stuff we care about */
	    sscanf(buf, "Host: scsi%d Channel: %0d Id: %0d Lun: %0d\n",
		   &host, &channel, &id, &lun);
	    printf("host %d channel %d id %d lun %d\n",
		   host, channel, id, lun);
	}
    }
}
