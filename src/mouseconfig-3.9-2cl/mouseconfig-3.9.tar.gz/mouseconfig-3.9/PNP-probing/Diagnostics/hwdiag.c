/* newt app which uses various probing techniques to  identify devices 
 * installed on the current system.                                    
 *
 * Michael Fulbright (msf@redhat.com)
 *
 * Copyright 1997 Red Hat Software 
 *
 * This software may be freely redistributed under the terms of the GNU
 * public license.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>

#include <linux/hdreg.h>
#include <linux/cdrom.h>
#include <sys/mtio.h>

#include <newt.h>

/* should consolidate all of these into a main header file eventually */
#include "devprobe.h"
#include "pnp_probe_com.h"
#include "pnp_probe_parport.h"


static char version[] = HWDIAG_VERSION;

/* Used to hold all the probed devices of a certain type */
struct probedevs {
    int ndevs;
    struct devprobe **probe;
};


/* hardcoded, maybe someday we'll get these from tty ? */
int screen_width=80;
int screen_height=25;


/* clean up that string */
static void trim_whitespace( char *s ) {
    char *f, *l, *p, *q;

    if (!(*s))
        return;
    
    for (f=s; *f && isspace(*f); f++) ;

    if (!*f) {
        *s = '\0';
        return;
    }
    
    for (l=f+strlen(f)-1; isspace(*l) ; l--)
    *l = '\0';
        
    q = s, p = f;
    while (*p)
        *q++ = *p++;
    
    *q = '\0';
}


/* display summary line given by char * arg */
int show_serial_warning(void) {
    newtComponent infoform, yes, no, infobox, answer;
    int retcode;
    
    char *serial_warning = "WARNING: If you have a UPS or serial "
	"printer attached to your system, you may want to avoid using the "
	"serial port probe. If you have a UPS and you probe the UPS port, "
	"the probe could inadvertantly tell the UPS to turn off. If you have "
	"a serial printer, you may get a few characters printed.\n\n"
        "Also, if you run this utility under X, you are likely to be "
        "unable to use a serial mouse without restarting X.\n\n"
        "    Would you like to probe serial devices?";
    
    newtOpenWindow(7, 4, 64, 16, "WARNING");
    infoform = newtForm(NULL, NULL, 0);
    infobox=newtTextbox(3, 1, 60, 10, NEWT_TEXTBOX_WRAP);
    newtTextboxSetText( infobox, serial_warning );
    yes = newtButton( 13, 12, "Yes");
    no  = newtButton( 43, 12, "No");
		
    newtFormAddComponents(infoform, infobox, yes, no, NULL);
    answer = newtRunForm( infoform );

    if (answer == yes)
	retcode = 1;
    else
	retcode = -1;
    
    newtPopWindow();
    newtFormDestroy(infoform);
    return retcode;
}

int intro_screen( void ) {
    newtComponent form, infobox, ok, quit, answer;
    int retcode;
    char *intro_text = " The Red Hat HW Discovery Utility is intended to aid "
	"end-users in determining the hardware installed in their system. "
	"By using various probing methods (PCI, PnP, etc), this utility "
	"should find most post-1994 hardware. On older machines hardware "
	"may not be detected, since there were few standards on how to "
	"detect hardware back then.\n\n"
	"              Would you like to continue?";
	
    newtOpenWindow(10, 4, 60, 15, "Introduction");
    form = newtForm(NULL, NULL, 0);

    infobox = newtTextbox(4, 1, 54, 11, NEWT_TEXTBOX_WRAP);
    newtTextboxSetText( infobox, intro_text );

    ok   = newtButton(18, 11, "Ok");
    quit = newtButton(36, 11, "Quit");
    newtFormAddComponents(form, infobox, ok, quit, NULL);
    answer = newtRunForm( form );

    if (answer == ok)
	retcode = 0;
    else
	retcode = -1;

    newtPopWindow();
    newtFormDestroy(form);
    return retcode;
}


int show_info_dialog( newtComponent *form, char *title, char *msg,
		      int width, int height) {
    newtComponent infobox;
    int cx, cy;

    cx = (screen_width-width)/2;
    cy = (screen_height-height)/2;
    newtOpenWindow(cx, cy, width, height, title);
    *form = newtForm(NULL, NULL, 0);

    infobox = newtTextbox(2, 1, width-4, height-2, NEWT_TEXTBOX_WRAP);
    newtTextboxSetText( infobox, msg );
    newtFormAddComponents( *form, infobox, NULL );
    newtDrawForm( *form );
    newtRefresh();
    return 0;
}

void remove_info_dialog( newtComponent *form ) {
    newtPopWindow();
    newtFormDestroy(*form);
}

void show_info_dialog_and_wait( char *title, char *msg,
		      int width, int height) {

    newtComponent infobox, ok, form;
    int cx, cy;

    if (height < 7)
	return;

    cx = (screen_width-width)/2;
    cy = (screen_height-height)/2;
    newtOpenWindow(cx, cy, width, height, title);
    form = newtForm(NULL, NULL, 0);
    infobox = newtTextbox(2, 1, width-4, height-5, NEWT_TEXTBOX_WRAP);
    newtTextboxSetText( infobox, msg );
    ok = newtButton(width/2-2, height - 4, "Ok");
    newtFormAddComponents( form, infobox, ok, NULL );
    newtRunForm( form );
    newtPopWindow();
    newtFormDestroy( form );
}


int show_info_dialog_and_getstr( char *title, char *msg, char *label,
				  char *old, char **str,
				 int width, int height) {

    newtComponent infobox, entry, ok, cancel, form, answer;
    int cx, cy;
    int retcode;
	
    if (height < 9 || width < 15)
	return -1;
    
    cx = (screen_width-width)/2;
    cy = (screen_height-height)/2;
    newtOpenWindow(cx, cy, width, height, title);
    form = newtForm(NULL, NULL, 0);
    infobox = newtTextbox(2, 1, width-4, height-4, NEWT_TEXTBOX_WRAP);
    newtTextboxSetText( infobox, msg );
    newtFormAddComponent(form, newtLabel(4, height-2, label));
    entry = newtEntry(8+strlen(label), height-2, old,
		       width-12-strlen(label), str, NEWT_FLAG_RETURNEXIT);
#if WE_CARE
    ok     = newtButton(width/4-2, height - 4, "Ok");
    cancel = newtButton((width/4)*3-4, height - 4, "Cancel");
    newtFormAddComponents( form, infobox, entry, ok, cancel, NULL );
#endif
    newtFormAddComponents( form, infobox, entry, NULL );
    newtRunForm( form );

	
    newtPopWindow();
    newtFormDestroy( form );
    return 1;
}

void display_help( void ) {

    show_info_dialog_and_wait("Help",
       "This utility attempts to identify the hardware devices installed "
       "in your computer.  For each possible device a single line report "
       "is presented giving its current status.  By pressing the <ENTER> "
       "key you can see more details about the device.\n  You can also "
       "generate a summary report which you can mail to Red Hat Software "
       "when you request technical support.  We are also interested in "
       "receiving reports so that we can build a database of hardware "
       "which works with Linux.  So please email in your results to "
       "hwsurvey@redhat.com !", 65, 16 );
}
		      

/* display details about the devprobe */
void show_device_details( struct devprobe *t ) {
    newtComponent infoform, infook, infobox, answer;
    char *buf=NULL;
    char *probe;

    if (!t)
	return;

    probe = devprobe_match( t, "PROBE RESULT");
    if (!probe || strncmp( probe, "SUCCEED", 6 ))
	return;
    
    devprobe_sprint( t, &buf);
    if (!buf)
	return;
    
    newtOpenWindow(6, 4, 68, 16, "Device Info");
    infoform = newtForm(NULL, NULL, 0);
    infobox=newtTextbox(3, 1, 62, 10, 
			NEWT_TEXTBOX_WRAP|NEWT_TEXTBOX_SCROLL);
    newtTextboxSetText( infobox, buf );
    infook = newtButton( 30, 12, "Ok");
		
    newtFormAddComponents(infoform, infobox, infook, NULL);
    answer = newtRunForm( infoform );

    newtPopWindow();
    newtFormDestroy(infoform);
    free(buf);
}


/* return < 0 if failed                                                      */
/* If port exists but no device recognized, it is included                   */
/* but no useful information will be gathered                                */
/* Sets a 'PROBE RESULT' field in each ports devprobe entry to give result   */
int probe_serial_devices( struct probedevs *t ) {
    newtComponent dialog;
    int i, fd;
    int status=0;
    struct devprobe *p;
    char infostr[80];

#define NUM_SERIAL_PORTS 4
    char *serialnames[NUM_SERIAL_PORTS] = {
	"/dev/ttyS0", "/dev/ttyS1", "/dev/ttyS2", "/dev/ttyS3" };

    if (!t)
	return -1;
    
    t->ndevs=0;
    t->probe=NULL;

    for (i=0; i< NUM_SERIAL_PORTS; i++) {
	snprintf(infostr, 80, "Probing serial device %s", serialnames[i]);
	show_info_dialog( &dialog, "Probing serial devices", infostr, 40, 3);

	/* we got enough info, let make a devprobe entry */
	if ((t->ndevs % 8) == 0)
	    t->probe=realloc(t->probe,
			     (t->ndevs+8)*sizeof(struct devprobe));
	
	fd=open(serialnames[i], O_RDWR|O_NONBLOCK);
	if (fd >= 0)
	    status=isatty(fd);
	else
	    status=-1;
	if (fd < 0 || !status) {

	    p=devprobe_create();
	    devprobe_setinfo(p, DEVPROBE_NONE);
	    devprobe_insert(p, "LINUX DEVICE", serialnames[i]);
	    devprobe_insert(p, "BUS", "SERIAL");
	    
	    /* see if the port is busy or not */
	    if (!status && fd >= 0) {
		devprobe_insert(p, "PROBE RESULT", "N/A");
	    } else if (errno == EBUSY) {
		devprobe_insert(p, "PROBE RESULT", "LOCKED");
	    } else {
		devprobe_insert(p, "PROBE RESULT", "FAILED");
	    }
	} else {
	    close(fd);
	    if (pnp_probe_com(&p, serialnames[i]) < 0) {
		p=devprobe_create();
		devprobe_setinfo(p, DEVPROBE_NONE);
		devprobe_insert(p, "LINUX DEVICE", serialnames[i]);
		devprobe_insert(p, "BUS", "SERIAL");
		devprobe_insert(p, "PROBE RESULT", "FAILED");
	    } else {
		devprobe_insert(p, "PROBE RESULT", "SUCCEED");
	    }
	}
	remove_info_dialog( &dialog );
	t->probe[i]=p;
	t->ndevs++;
    }
    return 0;
}
		

/* return < 0 if failed                                                      */
/* If port exists but no device recognized, it is included                   */
/* but no useful information will be gathered                                */
/* Sets a 'PROBE RESULT' field in each ports devprobe entry to give result   */
int probe_parport_devices( struct probedevs *t ) {
    newtComponent dialog;
    int i, fd;
    struct devprobe *p;
    char infostr[100];
    
#define NUM_PARPORTS 3
    char *parportnames[NUM_PARPORTS] = {"/dev/lp0", "/dev/lp1", "/dev/lp2" };

    if (!t)
	return -1;
    
    t->ndevs=0;
    t->probe=NULL;

    for (i=0; i< NUM_PARPORTS; i++) {
	snprintf(infostr, 100, "  Probing parallel device %s\n\n"
		 "This could take up to 15-20 seconds.", parportnames[i]);
	show_info_dialog( &dialog, "Probing parallel devices", infostr, 40, 5);

	/* we got enough info, let make a devprobe entry */
	if ((t->ndevs % 8) == 0)
	    t->probe=realloc(t->probe,
			     (t->ndevs+8)*sizeof(struct devprobe));
	
	fd=open(parportnames[i], O_RDWR|O_NONBLOCK);
	if (fd < 0 ) {

	    p=devprobe_create();
	    devprobe_setinfo(p, DEVPROBE_NONE);
	    devprobe_insert(p, "LINUX DEVICE", parportnames[i]);
	    devprobe_insert(p, "BUS", "PARALLEL");
	    
	    /* see if the port is busy or not */
	    if (errno == EBUSY) {
		devprobe_insert(p, "PROBE RESULT", "LOCKED");
	    } else {
		devprobe_insert(p, "PROBE RESULT", "N/A");
	    }
	} else {
	    close(fd);
	    if (pnp_probe_parport(&p, parportnames[i]) < 0) {
		p=devprobe_create();
		devprobe_setinfo(p, DEVPROBE_NONE);
		devprobe_insert(p, "LINUX DEVICE", parportnames[i]);
		devprobe_insert(p, "BUS", "PARALLEL");
		devprobe_insert(p, "PROBE RESULT", "FAILED");
	    } else {
		devprobe_insert(p, "PROBE RESULT", "SUCCEED");
	    }
	}
	remove_info_dialog( &dialog );
	t->probe[i]=p;
	t->ndevs++;
    }
    return 0;
}


/* return < 0 if failed                                                      */
/* If port exists but no device recognized, it is included                   */
/* but no useful information will be gathered                                */
/* Sets a 'PROBE RESULT' field in each ports devprobe entry to give result   */
int probe_psaux_devices( struct probedevs *t ) {
    newtComponent dialog;
    int i, fd;
    struct devprobe *p;
    char infostr[100];
    char buf[256];
    int len;
    
    if (!t)
	return -1;
    
    t->ndevs=0;
    t->probe=NULL;

    snprintf(infostr, 100, "  Probing PS/2 Mouse port");
    show_info_dialog( &dialog, "Probing Mouse", infostr, 30, 5);

    /* we got enough info, let make a devprobe entry */
    if ((t->ndevs % 8) == 0)
	t->probe=realloc(t->probe,
			 (t->ndevs+8)*sizeof(struct devprobe));
	
	
    p=devprobe_create();
    devprobe_setinfo(p, DEVPROBE_NONE);
    devprobe_insert(p, "LINUX DEVICE", "/dev/psaux");
    devprobe_insert(p, "BUS", "PSAUX");
	
    fd=open("/dev/psaux", O_RDONLY|O_NONBLOCK);
    if (fd < 0 ) {
	/* see if the port is busy or not */
	if (errno == EBUSY) {
	    devprobe_insert(p, "PROBE RESULT", "LOCKED");
	} else
	    devprobe_insert(p, "PROBE RESULT", "N/A");
    } else {
       if (!((len = read (fd,buf,sizeof(buf)) == 1) && buf[0] == -2)) {
	close(fd);
	devprobe_setinfo(p, DEVPROBE_PSAUX);
	devprobe_insert(p, "MODEL", "PS/2 Mouse");
	devprobe_insert(p, "CLASS", "MOUSE");
	devprobe_insert(p, "PROBE RESULT", "SUCCEED");
       } else {
	  close(fd);
       }
    }

    remove_info_dialog( &dialog );
    t->probe[0]=p;
    t->ndevs++;

    return 0;
}

/* return < 0 if failed                                                      */
/* If port exists but no device recognized, it is included                   */
/* but no useful information will be gathered                                */
/* Sets a 'PROBE RESULT' field in each ports devprobe entry to give result   */
int probe_pci_devices( struct probedevs *t ) {
    newtComponent dialog;
    int done;
    int bus, device, function;
    char *devtype, *devmodel, *vendorid, *deviceid;
    int stage;
    FILE *f;
    struct devprobe *p;
    char buf[100];
    char infostr[80];


    if (!t)
	return -1;
    
    t->ndevs=0;
    t->probe=NULL;
    
    snprintf(infostr, 100, "  Probing PCI bus");
    show_info_dialog( &dialog, "Probing PCI devices", infostr, 30, 3);

    /* open /proc/pci and parse output */
    f=fopen("/proc/pci", "r");
    if (!f) {
	remove_info_dialog( &dialog );
	return -1;
    }

    done = 0;
    stage = 0;
    while (!done) {
	if (!fgets(buf,100,f))
	    break;

	/* see what we're looking for */
	if (stage == 0) {
	    /* need to find start of list of PCI devices */
	    if (!strncmp(buf, "PCI devices found:", 18))
		stage++;
	    continue;
	} else if (stage == 1) {
	    /* looking for a line starting with 'Bus' */
	    if (strstr(buf, "Bus") && strstr(buf, "device")) {
		/* found it, now parse out stuff we care about */
		sscanf(buf, "  Bus %d, device %d, function %d:\n",
		       &bus, &device, &function);

		/* read the next line for other goodies */
		if (!fgets(buf,100,f))
		    break;

		/* strip out devtype and model of card */
		devmodel = strchr(buf, ':');
		if (!devmodel)
		    continue;
		*devmodel++ = 0;

		devtype=strdup(buf);
		devmodel=strdup(devmodel);
		trim_whitespace(devtype);
		trim_whitespace(devmodel);

		/* see if its an unknown model */
		deviceid = vendorid = NULL;
		if (strstr(devmodel, "Unknown")) {
		    if (!fgets(buf,100,f))
			break;
		    if (strstr(buf, "Vendor id")) {
			char *s, *t, *v;
			s = strchr(buf, '=');
			if (s) {
			    s++;
			    t = strchr(s, '.');
			    if (t) {
				*t = 0;
				t = strchr(t+1, '=');
				if (t) {
				    t++;
				    v = strchr(t, '.');
				    if (v) {
					*v = 0;
					vendorid = strdup(s);
					deviceid = strdup(t);
					trim_whitespace(vendorid);
					trim_whitespace(deviceid);
				    }
				}
			    }
			}
		    }
		}
		    
		/* we got enough info, let make a devprobe entry */
		if ((t->ndevs % 8) == 0)
		    t->probe=realloc(t->probe,
				     (t->ndevs+8)*sizeof(struct devprobe));
		p=devprobe_create();
		devprobe_setinfo(p, DEVPROBE_PCI);
		snprintf(buf, 100, "PCI%d:%d:%d\n",bus,device,function);
		trim_whitespace(buf);
		devprobe_insert(p, "LINUX DEVICE", buf);
		devprobe_insert(p, "BUS", "PCI");
		devprobe_insert(p, "CLASS", devtype);
		devprobe_insert(p, "MODEL", devmodel);
		if (vendorid && deviceid) {
		    devprobe_insert(p, "VENDOR ID", vendorid);
		    devprobe_insert(p, "DEVICE ID", deviceid);
		    free(vendorid);
		    free(deviceid);
		}
		devprobe_insert(p, "PROBE RESULT", "SUCCEED");
		t->probe[t->ndevs++] = p;
		free(devtype);
		free(devmodel);
	    }
	}
    }
    fclose(f);
    remove_info_dialog( &dialog );
    return 0;
}


/* return < 0 if failed                                                      */
/* If port exists but no device recognized, it is included                   */
/* but no useful information will be gathered                                */
/* Sets a 'PROBE RESULT' field in each ports devprobe entry to give result   */
int probe_scsi_devices( struct probedevs *t ) {
    newtComponent dialog;
    int done;
    int host, channel, id, lun;
    char *devtype, *devmodel, *devrev, *devmfg, *scsirev;
    int stage;
    FILE *f;
    struct devprobe *p;
    char buf[100];
    char infostr[80];


    if (!t)
	return -1;
    
    t->ndevs=0;
    t->probe=NULL;
    
    snprintf(infostr, 100, "  Probing SCSI bus");
    show_info_dialog( &dialog, "Probing SCSI devices", infostr, 30, 3);

    /* open /proc/pci and parse output */
    f=fopen("/proc/scsi/scsi", "r");
    if (!f) {
	return -1;
	remove_info_dialog( &dialog );
    }

    done = 0;
    stage = 0;
    while (!done) {
	if (!fgets(buf,100,f))
	    break;

	/* see what we're looking for */
	if (stage == 0) {
	    /* need to find start of list of PCI devices */
	    if (!strncmp(buf, "Attached devices:", 17))
		stage++;
	    continue;
	} else if (stage == 1) {
	    /* looking for a line starting with 'Host' */
	    if (strstr(buf, "Host:") && strstr(buf, "Id:")) {
		/* found it, now parse out stuff we care about */
		sscanf(buf, "Host: scsi%d Channel: %0d Id: %0d Lun: %0d\n",
		       &host, &channel, &id, &lun);

		/* read the next line for other goodies */
		if (!fgets(buf,100,f))
		    break;

		/* identify parts we want */
		devmfg = strstr(buf, "Vendor:");
		if (!devmfg)
		    continue;
		devmfg += 7;

		devmodel = strstr(devmfg, "Model:");
		if (!devmodel)
		    continue;
		*devmodel = 0;
		devmodel += 6;

		devrev = strstr(devmodel, "Rev:");
		if (!devrev)
		    continue;
		*devrev = 0;
		devrev += 4;

		/* woohoo we got all we asked for */
		devmfg=strdup(devmfg); trim_whitespace(devmfg);
		devmodel=strdup(devmodel); trim_whitespace(devmodel);
		devrev=strdup(devrev); trim_whitespace(devrev);

		/* read the next line for other goodies */
		if (!fgets(buf,100,f)) {
		    free(devmfg); free(devmodel); free(devrev);
		    break;
		}

		/* identify parts we want */
		devtype = strstr(buf, "Type:");
		if (!devtype) {
		    free(devmfg); free(devmodel); free(devrev);
		    continue;
		}
		devtype += 5;

		scsirev = strstr(devtype, "ANSI SCSI revision:");
		if (!scsirev) {
		    free(devmfg); free(devmodel); free(devrev);
		    continue;
		}
		*scsirev = 0;
		scsirev += 19;

		/* woohoo we got all we asked for */
		devtype=strdup(devtype); trim_whitespace(devtype);
		scsirev=strdup(scsirev); trim_whitespace(scsirev);
		
		/* we got enough info, let make a devprobe entry */
		if ((t->ndevs % 8) == 0)
		    t->probe=realloc(t->probe,
				     (t->ndevs+8)*sizeof(struct devprobe));
		p=devprobe_create();
		devprobe_setinfo(p, DEVPROBE_SCSI);
		snprintf(buf, 100, "SCSI%d:%d:%d:%d\n",
			 host,channel,id,lun);
		trim_whitespace(buf);
		devprobe_insert(p, "LINUX DEVICE", buf);
		devprobe_insert(p, "BUS", "SCSI");
		devprobe_insert(p, "MANUFACTURER", devmfg);
		devprobe_insert(p, "MODEL", devmodel);
		devprobe_insert(p, "MODEL REV", devrev);
		devprobe_insert(p, "SCSI REV", scsirev);
		devprobe_insert(p, "CLASS", devtype);
		devprobe_insert(p, "PROBE RESULT", "SUCCEED");
		t->probe[t->ndevs++] = p;
		free(devmfg);
		free(scsirev);
		free(devrev);
		free(devtype);
		free(devmodel);
	    }
	}
    }
    fclose(f);
    remove_info_dialog( &dialog );
    return 0;
}


/* return < 0 if failed                                                      */
/* If port exists but no device recognized, it is included                   */
/* but no useful information will be gathered                                */
/* Sets a 'PROBE RESULT' field in each ports devprobe entry to give result   */
int probe_ide_devices( struct probedevs *t ) {
    newtComponent dialog;
    int fd, i;
    int err=-1;
    struct devprobe *p;
    char buf[100];
    char infostr[80];
    char *class;
    char *model;
    char geom[80];

    int  numide = 8;
    char *idenames[8] = { "hda", "hdb", "hdc", "hdd",
			  "hde", "hdf", "hdg", "hdh" };
    
    if (!t)
	return -1;
    
    t->ndevs=0;
    t->probe=NULL;
    
    snprintf(infostr, 100, "  Probing IDE bus");
    show_info_dialog( &dialog, "Probing IDE devices", infostr, 25, 3);

    /* go thru possible IDE devices and see if they exist */
    for (i=0; i<numide; i++) {
	/* make a devprobe entry */
	if ((t->ndevs % 8) == 0)
	    t->probe=realloc(t->probe,
			     (t->ndevs+8)*sizeof(struct devprobe));
	
	p=devprobe_create();
	devprobe_insert(p, "BUS", "IDE");
	snprintf(buf, 100, "/dev/%s", idenames[i]);
	devprobe_insert(p, "LINUX DEVICE", buf);
	fd=open(buf, O_RDONLY);

	if (fd >= 0) {
	    /* lets figure out the class */
	    struct hd_geometry  hdgeom;
	    struct hd_driveid    hdid;
	    struct cdrom_volctrl cdid;
	    struct mtget         mtid;

	    err = 0;
	    class = NULL;
	    model = NULL;
	    geom[0] = 0;
	    if (!ioctl(fd, HDIO_GETGEO, &hdgeom)) {
		snprintf(geom,80,"%d cyl, "
			         "%d heads, "
			         "%d sectors",
			 hdgeom.cylinders,hdgeom.heads, hdgeom.sectors);
		class = "HARD DRIVE";
		if (!ioctl(fd, HDIO_GET_IDENTITY, &hdid))
		    if (hdid.model[0])
			model = strdup(hdid.model);
	    } else if (!ioctl(fd, CDROMVOLREAD, &cdid))
		class = "CDROM";
		if (!ioctl(fd, HDIO_GET_IDENTITY, &hdid))
		    if (hdid.model[0])
			model = strdup(hdid.model);
	    else if (!ioctl(fd, MTIOCGET, &mtid)) 
		class = "TAPE";
		if (!ioctl(fd, HDIO_GET_IDENTITY, &hdid))
		    if (hdid.model[0])
			model = strdup(hdid.model);
	    else
		err = -1;
	}

	if (fd < 0 || err) {
	    devprobe_setinfo(p, DEVPROBE_NONE);
	    devprobe_insert(p, "PROBE RESULT", "FAILED");
	} else {
	    devprobe_setinfo(p, DEVPROBE_IDE);
	    devprobe_insert(p, "BUS", "IDE");
	    if (model) {
		devprobe_insert(p, "MODEL", model);
		free(model);
	    }
	    if (geom[0])
		devprobe_insert(p, "GEOMETRY", geom);

	    devprobe_insert(p, "CLASS", class);
	    devprobe_insert(p, "PROBE RESULT", "SUCCEED");
	}
	t->probe[t->ndevs++] = p;
    }
    close(fd);
    remove_info_dialog( &dialog );
    return 0;
}

/* fill in the                                          */
/* position in the status line, up to length characters */
/* if cen=1, center it                                    */
void build_table_field( char *line, char *val, int pos, int length, int cen ) {
    char *p, *q;
    int i;
    int c;

    /* lets center field value in the field */
    if (cen) {
	c = strlen(val);
	c = (length-c)/2;
	if (c < 0)
	    c = 0;
    } else
	c=0;

    /* first setup device name */
    for (p=val, q=line+pos+c, i=c; *p && i<length; p++, q++, i++)
	*q = *p;
}

/* simple helper function to tack a string onto a buffer, growing */
/* the buffer by the required amount                              */
void strcatbuf(char **buf, char *str) {
    int len;

    if (!str || !buf)
	return;
    if (!*buf)
	len = 0;
    else
	len = strlen(*buf);
    *buf=realloc(*buf, len+strlen(str)+2);
    if (len)
	strcat(*buf, str);
    else
	strcpy(*buf, str);
}    

void write_file_to_survey(FILE *f, char *file) {
    FILE *c;
    int done;
    char buf[256];
    
    if ((c=fopen(file, "r"))==NULL) {
	fprintf(f, "ERROR - Could not open %s", file);
	return;
    }

    done = 0;
    while (!done) {
	if (!fgets(buf, 256, c))
	    done = 1;
	else
	    fputs(buf, f);
    }
    fclose(c);
}

void save_survey_to_file( int ndev, struct devprobe **t, char *summary ) {
    newtComponent form, fname, text, ok, cancel, answer;

    FILE *f;
    int  i;
    char *outname;
    char *probe_result;
    
    newtOpenWindow( 12, 7, 56, 11, "Save Survey To File" );
    form = newtForm(NULL,NULL,0);
    text = newtTextbox(5,1,50,4,NEWT_TEXTBOX_WRAP);
    newtTextboxSetText(text,
		       "A text file containing a summary of the detected "
		       "devices on your system will now be written. Please "
		       "supply a filename for this file:");
    newtFormAddComponent(form, newtLabel(6, 5, "Output Filename:"));
    fname = newtEntry(22, 5, "hw_survey.txt", 20, &outname,
		      NEWT_FLAG_RETURNEXIT);
    ok = newtButton( 13, 7, "Ok");
    cancel  = newtButton( 33, 7, "Cancel");
    newtFormAddComponents( form, text, fname, ok, cancel, NULL);
    answer = newtRunForm(form);

    if (answer != cancel) {
	f = fopen(outname, "w");
	if (f==NULL) {
	    show_info_dialog_and_wait("Error creating file",
		       "   Error creating the output file!", 40, 7);
	} else {
	    fprintf(f,"Red Hat HW Discovery Version %s -  Survey\n",version);
	    fputs("----------------------------------------"
		  "----------------------------------------\n\n", f);
	    fputs("------ Contents of /proc/cpuinfo -------"
		  "----------------------------------------\n", f);
	    write_file_to_survey(f, "/proc/cpuinfo");
	    fputs("\n------ Contents of /proc/version -------"
		  "----------------------------------------\n", f);
	    write_file_to_survey(f, "/proc/version");
	    fputs("\n------ Contents of /etc/redhat-release -"
		  "----------------------------------------\n", f);
	    write_file_to_survey(f,"/etc/redhat-release");
	    fputs("\n------ Contents of /etc/printcap -----"
		  "----------------------------------------\n", f);
	    write_file_to_survey(f,"/etc/printcap");
	    fputs("\n----------------------------------------"
		  "----------------------------------------\n", f);
	    fputs("Summary of device probe results:\n\n",f);
	    fputs(summary, f);
	    fputs("----------------------------------------"
		  "----------------------------------------\n", f);
	    fputs("----------------------------------------"
		  "----------------------------------------\n", f);
	    fputs("\nDetailed probe results:\n\n", f);
	    for (i=0; i<ndev; i++) {
		probe_result=devprobe_match(t[i], "PROBE RESULT");
		if (probe_result && !strncmp(probe_result, "SUCCEED", 6)) {
		    int type;
		    char *buf;
		    
		    /* get model info for PCI DEVICES */
		    type = devprobe_getinfo(t[i]) & DEVPROBE_PCI;
		    if (type) {
			char *tmpstr;
			char *model;
			tmpstr = devprobe_match(t[i], "CLASS");
			model  = devprobe_match(t[i], "MODEL");
			if (tmpstr && (strstr(tmpstr, "Ethernet") ||
				       strstr(tmpstr, "SCSI") ||
				       strstr(tmpstr, "VGA"))) {
			    char s[2048];
			    if (!model)
				model = strdup("Unknown model");
			    snprintf(s, 2048,
				     "The probe detected a PCI card:\n\n"
				     "   Type  : %s\n   Model : %s\n\n"
                                     "Please enter the "
				     "exact model for this card so we can "
				     "add it to our hardware database.\n\n"
				     "Enter the information in the "
				     "form:\n      MANUFACTURER/MODEL\n\n"
				     "For example, \n"
				     "      ACME/WonderVGA 45000XL\n\n"
				     "  -> This information is NOT required, "
				     "hit ENTER to skip <-"
				     ,tmpstr,model);
			    show_info_dialog_and_getstr("PCI Model Info",
							s,"Model: ", "", &buf,
							65, 20);
			    devprobe_insert(t[i], "USER COMMENT", buf);
			    free(tmpstr);
			    free(model);
			}
		    }
		    devprobe_print(t[i], f);
		    devprobe_delete(t[i], "USER COMMENT");
		    fputs("\n",f);
		}
	    }
	    fputs("--------- END OF HW DISCOVERY SURVEY----"
		  "----------------------------------------\n", f);
	    fclose(f);
	    show_info_dialog_and_wait("Success", "The report was successfully "
				      "written to disk.\n\n"
				      "If you haven't already, please email "
				      "a copy of your report to\n\n"
				      "               hwsurvey@redhat.com\n",
				      50, 12);
	}
    }
    newtPopWindow();
    newtFormDestroy(form);
}	


void start_master( void ) {
    newtComponent form, ok, help, survey, quit, devbox, answer;

    int do_serial_probe=0;
    int i;
    int port_exists;
    int num_devices=0;

    int formdone;
    struct newtExitStruct event;
    
    char statstr[100];
    char *tmpstr;
    char *summarybuf;
    
    struct probedevs serialdev  = {0, NULL};
    struct probedevs parportdev = {0, NULL};
    struct probedevs pcidev     = {0, NULL};
    struct probedevs idedev     = {0, NULL};
    struct probedevs scsidev    = {0, NULL};
    struct probedevs psauxdev   = {0, NULL};
    
    struct devprobe *devices[100]; /* 100 should be enough for now */
    struct devprobe *t;

    /* first warn the user of possible danger of probing serial devices */
    if (show_serial_warning() < 0)
	do_serial_probe = 0;
    else
	do_serial_probe = 1;

    /* end of static form elements, now we need to build up the list */
    /* of devices we are going to display information about          */
    if (do_serial_probe) {
	probe_serial_devices(&serialdev);
	for (i=0; i<serialdev.ndevs; i++)
	    devices[num_devices++] = serialdev.probe[i];
    }
    
    probe_parport_devices(&parportdev);
    for (i=0; i<parportdev.ndevs; i++)
	devices[num_devices++] = parportdev.probe[i];

    probe_psaux_devices(&psauxdev);
    for (i=0; i<psauxdev.ndevs; i++)
	devices[num_devices++] = psauxdev.probe[i];

    probe_ide_devices(&idedev);
    for (i=0; i<idedev.ndevs; i++)
	devices[num_devices++] = idedev.probe[i];

    probe_pci_devices(&pcidev);
    for (i=0; i<pcidev.ndevs; i++)
	devices[num_devices++] = pcidev.probe[i];

    probe_scsi_devices(&scsidev);
    for (i=0; i<scsidev.ndevs; i++)
	devices[num_devices++] = scsidev.probe[i];

/* build the main list of installed/probed devices */
    newtOpenWindow(3, 3, 74, 18, "Currently Installed Devices");
    form = newtForm(NULL, NULL, 0);

    /* put summary line at top */
    newtFormAddComponent(form, newtLabel(1,0,
"                         Probe                            \n"));
    newtFormAddComponent(form, newtLabel(1,1,
"   Port         Bus      Status      Mfg/Model/Description\n"));
    newtFormAddComponent(form, newtLabel(1,2,
"  ------       -----    --------    -----------------------\n"));
    
    devbox = newtListbox( 1, 3, 10, NEWT_FLAG_RETURNEXIT | NEWT_FLAG_SCROLL );
    summarybuf=NULL;
    for (i=0; i<num_devices; i++) {
	t=devices[i];
	memset(statstr, ' ', sizeof(statstr));

	/* device name */
	tmpstr = devprobe_match(t, "LINUX DEVICE");
	if (!tmpstr)
	    tmpstr = strdup("Unknown");
	build_table_field(statstr, tmpstr, 0, 12, 0);
	free(tmpstr);

	/* Bus type */
	tmpstr = devprobe_match(t, "BUS");
	if (!tmpstr)
	    tmpstr = strdup("Unknown");
	build_table_field(statstr, tmpstr, 13, 8, 1);
	free(tmpstr);

	/* Probe status */
	tmpstr = devprobe_match(t, "PROBE RESULT");
	port_exists = 1;
	if (!tmpstr)
	    tmpstr = strdup("UNKNOWN");
	else if (!strcmp(tmpstr, "SUCCEED"))
	    tmpstr = devprobe_infotoasc( t );
	else if (!strcmp(tmpstr, "N/A")) {
	    tmpstr = strdup("<Port does not exist>");
	    port_exists = 0;
	}
	if (port_exists)
	    build_table_field(statstr, tmpstr, 22, 11, 1);
	else
	    build_table_field(statstr, tmpstr, 22, 25, 0);
	free(tmpstr);

	/* description/mfg/model info                              */
	/* if the port exists, see if we have anything to describe */
	/* what is attached                                        */
	/* First check  'MFG'/'MANUFACTURER'                       */
	/* Then add 'DESCRIPTION', or 'MODEL', then                */
	/* then finally add 'CLASS'                                */
	if (port_exists) {
	    char *descr;
	    char *model;
	    char *mfg;
	    char *class;
	    int  totlen=0;
	    
	    /* who made it */
	    mfg = devprobe_match(t, "MFG");
	    if (!mfg)
		mfg = devprobe_match(t, "MANUFACTURER");
	    if (mfg)
		totlen += strlen(mfg);

	    /* add on the description */
	    descr = devprobe_match(t, "DESCRIPTION");
	    if (descr)
		totlen += strlen(descr);

	    /* model # */
	    model = devprobe_match(t, "MODEL");
	    if (model)
		totlen += strlen(model);

	    /* PnP Class */
	    class = devprobe_match(t, "CLASS");
	    if (class)
		totlen += strlen(class);

	    /* make a string long enough for everything we could want */
	    tmpstr = malloc(totlen+5);
	    tmpstr[0]=0;

	    if (mfg) {
		strcat(tmpstr, mfg);
		strcat(tmpstr, "/");
	    }
	    if (descr) {
		strcat(tmpstr, descr);
		strcat(tmpstr, "/");
	    } else if (model) {
		strcat(tmpstr, model);
		strcat(tmpstr, "/");
	    }
	    if (class) {
		strcat(tmpstr, class);
		strcat(tmpstr, "/");
	    }
	    build_table_field(statstr, tmpstr, 36, 35, 0);
	    if (strlen(tmpstr) == 0)
		tmpstr = strdup("No info available for this port.");
	    
	    build_table_field(statstr, tmpstr, 36, 35, 0);
	    free(tmpstr);
	}
	
	/* now stick it in lostbox */
	statstr[70]=0;
	newtListboxAddEntry(devbox, statstr, (void *) i);
	statstr[69]='\n';
	strcatbuf(&summarybuf, statstr);
    }
    
/*    ok      = newtButton(14, 14, "Ok"); */
    help    = newtButton(13, 14, "Help");
    survey  = newtButton(25, 14, "Generate Report");
    quit    = newtButton(48, 14, "Quit");

    newtFormAddComponents(form, devbox, help, survey, quit, NULL);
    
    /* setup main screen */
    formdone = 0;
    answer = NULL;
    while (!formdone) {
	newtFormRun(form, &event);
	
	if (event.reason == NEWT_EXIT_COMPONENT) {
	    if (event.u.co != devbox) {
		if (event.u.co == quit)
		    formdone = 1;
		else if (event.u.co == survey) {
		    save_survey_to_file( num_devices, devices, summarybuf );
		}
		else if (event.u.co == help) {
		    display_help();
		}
	    } else {
		int sel=(long)newtListboxGetCurrent(devbox);
		show_device_details( devices[sel] );
	    }
	}
    }

    newtPopWindow();
    newtFormDestroy(form);
}

int main (int argc, char **argv) {
    char roottext[80];


    /* make sure we should even be running */
    if (getuid()) {
	fprintf(stderr,"\nERROR - You must be root to run hwdiag.\n");
	exit(1);
    }
    
    /* newt startup */
    newtInit();
    newtCls();
    newtPushHelpLine("  <Tab>/<Alt-Tab> between elements  |"
		     "  Use <Enter> to see details of selection" );

    snprintf(roottext, 80,
	      "HW Discovery Utility Version %s - (C) 1997 Red Hat Software",
	     version);
    newtDrawRootText(0, 0, roottext);
    
    /* Set up intro screen with info */
    if (intro_screen() < 0) {
	newtFinished();
	exit(1);
    }

    /* Goto master screen */
    start_master();
    
    newtFinished();
    exit(0);
}
