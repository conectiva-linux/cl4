#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <newt.h>
#include <popt.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>
#include <fcntl.h>
#include <libintl.h> 
#include <locale.h>
/* for strcasestr */
#define _GNU_SOURCE
#include <libgen.h>

#define _(String) gettext((String)) 
#define N_(String) String

#ifdef __sparc__
#include "Sun-probing/sunprobe.h"
#else
#include "pnp_probe_com.h"
#endif

#define MOUSEDEV "/dev/mouse"

static int kickstart=0;

static char * progName;

struct mouseTypes {
    char * name;
    char * shortName;
    short numButtons;
    char * gident; /* for GPM */
    char * xident; /* for XF86Config */
    char * device;
};


#define UNKNOWN_MOUSE 1000
/* 
 * The #ifdefs for mc68000 are removed.  We don't support the platform.
 * We'll add em back if we ever do. 
 */
struct mouseTypes mouseTypes[] = {
  { N_("No Mouse"), "none", 0, "none", "Microsoft", "none" },
#ifdef __sparc__
  { N_("PS/2"), "ps/2", 2, "ps/2", "PS/2", "psaux" },
  { N_("Sun"), "sun", 3, "sun", "sun", "sunmouse" },
#else
  { N_("ALPS GlidePoint (PS/2)"), "alpsps/2", 2, "ps/2",
    "GlidePointPS/2", "psaux" },
  { N_("ASCII MieMouse (serial)"), "ascii", 5, "ms3",
    "IntelliMouse", "ttyS" },
  { N_("ASCII MieMouse (PS/2)"), "asciips/2", 5, "ps/2",
    "NetMousePS/2", "psaux" },
  { N_("ATI Bus Mouse"), "atibm", 2, "Busmouse", "BusMouse", "atibm" },
  { N_("Generic Mouse (serial)"), "generic", 2, "Microsoft",
    "Microsoft", "ttyS" },
  { N_("Generic 3 Button Mouse (serial)"), "generic3", 3, "Microsoft",
    "Microsoft", "ttyS" },
  { N_("Generic Mouse (PS/2)"), "genericps/2", 2, "ps/2", "PS/2", "psaux" },
  { N_("Generic 3 Button Mouse (PS/2)"), "generic3ps/2", 3, "ps/2",
    "PS/2", "psaux" },
  { N_("Genius NetMouse (serial)"), "geniusnm", 5, "ms3",
    "IntelliMouse", "ttyS" },
  { N_("Genius NetMouse (PS/2)"), "geniusnmps/2", 5, "netmouse",
    "NetMousePS/2", "psaux" },
  { N_("Genius NetMouse Pro (PS/2)"), "geniusnmps/2", 5, "netmouse",
    "NetMousePS/2", "psaux" },
  { N_("Genius NetScroll (PS/2)"), "geniusnsps/2", 5, "netmouse",
    "NetScrollPS/2", "psaux" },
  { N_("Kensington Thinking Mouse (PS/2)"), "thinkingps/2", 5, "ps/2",
    "ThinkingMousePS/2", "psaux" },
  { N_("Logitech Mouse (serial, old C7 type)"), "logitech", 3, "Logitech",
    "Logitech", "ttyS" },
  { N_("Logitech CC Series (serial)"), "logitechcc", 3, "logim", 
    "MouseMan", "ttyS" },
  { N_("Logitech Bus Mouse"), "logibm", 3, "Busmouse", "BusMouse", "logibm" },
  { N_("Logitech MouseMan/FirstMouse (serial)"), "logimman", 3, "MouseMan",
    "MouseMan", "ttyS" },
  { N_("Logitech MouseMan/FirstMouse (ps/2)"), "logimmanps/2", 3, "ps/2",
    "PS/2", "psaux" },
  { N_("Logitech MouseMan+/FirstMouse+ (serial)"), "logimman+", 5, "pnp",
    "IntelliMouse", "ttyS" },
  { N_("Logitech MouseMan+/FirstMouse+ (PS/2)"), "logimman+ps/2", 5, "ps/2",
    "MouseManPlusPS/2", "psaux" },
  { N_("Microsoft compatible (serial)"), "microsoft", 2, "Microsoft",
    "Microsoft", "ttyS" },
  { N_("Microsoft Rev 2.1A or higher (serial)"), "msnew", 2, "pnp",
    "Auto", "ttyS" },
  { N_("Microsoft IntelliMouse (serial)"), "msintelli", 5, "ms3",
    "IntelliMouse", "ttyS" },
  { N_("Microsoft IntelliMouse (PS/2)"), "msintellips/2", 5, "imps2",
    "IMPS/2", "psaux" },
  { N_("Microsoft Bus Mouse"), "msbm", 2, "Busmouse", "BusMouse", "inportbm" },
  { N_("Mouse Systems (serial)"), "mousesystems", 2, "MouseSystems",
    "MouseSystems", "ttyS" },
  { N_("MM Series (serial)"), "mmseries", 2, "MMSeries", "MMSeries", "ttyS" },
  { N_("MM HitTablet (serial)"), "mmhittab", 2, "MMHitTab", "MMHittab", "ttyS" }
#endif
};
#define NUM_MICE (sizeof(mouseTypes) / sizeof(struct mouseTypes))

void usage(int errCode) {
    int i;

    fprintf(stderr,_("\nUsage: mouseconfig [--kickstart] [--device <dev>] "
	    "[--emulthree] [--noprobe] [<mousetype>]\n\n"));
    fprintf(stderr,_("       --noprobe        No automatic probing will be done\n"));
    fprintf(stderr,_("       --device <dev>   Specify port mouse is on\n"));
    fprintf(stderr,_("            <dev> is typically ttyS[0-3], \n"
	    "                  or psaux for PS/2 mice on a PS/2 port\n\n"));
    fprintf(stderr,_("       <mousetype> is one of:\n"));
    for (i=0; i < NUM_MICE; i++)
	fprintf(stderr,"                             %s\n",mouseTypes[i].shortName);
    fprintf(stderr,_("\n       If <mousetype> is not given then user will "
	    "be interactively queried.\n"));

    exit(errCode);
}    


void winStatus(int width, int height, char * title,
                char * text, ...) {
    newtComponent t, f;
    char * buf = NULL;
    int size = 0;
    int i = 0;
    va_list args;

    va_start(args, text);

    do {
        size += 1000;
        if (buf) free(buf);
        buf = malloc(size);
        i = vsnprintf(buf, size, text, args);
    } while (i == size);

    va_end(args);

    newtOpenWindow(40 - (width / 2), 11 - (height / 2), width, height, title);

    t = newtTextbox(1, 1, width - 2, height - 2, NEWT_TEXTBOX_WRAP);
    newtTextboxSetText(t, buf);
    f = newtForm(NULL, NULL, 0);

    free(buf);

    newtFormAddComponent(f, t);

    newtDrawForm(f);
    newtRefresh();
    newtFormDestroy(f);
}



static int readConfigFile(int * mouse, int * emu) {
    FILE * f;
    char * start, * end;
    char buf[250];
    int line = 0;
    int i;
    char link[1024];
    char * linkStart;

    *mouse = UNKNOWN_MOUSE;
    *emu = 0;

    f = fopen("/etc/sysconfig/mouse", "r");
    if (!f) {
	if (errno == ENOENT) return 0;

	fprintf(stderr, _("%s: cannot open /etc/sysconfig/mouse: %s\n"),
		progName, strerror(errno));
	return 1;
    }

    while (errno = 0, fgets(buf, sizeof(buf) - 1, f)) {
	line++;

	start = buf;

	/* skipping leading spaces */
	while (*start && isspace(*start)) start++;
	if (!*start) continue;

	/* skip comments */
	if (*start == '#') continue;

	/* cut off trailing spaces and \n */
	end = start + strlen(start) - 2;
	while (isspace(*end)) end--;
	end++;
	*end = '\0';	
	end--;
	
	if (!strncmp("MOUSETYPE=", start, 10)) {
	    start += 10;
	    if (*start == '"' && *end != '"') {
		fprintf(stderr, _("%s: mismatched quotes on line %d in "
			"/etc/sysconfig/mouse\n"), progName, line);
		fclose(f);
		return 1;
	    } else if (*start == '"') {
		start++;
		*end = '\0';
		end--;
	    }

	    if (!strcasecmp(start, "Busmouse")) {
		i = readlink(MOUSEDEV, link, sizeof(link) - 1);
		if (i > 0) {		/* if this fails, fuck it */
		    link[i] = '\0';
		    if ((linkStart = strrchr(link, '/')))
			linkStart += 1;
		    else
			linkStart = link;
		    
		    for (i = 0; i < NUM_MICE; i++) 
			if (!strcasecmp(mouseTypes[i].device, linkStart)) 
			    break;
		} else {
		    i = NUM_MICE;
		}
	    } else {
	      if (strstr(start,"ps/2")) {
		for (i = 0; i < NUM_MICE; i++) 
		  if (!strcasecmp(mouseTypes[i].shortName, "genericps/2"))
		    break;
	      } else {
		for (i = 0; i < NUM_MICE; i++)
		  if (!strcasecmp(mouseTypes[i].shortName, "generic"))
		    break;
	      }
		
	    }
	    if (i < NUM_MICE) *mouse = i;

	} else if (!strncmp("XMOUSETYPE=", start, 11)) {
	    start += 11;
	    if (*start == '"' && *end != '"') {
		fprintf(stderr, _("%s: mismatched quotes on line %d in "
			"/etc/sysconfig/mouse\n"), progName, line);
		fclose(f);
		return 1;
	    } else if (*start == '"') {
		start++;
		*end = '\0';
		end--;
	    }

	    if (!strcasecmp(start, "Busmouse")) {
		i = readlink(MOUSEDEV, link, sizeof(link) - 1);
		if (i > 0) {		/* if this fails, fuck it */
		    link[i] = '\0';
		    if ((linkStart = strrchr(link, '/')))
			linkStart += 1;
		    else
			linkStart = link;
		    
		    for (i = 0; i < NUM_MICE; i++) 
			if (!strcasecmp(mouseTypes[i].device, linkStart)) 
			    break;
		} else {
		    i = NUM_MICE;
		}
	    } else {
		for (i = 0; i < NUM_MICE; i++) 
		    if (!strcasecmp(mouseTypes[i].xident, start))
			break;
	    }
	    if (i < NUM_MICE) *mouse = i;
	} else if (!strncmp("FULLNAME=", start, 9)) {
	    start += 9;
	    if (*start == '"' && *end != '"') {
		fprintf(stderr, _("%s: mismatched quotes on line %d in "
			"/etc/sysconfig/mouse\n"), progName, line);
		fclose(f);
		return 1;
	    } else if (*start == '"') {
		start++;
		*end = '\0';
		end--;
	    }

	    for (i = 0; i < NUM_MICE; i++) 
	      if (!strcasecmp(mouseTypes[i].name, start))
		break;
	    if (i < NUM_MICE) *mouse = i;
	} else if (!strncmp("XEMU3=", start, 6)) {
	    start += 6;
	    if (*start == '"' && *end != '"') {
		fprintf(stderr, _("%s: mismatched quotes on line %d in "
			"/etc/sysconfig/mouse\n"), progName, line);
		fclose(f);
		return 1;
	    } else if (*start == '"') {
		start++;
		*end = '\0';
		end--;
	    }

	    if (!strcasecmp(start, "yes") || !strcasecmp(start, "true"))
		*emu = 1;
	    else
		*emu = 0;
	} else {
	    fprintf(stderr, 
		    _("%s: line %d unexpected in /etc/sysconfig/mouse\n"),
		    progName, line);
	    fclose(f);
	    return 1;
	}
    }
    if (errno) {
	fprintf(stderr, _("%s: cannot read /etc/sysconfig/mouse: %s\n"),
		progName, strerror(errno));
    }

    return 0;
}

#if !defined(__mc68000__) && !defined(__sparc__)
/* search for the first mouse in the system - */
/* starts with PS/2 port, then ttyS?          */
/* type is not well defined except for ps/2   */
/* if type is NULL but port is NOT NULL, you  */
/* better ask user what mouse type is on that */
/* port.  Type uses the mouseTypes.shortName[]         */
int find_first_mouse(int *type, char **port) {
    int fd;
    int found;
    int good_probe;
    struct devprobe *t=NULL;
    char **try;
    char *ports[]={"/dev/ttyS0", "/dev/ttyS1", "/dev/ttyS2", "/dev/ttyS3", NULL};
    char buf[256];
    int i, len;
    
    found = 0;
    fd=open("/dev/psaux", O_RDONLY|O_NONBLOCK);
    if (fd >= 0) {
      /* The following line is a 2.2.x kernel workaround */
      if (!((len = read(fd, buf, sizeof(buf)) == 1) && buf[0] == -2)) {
        close(fd);
	for (i = 0; i < NUM_MICE; i++)
	    if (!strcasecmp(mouseTypes[i].shortName, "genericps/2"))
		break;
	*type = i;
	return 0;
      }
    }

    
    /* see if we can probe a mouse on one of the com ports */
    try = ports;
    found = 0;
    good_probe = 0;
    i = 1;
    while (*try && !found) {
      char *class, *mfg, *model;
      
      if (!pnp_probe_com( &t, *try )) {
	/* is it a mouse? */
	class = devprobe_match(t, "CLASS");
	if (class) {
	  if (!strcmp(class,"MOUSE")) {
	    /* found a plug 'n' play mouse
	     * set found now, because we might not know what it is. */
	    found = 1;
	    free(class);
	    
	    /* who made it */
	    mfg = devprobe_match(t, "MFG");
	    if (!mfg)
	      mfg = devprobe_match(t, "MANUFACTURER");
	    
	    if (mfg) {
	      model = devprobe_match(t, "MODEL");
	      if (model) {
		if (!strcmp(mfg,"MSH") && !strcmp(model,"0001")) {
		  for (i = 0; i < NUM_MICE; i++)
		    if (!strcasecmp(mouseTypes[i].shortName, "msintelli"))
		      break;
		  good_probe = 1;
		} /* microsoft intellimouse */
		if (!strcmp(mfg,"LGI") && (!strncmp(model,"80",2))) {
		  for (i = 0; i < NUM_MICE; i++)
		    if (!strcasecmp(mouseTypes[i].shortName, "logimman"))
		      break;
		  good_probe = 1;
		} /* logitech three button */
		if (!strcmp(mfg,"KYE") && !strcmp(model,"0003")) {
		  for (i = 0; i < NUM_MICE; i++)
		    if (!strcasecmp(mouseTypes[i].shortName, "geniusnm"))
		      break;
		  good_probe = 1;
		} /* Genius / KYE NetMouse */
		free(model);
		free(mfg);
	      }
	    }
	  }
	}
      } else {
	devprobe_destroy(t);
      }
      
      if (!found)
	try++;
    }
    
    if (found) {
      if (!good_probe)
	for (i = 0; i < NUM_MICE; i++)
	  if (!strcasecmp(mouseTypes[i].shortName, "generic"))
	    break;
      *type = i;
      *port = (*try) + 5;
      if (good_probe)
	return 1;
      else
	return 0;
    } else {
      *type = UNKNOWN_MOUSE;
      return -1;
    }
}
#endif

int writeXcfg(int mouse, char * device, int emu3) {
    FILE *in, *out;
    char buf[250];
    char *start;
    int inPointer = 0;
    
    in = fopen("/etc/X11/XF86Config", "r");
    if (!in) {
	newtWinMessage(_("Error"), _("Ok"),
		       _("There was an error reading your current "
			 "/etc/X11/XF86Config file"));
	return -1;
    }

    out = fopen("/etc/X11/XF86Config-", "w");
    if (!out) {
	newtWinMessage(_("Error"), _("Ok"),
		       _("There was an error writing your new "
			 "/etc/X11/XF86Config file"));
	return -1;
    }

    while ((fgets(buf, sizeof(buf) - 1, in)) != NULL) {
	/* we only really care if we're in the Pointer section of XF86Config */
	if (strcasestr(buf, "Pointer")) 
	    inPointer = 1;
	/* once in the pointer section, look for the protocol - and the
	   protocol entry that isn't commented. */
	if (inPointer) {
	    if (strcasestr(buf, "Protocol") && !strchr(buf, '#')) {
		/* replace it with the new one and continue */
		fprintf(out, "    Protocol    \"%s\"\n",
			mouseTypes[mouse].xident);
		continue;
	    }
	    /* now these are more tricky - there are more than one line with
	       the "Emulate3Buttons" and "Emulate3Timeout" keywords - they
	       are in the documentation.  We will look for these words
	       in the beginning of lines, after white space */
	    start = buf;
	    while (*start && *start == ' ')
		start++;
	    if (!strncasecmp(start, "Emulate3Buttons", 15) && !emu3) {
		fprintf(out, "#    Emulate3Buttons\n");
		continue;
	    }
	    if (!strncasecmp(start, "Emulate3Timeout", 15) && !emu3) {
		fprintf(out, "#    Emulate3Timeout    50\n");
		continue;
	    }

	    /* now, we've covered the case where the keywords were uncommented
	       and they need to be commented.  We now need to handle the case
	       where they were commented and need to be uncommented. */
	    /* This is sort of a hack because there are two lines in the
	       XF86Config file that are documentation regarding Emulate3Buttons
	       and Emulate3Timeout.  They're long, so I'll toss them out here.
	    */
	    /* commented line */
	    if ((strlen(start) < 30 && *start == '#')) {
		while (*start && *start == '#')
		    start++;
	    
		while (*start && *start == ' ')
		    start++;

		if (!strncasecmp(start, "Emulate3Buttons", 15) && emu3) {
		    fprintf(out, "    Emulate3Buttons\n");
		    continue;
		}
		if (!strncasecmp(start, "Emulate3Timeout", 15) && emu3) {
		    fprintf(out, "    Emulate3Timeout    50\n");
		    continue;
		}
	    }
	    if (strcasestr(buf, "EndSection"))
		inPointer = 0;
	}
	fprintf(out, buf);
    }
    fclose(in);
    fclose(out);

    unlink("/etc/X11/XF86Config");
    rename("/etc/X11/XF86Config-", "/etc/X11/XF86Config");

    return 0;
}

int writecfg(int mouse, char * device, int emu3) {
    FILE *f;

#ifdef __sparc__
    if (mouse == SUN_SUNMOUSE)
	emu3 = 0;
#endif
    
    f = fopen("/etc/sysconfig/mouse", "w");
    if (!f) {
	fprintf(stderr, _("%s: failed to make /etc/sysconfig/mouse: %s"), 
		progName, strerror(errno));
	exit(2);
    }
    
    fprintf(f, "MOUSETYPE=\"%s\"\n", mouseTypes[mouse].gident);
    fprintf(f, "XMOUSETYPE=\"%s\"\n", mouseTypes[mouse].xident);
    fprintf(f, "FULLNAME=\"%s\"\n", mouseTypes[mouse].name);
    fprintf(f, "XEMU3=%s\n", emu3 ? "yes" : "no");
    
    /* link mouse device */
    unlink(MOUSEDEV);
    if (strncmp(device, "none", 4))
	symlink(device, MOUSEDEV);
    
    return 0;
}

/* this ONLY gets run in kickstart                       */
int kickstart_mode(int mouse, char * device, int noprobe, int emulate3) {
    int probedMouse;
    char * probedDevice;
    int status;

    status = -1;
/* see if we need to autoprobe when they gave us no info */
    if (!mouse || !device) {
#ifndef __mc68000__
	if (!noprobe) {
	    status = find_first_mouse(&probedMouse, &probedDevice);
	    if (status < 0)
		return 2;
	}

	if (!mouse) {
	  if (status >= 0)
	    mouse = probedMouse;
	  else
#ifdef __sparc__
	    mouse = SUN_SUNMOUSE; /* sunmouse */
#else	  
	    mouse = 4; /* generic 2 button serial */
#endif	    
	}

	if (!device) {
	    if (strcmp(mouseTypes[mouse].device, "ttyS"))
		device = mouseTypes[mouse].device;
	    else if (probedDevice)
		device = probedDevice;
	}
#endif

	if (!mouse)
	    mouse = 1;
	if (!device)
	    device = "ttyS0";
    }

    return writecfg(mouse, device, emulate3);
}

int mouseTypeWindow(int backButton, int * mouseType, int * emul3Val) {
    int i;
    newtGrid grid, subgrid, buttons;
    newtComponent listbox, checkbox, okay, cancel, help, form, label, answer;
    char emul3;
    int mouse = *mouseType;

    if (mouse == UNKNOWN_MOUSE)
#ifdef __sparc__
	mouse = SUN_SUNMOUSE;
#else
	mouse = 1;
#endif

    listbox = newtListbox(-1, -1, 8, NEWT_FLAG_SCROLL | NEWT_FLAG_RETURNEXIT);
    for (i = 0; i < NUM_MICE; i++)
	newtListboxAddEntry(listbox, _(mouseTypes[i].name), (void **) i);
    newtListboxSetCurrent(listbox, mouse);
    
    checkbox = newtCheckbox(-1, -1, _("Emulate 3 Buttons?"), 
			    (*emul3Val) ? '*' : ' ', NULL, &emul3);

    buttons = newtButtonBar(_("Ok"), &okay, 
			    backButton ? _("Back") : _("Cancel"),
			    &cancel, 
			    _("Help"), &help, NULL);

    label = newtLabel(-1, -1, _("What type of mouse do you have?"));
    subgrid = newtGridVStacked(NEWT_GRID_COMPONENT, listbox,
			       NEWT_GRID_COMPONENT, checkbox, NULL);
    grid = newtGridBasicWindow(label, subgrid, buttons);
    form = newtForm(NULL, NULL, 0);
    newtGridWrappedWindow(grid, _("Configure Mouse"));
    newtGridAddComponentsToForm(grid, form, 1);
    newtGridFree(grid, 1);

    newtFormSetCurrent(form, listbox);

    while ((answer = newtRunForm(form)) != okay && (answer != NULL)) {
      if (answer == cancel) {
	newtPopWindow();
	newtFormDestroy(form);
	return 1;
	
      }
      if (answer == help) {
	newtWinMessage(_("Mouse Config Help"), _("Ok"),
		       _("Choose your mouse from one of those listed.  If you see your\n"
		       "mouse in the list, or know your mouse is compatible with one\n"
		       "of those listed, choose that entry.  Pay attention to the\n"
		       "interface your mouse has; serial connectors are flat, PS/2\n"
		       "connectors round. If you are not sure what type of mouse you\n"
		       "have, or your mouse is not listed, choose the closest matching\n"
		       "\"Generic\" entry with the same interface and number of buttons."));
      } else {
	/* must have pressed F12 */
	break;
      }
    }

    *mouseType = (int) newtListboxGetCurrent(listbox);
    *emul3Val = (emul3 != ' ');

    newtPopWindow();
    newtFormDestroy(form);

    return 0;
}

static char * serialPorts[] = {
	N_("/dev/ttyS0 (COM1 under DOS)"),
	N_("/dev/ttyS1 (COM2 under DOS)"),
	N_("/dev/ttyS2 (COM3 under DOS)"),
	N_("/dev/ttyS3 (COM4 under DOS)"),
	NULL
};

int pickSerialPort(char ** device) {
    int rc;
    static char name[10];
    int num;

    for (num = 0; serialPorts[num]; num++)
	serialPorts[num] = _(serialPorts[num]);

    if (*device)
	num = (*device)[3] - '0';
    else
	num = 0;

    rc = newtWinMenu(_("Mouse Port"),
		     _("Which serial port is your mouse connected to?"),
		      40, 0, 20, 6, serialPorts, &num, 
		      _("Ok"), _("Back"), NULL);
    if (rc == 2) return 1;

    sprintf(name, "ttyS%d", num);
    *device = name;

    return 0;
}

int main(int argc, char ** argv) {
    int i;
    int status = 0;
    int mouse = 0;
    char * device = NULL;
    char * probedDevice = NULL;
    char * mouseName;
    poptContext optCon;
    int rc;
    int expert = 0;
    int noprobe = 0, noconfig = 0;
    int emulate3 = 0;
    int emul3Option = 0;
    int help=0;
    int test=0;
    int useBack = 0;
    struct poptOption options[] = {
	{ "back", '\0', 0, &useBack, 0 },
	{ "device", '\0', POPT_ARG_STRING, &device, 0 },
	{ "emulthree", '\0', 0, &emul3Option, 0 },
	{ "expert", '\0', 0, &expert, 0},
	{ "help", '\0', POPT_ARG_NONE, &help, 0},
	{ "kickstart", '\0', POPT_ARG_NONE, &kickstart, 0},
	{ "noconfig", '\0', 0 , &noconfig, 0},
	{ "noprobe", '\0', 0 , &noprobe, 0},
	{ "test", '\0', 0 , &test, 0},
	{ 0, 0, 0, 0, 0 }
    };

    progName = argv[0];
    setlocale(LC_ALL, ""); 
    bindtextdomain("mouseconfig","/usr/share/locale"); 
    textdomain("mouseconfig"); 

    optCon = poptGetContext("mouseconfig", argc, argv, options, 0);
    poptReadDefaultConfig(optCon, 1);

    if ((rc = poptGetNextOpt(optCon)) < -1) {
	fprintf(stderr, _("%s: bad argument %s: %s\n"), progName,
		poptBadOption(optCon, POPT_BADOPTION_NOALIAS), 
		poptStrerror(rc));
	return 2;
    }

    mouseName = poptGetArg(optCon);
    if (mouseName && poptGetArg(optCon)) {
	fprintf(stderr, _("%s: only one argument (the mouse type) may be used\n"), 
		progName);
	return 2;
    } else if (mouseName) {
	for (i = 0; i < NUM_MICE; i++) 
	    if (!strcmp(mouseTypes[i].shortName, mouseName))
		break;
	if (i == NUM_MICE) usage(2);
	mouse = i;
    }

    poptFreeContext(optCon);

    if (help) usage(0);

    /* see if we are in kickstart mode */
    if (kickstart) {
	return kickstart_mode(mouse, device, noprobe, emul3Option);
    }

    /* ok, we're in interactive mode */
    if (!test && getuid()) {
	fprintf(stderr, _("%s: can only be run as root\n"), progName);
	exit(2);
    }

    /* we still dont know what type of mouse, better ask the user */
    newtInit();
    newtCls();
    newtPushHelpLine(_("  <Tab>/<Alt-Tab> between elements   |  <Space> selects   |  <F12> next screen "));
    newtDrawRootText(0, 0, "mouseconfig " VERSION " - (C) "
		     "1999 Red Hat Software");

    /* We listen to command line, then /etc/sysconfig/mouse, then 
       probing */

    if (!mouse && !noconfig) {
	if (readConfigFile(&mouse, &emulate3)) {
	  status = newtWinChoice(_("Error on Read"), _("Ok"), _("Cancel"), 
				 _("There was an error "
				   "reading the file /etc/sysconfig/mouse.\n\n"
				   "Would you like to proceed in creating "
				   "a new configuration?"));
	  if (status == 2) {
	    newtFinished();
	    exit(2);
	  }
	} else {
	  /* When they run us after the initial install, mouse will be
	   * set from reading the config file.  Always ask questions. */
	  if (mouse != UNKNOWN_MOUSE)
	    expert = 1;
	}
    }

#ifndef __mc68000__
    /* probe to see if we can determine mouse type and port */
    if ((mouse == UNKNOWN_MOUSE || !mouse) && !noprobe) {
	winStatus(35, 3, _("Mouse"), _("Probing for mouse type..."));
	status = find_first_mouse(&mouse, &probedDevice);
	newtPopWindow();
	if (status == 0) {
	    newtWinMessage(_("Probing Result"), _("Ok"),
			   _("Probing found some type of %s mouse on port %s."),
			   strstr(mouseTypes[mouse].shortName, "ps/2")
#ifdef __sparc__
			   ? "PS/2": "sun",
#else
			   ? "PS/2": "serial",
#endif
			   probedDevice ? probedDevice : "psaux");
	} else if (status > 0) {
	  newtWinMessage(_("Probing Result"), _("Ok"),
			 _("Probing found a %s mouse on port %s."),
			 mouseTypes[mouse].name,
			 probedDevice ? probedDevice : "psaux");
	} else {
	  newtWinMessage(_("Probing Failed"), _("Ok"),
			 _("Unable to probe mouse type.\n"
			 "You must manually choose a mouse."));
	}
    }
#endif

    /* status is <= 0 if a mouse was found, but not through PNP, and 1
     * if a mouse was found with PNP
     */
    if (expert || (status <= 0))
	if (mouseTypeWindow(useBack, &mouse, &emulate3)) {
	  newtFinished();
	  exit(1);
	}

    // if they forgot to check emulate 3 buttons but we know that
    // they have a two button mouse, set it for them.  If they have a
    // 3 button mouse but choose emulate 3 anyway, let them.  Who knows?
    if (!emulate3 && mouseTypes[mouse].numButtons < 3)
      emulate3 = 1;

    /* do we know what device the mouse is on? */
    /* Now we need to figure out what device this mouse is on. */
    if (!strcmp(mouseTypes[mouse].device, "ttyS") && !device) {
	if (probedDevice) {
	    device = probedDevice;
	}

	if (expert || !device) {
	    if (pickSerialPort(&device)) {
		newtFinished();
		exit(1);
	    }
	}
    } else {
	device = mouseTypes[mouse].device;
    }

    /* emulate three buttons? */
    /* we ask cause in normal mode user wouldnt have been asked */
    /* this question above in the mouse type dialog */
    if ((mouseTypes[mouse].numButtons < 3) && !expert && !emulate3) {
	if (newtWinChoice(_("Emulate Three Buttons"), _("Yes"), _("No"),
			  _("X Windows generally works best with a three "
			    "button mouse.  If your mouse only has two "
			    "buttons you can emulate the third by pressing "
			    "both buttons at the same time.\n\n"
			    "Would you like to enable this emulation?\n\n"
			    "(This option is only needed if you have a 2 "
			    "button mouse)")) == 1) {
	    emulate3 = 1;
	} else {
	    emulate3 = 0;
	}
    }

    if (!useBack && !access("/etc/X11/XF86Config", W_OK)) {
	if (newtWinChoice(_("Update X Configuration"), _("Yes"), _("No"),
			  _("Mouseconfig can now update your XFree86 "
			    "configuration file to reflect your new mouse "
			    "settings. Would you like mouseconfig to make "
			    "these changes now?")) == 1)
	    writeXcfg(mouse, device, emulate3);
    }

    
    newtFinished();

    if (test)
	return 0;

    return writecfg(mouse, device, emulate3);
}
