// Implementation file for the -*- C++ -*- math functions header.
// This file is part of the GNU ANSI C++ Library.

#ifdef __GNUG__
#pragma implementation "std/cmath.h"
#endif
#include <std/cmath.h>
