// Implementation file for the -*- C++ -*- dynamic memory management header.
// This file is part of the GNU ANSI C++ Library.

#ifdef __GNUG__
#pragma implementation "std/new.h"
#endif
#include <std/new.h>
