// Implementation file for Exception Support for -*- C++ -*-
// This file is part of the GNU ANSI C++ Library.

#ifdef __GNUG__
#pragma implementation "std/stdexcept.h"
#endif

#include <stdexcept>
