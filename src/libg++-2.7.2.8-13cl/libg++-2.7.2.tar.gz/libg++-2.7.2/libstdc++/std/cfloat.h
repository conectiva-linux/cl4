// The -*- C++ -*- floating point header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CFLOAT__
#define __CFLOAT__
#include <float.h>
#endif
