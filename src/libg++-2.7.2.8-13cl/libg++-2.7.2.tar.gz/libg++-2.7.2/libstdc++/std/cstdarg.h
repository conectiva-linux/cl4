// The -*- C++ -*- variable argument handling header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CSTDARG__
#define __CSTDARG__
#include <stdarg.h>
#endif
