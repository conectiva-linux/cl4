// The -*- C++ -*- signal handling header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CSIGNAL__
#define __CSIGNAL__
#include <signal.h>
#endif
