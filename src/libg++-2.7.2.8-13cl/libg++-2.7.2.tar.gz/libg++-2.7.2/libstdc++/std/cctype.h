// The -*- C++ -*- character type header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CCTYPE__
#define __CCTYPE__
#include <ctype.h>
#endif
