// Implementation file for the -*- C++ -*- standard definitions header.
// This file is part of the GNU ANSI C++ Library.

#ifdef __GNUG__
#pragma implementation "std/stddef.h"
#endif
#include <std/stddef.h>
