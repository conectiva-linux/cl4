// Implementation file for the -*- C++ -*- null-terminated string header.
// This file is part of the GNU ANSI C++ Library.

#ifdef __GNUG__
#pragma implementation "std/cstring.h"
#endif
#include <std/cstring.h>
