// -*- C++ -*-
struct point
{
  double x, y;			// x and y coordinates
  char *label;			// label attched to coordinates.
  int symbol;			// index of symbol drawn at corrdinates.
};

#define DEFAULT_INITIAL_CAPACITY 1024
