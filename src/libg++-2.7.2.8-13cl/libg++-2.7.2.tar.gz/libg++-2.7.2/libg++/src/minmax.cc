#ifdef _GNUG_
#pragma implementation
#endif

#include <minmax.h>
