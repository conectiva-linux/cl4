/*
 * header.h	Header file with global variables and functions
 *		for the tacp2rad daemon.
 *
 * Version:	@(#)header.h  1.00  04-Sep-1996  miquels@cistron.nl
 *
 */

#define CONFFILE	"/etc/tacp2rad.conf"
#define MAPFILE		"/etc/tacp2rad.map"
#define PIDFILE		"/var/run/tacp2radd.pid"

/*
 *	Global variables.
 */
extern struct radius radius_conf;

/*
 *	Function prototypes.
 */
int buffer_server(void);
int buffer_ask(struct auth *ai, char *recvbuf, int bufsz);
int buffer_send(struct auth *ai, char *recvbuf, int bufsz);

int tac_map(unsigned int nas_addr, char *tacport);
void DEBUG(char *fmt, ...);
void nsyslog(int lvl, char *fmt, ...);

#ifndef MAX
#define MAX(a, b)     ((a) > (b) ? (a) : (b))
#endif
#ifndef MIN
#define MIN(a, b)     ((a) < (b) ? (a) : (b))
#endif

