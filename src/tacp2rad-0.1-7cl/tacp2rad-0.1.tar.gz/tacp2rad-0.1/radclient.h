/*
 * radclient.h	Header file for the authentication stuff.
 *
 * Version:	@(#)radclient.h  1.10  29-Aug-1996  miquels@cistron.nl
 *
 */

/*
 *	Some definitions.
 */
#define RAD_ID_FILE		"/var/run/radius.id"
#define RAD_SESSIONID_FILE	"/var/log/radsession.id"

/*
 *	Types of connection.
 */
#define P_UNKNOWN	0
#define P_LOCAL		'L'
#define P_RLOGIN	'R'
#define P_SLIP		'S'
#define P_CSLIP		'C'
#define P_PPP		'P'
#define P_AUTOPPP	'A'
#define P_TELNET	'E'
#define P_TCPCLEAR      'T'
#define P_TCPLOGIN      'U'
#define P_CONSOLE	'!'
#define P_SHELL		'X'


/*
 *	This is an "attribute".
 */
typedef struct _attr_ {
	unsigned char type;
	unsigned char len;
	union {
		char str[254];
		unsigned int num;
	} val;
	unsigned char pwtype;
	struct _attr_ *next;
} ATTR;

/*
 *	This is a complete request or reply.
 */
typedef struct {
	unsigned char code;
	unsigned char id;
	unsigned char vector[AUTH_VECTOR_LEN];
	time_t timestamp;
	time_t lastsent;
	ATTR *list;
} RADPKT;


/*
 *	Authentication info. This is what we send to the RADIUS server
 *	for an authentication request.
 */
struct auth {
  char login[32];
  char passwd[32];
  unsigned int nas_ip;
  int nas_port;
  int ppphint;
};

/*
 *	Accounting info. This is what we send to the RADIUS server
 *	for an accounting request.
 */
struct acct {
  char login[32];
  unsigned int nas_ip;
  int nas_port;
  int islogin;
  char acctsessionid[32];
  int elapsed;
  int proto;
  unsigned int address;
};

/*
 *	Generic info for the RADIUS client code.
 */
struct radius {
  char secret[32];
  unsigned int authhost1;
  unsigned int authhost2;
  unsigned int accthost1;
  unsigned int accthost2;
};

/*
 *	Exported functions; the "API"..
 */
void rad_attrfree(ATTR *l);
unsigned int rad_sessionid(char *s);
int rad_client(struct radius *rad, struct auth *ai, char *recvbuf, int bufsz);
RADPKT *rad_decode(char *recvbuf, int bufsz);
int rad_acct(struct radius *rad, struct acct *ai);
void rad_pktfree(RADPKT *r);
ATTR *rad_attrfind(RADPKT *r, int attr);
