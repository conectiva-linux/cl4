/*
 * radbuffer.c	This part of the program listens on a socket
 *		for connects. Another process can either send
 *		auth. info, or ask for it by name/NAS/port.
 *		The info is buffered up to 10 seconds.
 *
 *		Note that this thing does not do auth. requests
 *		by itself. It's just a buffer.
 *
 * Version:	@(#)radbuffer.c  1.00  30-Aug-1996  MvS.
 *
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <syslog.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <signal.h>

#include "radius.h"
#include "radclient.h"

#include "header.h"

#define PATH_BUFSOCK "/var/run/tacp2rad.sok"


/*
 *	Structure of our in-memory buffer list.
 */
struct buflist {
  time_t tm;
  char login[32];
  int nas_ip;
  int nas_port;
  char *recvbuf;
  int bufsz;
  struct buflist *next;
};
static struct buflist *buflist;

/*
 *	Block or unblock the ALRM signal.
 */
static void blockalrm(int how)
{
  sigset_t s;

  sigemptyset(&s);
  sigaddset(&s, SIGALRM);
  sigprocmask(how ? SIG_BLOCK : SIG_UNBLOCK, &s, NULL);
}

/*
 *	This is called every second; it expires a buffer
 *	after 10 seconds (we could also do this just _before_
 *	every request, I think).
 */
/*ARGSUSED*/
static void buffer_expire(int sig)
{
  struct buflist *b, *last, *next;
  time_t tm;

  alarm(1);

  tm = time(NULL) - 10;

  last = NULL;
  for(b = buflist; b; b = next) {
	next = b->next;
	if (b->tm < tm) {
		DEBUG("buffer_expire: expiring %s\n", b->login);
		if (last)
			last->next = b->next;
		else
			buflist = b->next;
		free(b->recvbuf);
		free(b);
		continue;
	}
	last = b;
  }
}

/*
 *	Find a buffer in our linked list.
 *	Also update timestamp if found.
 */
static struct buflist *buffer_find(struct auth *ai)
{
  struct buflist *b;

  blockalrm(1);

  DEBUG("buffer_find: looking for %s..\n", ai->login);

  for(b = buflist; b; b = b->next) {
	DEBUG("buffer_find: checking %s.\n", b->login);
	if (strcmp(b->login, ai->login) == 0 &&
	    b->nas_ip == ai->nas_ip && b->nas_port == ai->nas_port)
		break;
  }
  if (b) b->tm = time(NULL);

  DEBUG("buffer_find: %s match.\n", b ? "" : "No ");

  blockalrm(0);

  return b;
}


/*
 *	Add a buffer to the linked list.
 */
static void buffer_add(struct auth *ai, char *recvbuf, int bufsz)
{
  struct buflist *b, *i, *last;

  DEBUG("buffer_add: adding entry for %s\n", ai->login);

  /*
   *	Allocate and fill a struct buflist.
   */
  if ((b = malloc(sizeof(struct buflist))) == NULL) {
	nsyslog(LOG_ERR, "buffer_add: out of memory");
	return;
  }
  strcpy(b->login, ai->login);
  b->nas_ip = ai->nas_ip;
  b->nas_port = ai->nas_port;
  if ((b->recvbuf = malloc(bufsz)) == NULL) {
	nsyslog(LOG_ERR, "buffer_add: out of memory");
	free(b);
	return;
  }
  memcpy(b->recvbuf, recvbuf, bufsz);
  b->bufsz = bufsz;

  blockalrm(1);

  /*
   *	Check if there is already a similar entry.
   */
  last = NULL;
  for(i = buflist; i; i = i->next) {
	if (strcmp(i->login, ai->login) == 0 &&
	    i->nas_ip == ai->nas_ip && i->nas_port == ai->nas_port)
		break;
	last = i;
  }
  if (i) {
	/*
	 *	Yeah, so delete the old entry.
	 */
	if (last)
		last->next = b->next;
	else
		buflist = b->next;
	free(i->recvbuf);
	free(i);
  }

  /*
   *	Now insert the new entry at the head of the list.
   */
  b->next = buflist;
  buflist = b;
  b->tm = time(NULL);

  blockalrm(0);
}


/*
 *	Handle one connection: a read or a write.
 */
static void handle_conn(int s)
{
  struct auth ai;
  char c;
  int n;
  char recvbuf[1024];
  int cnt;
  struct buflist *b;

  /*
   *	Receive/Send request ??
   */
  while ((n = read(s, &c, 1)) != 1) {
	if (n < 0 && errno == EINTR) continue;
	nsyslog(LOG_ERR, "handle_conn: expected 1 char, got %d", n);
	return;
  }

  if (c != 'S' && c != 'R') {
	nsyslog(LOG_ERR, "handle_conn: unknown action `%c'", c);
	return;
  }

  /*
   *	Read struct auth.
   */
  while((n = read(s, &ai, sizeof(ai))) != sizeof(ai)) {
	if (n < 0 && errno == EINTR) continue;
	nsyslog(LOG_ERR,"handle_conn: expected %d chars, got %d", sizeof(ai), n);
	return;
  }

  if (c == 'R') {
	/*
	 *	'R' means we have to receive data.
	 */
	cnt = 0;
	n = 0;
	while((n = read(s, recvbuf + cnt, sizeof(recvbuf) - cnt)) != 0) {
		if (n < 0) {
			if (n == EINTR) continue;
			nsyslog(LOG_ERR, "handle_conn: read: %m");
			return;
		}
		cnt += n;
		if (cnt > sizeof(recvbuf)) {
			nsyslog(LOG_ERR, "handle_conn: read: input overflow");
			return;
		}
	}
	/*
	 *	OK, got it. Now put it in our buffer.
	 */
	buffer_add(&ai, recvbuf, cnt);
	return;
  }

  if (c == 'S') {
	/*
	 *	'S' means we have to send data.
	 */
	if ((b = buffer_find(&ai)) != NULL) {
		cnt = 0;
		while((n = write(s, b->recvbuf + cnt, b->bufsz - cnt)) != 0){
			if (n < 0) {
				if (n == EINTR) continue;
				nsyslog(LOG_ERR, "handle_conn: write: %m");
				return;
			}
			cnt += n;
			if (cnt == b->bufsz) break;
		}
	}
	return;
  }
}

/*
 *	This is the buffer server. Just a tight accept() loop.
 */
int buffer_server(void)
{
  pid_t pid;
  int s, n;
  struct sockaddr_un un, from_un;
  size_t len;
  struct sigaction sa;

  if ((pid = fork()) < 0) {
	nsyslog(LOG_ERR, "buffer_server: fork: %m");
	return -1;
  }
  if (pid > 0) return (int)pid;

  signal(SIGHUP,  SIG_DFL);
  signal(SIGINT,  SIG_DFL);
  signal(SIGTERM, SIG_DFL);

  /*
   *	Set up the expire stuff.
   */
  memset(&sa, 0, sizeof(sa));
  sa.sa_handler = buffer_expire;
  sigaction(SIGALRM, &sa, 0);
  alarm(1);

  /*
   *	Listen to the UNIX socket.
   */
  while ((s = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
	if (errno == EINTR) continue;
	nsyslog(LOG_ERR, "buffer_server: socket: %m (ARGH!)");
	exit(1);
  }

  (void)unlink(PATH_BUFSOCK);
  un.sun_family = AF_UNIX;
  strcpy(un.sun_path, PATH_BUFSOCK);

  while (bind(s, (struct sockaddr *)&un, sizeof(un)) < 0) {
	if (errno == EINTR) continue;
	nsyslog(LOG_ERR, "buffer_server: bind: %m (ARGH!)");
	exit(1);
  }
  (void)listen(s, 5);

  while(1) {
	if ((n = accept(s, (struct sockaddr *)&from_un, &len)) < 0){
		if (errno != EINTR && errno != ECONNRESET) {
			nsyslog(LOG_ERR, "buffer_server: accept: %m (ARGH!)");
			exit(1);
		}
		continue;
	}
	handle_conn(n);
	close(n);
  }

  /*NOTREACHED*/
  return 0;
}

/*
 *	Ask the buffer server for some data.
 */
int buffer_ask(struct auth *ai, char *recvbuf, int bufsz)
{
  struct sockaddr_un un;
  char c;
  int s, n, cnt;

  /*
   *	Connect to the buffer server and ask for the info.
   */
  un.sun_family = AF_UNIX;
  strcpy(un.sun_path, PATH_BUFSOCK);

  if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
	nsyslog(LOG_ERR, "buffer_ask: socket: %m");
	return -1;
  }

  if (connect(s, (struct sockaddr *)&un, sizeof(un)) < 0) {
	nsyslog(LOG_ERR, "buffer_ask: connect: %m");
	return -1;
  }

  c = 'S';
  (void)write(s, &c, 1);
  (void)write(s, ai, sizeof(struct auth));

  /*
   *	Read the reply.
   */
  cnt = 0;
  while((n = read(s, recvbuf + cnt, bufsz - cnt)) != 0) {
	if (n < 0) {
		if (errno == EINTR)
			continue;
		else
			break;
	}
	cnt += n;
  }

  close(s);

  return cnt ? cnt : n;
}

/*
 *	Send some data to the buffer server.
 */
int buffer_send(struct auth *ai, char *recvbuf, int bufsz)
{
  struct sockaddr_un un;
  char c;
  int s, n, cnt;

  /*
   *	Connect to the buffer server and send the info.
   */
  un.sun_family = AF_UNIX;
  strcpy(un.sun_path, PATH_BUFSOCK);

  if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
	nsyslog(LOG_ERR, "buffer_ask: socket: %m");
	return -1;
  }

  if (connect(s, (struct sockaddr *)&un, sizeof(un)) < 0) {
	nsyslog(LOG_ERR, "buffer_ask: connect: %m");
	return -1;
  }

  c = 'R';
  (void)write(s, &c, 1);
  (void)write(s, ai, sizeof(struct auth));

  /*
   *	Send the data block.
   */
  cnt = 0;
  while((n = write(s, recvbuf + cnt, bufsz - cnt)) != 0) {
	if (n < 0) {
		if (errno == EINTR)
			continue;
		else
			break;
	}
	cnt += n;
  }

  close(s);

  return cnt ? cnt : n;
}

