/*
 * radclient	A client-side implementation of the RADIUS protocol.
 *
 * Version:	@(#)radclient.c  1.20  04-Sep-1996  miquels@cistron.nl
 *
 */
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/time.h>
#include <sys/file.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#include "radius.h"
#include "radclient.h"

extern void md5_calc(unsigned char *, unsigned char *, unsigned int);
extern void nsyslog(int lvl, char *fmt, ...);

/*
 *      Print dotted IP address.
 */
static char *xdotted(unsigned int a)
{
	struct in_addr ia;

	ia.s_addr = a;
	return inet_ntoa(ia);
}

/*
 *	Create a new id.
 */
static int rad_id()
{
	int fd, i, n;
	char id[8];

	if ((fd = open(RAD_ID_FILE, O_RDWR|O_CREAT, 0644)) < 0) {
		nsyslog(LOG_ERR, "%s: %m", RAD_ID_FILE);
		return -1;
	}
	for(i = 0; i < 10; i++) {
		if (i > 0) usleep(200000);
		if (flock(fd, LOCK_EX) == 0)
		        break;
	}
	if (i == 10) {
		nsyslog(LOG_ERR, "rad_id: failed to lock %s", RAD_ID_FILE);
		return -1;
	}

	n = read(fd, id, 7);
	if (n < 0) n = 0;
	id[n] = 0;
	i = (atoi(id) + 1) & 0xff;
	sprintf(id, "%d\n", i);
	(void)ftruncate(fd, 0L);
	(void)lseek(fd, 0L, SEEK_SET);
	(void)write(fd, id, strlen(id));

	flock(fd, LOCK_UN);
	close(fd);

	return i;
}

/*
 *	Create a new session id.
 */
unsigned int rad_sessionid(char *s)
{
	int fd, n;
	unsigned int i;
	char id[32];

	if ((fd = open(RAD_SESSIONID_FILE, O_RDWR|O_CREAT, 0644)) < 0) {
		nsyslog(LOG_ERR, "%s: %m", RAD_SESSIONID_FILE);
		return -1;
	}
	for(i = 0; i < 10; i++) {
		if (i > 0) usleep(200000);
		if (flock(fd, LOCK_EX) == 0)
		        break;
	}
	if (i == 10) {
		nsyslog(LOG_ERR, "rad_sessionid: failed to lock %s",
			RAD_SESSIONID_FILE);
		return -1;
	}

	n = read(fd, id, 31);
	if (n < 0) n = 0;
	id[n] = 0;
	i = 0;
	sscanf(id, "%x", &i);
	if (s == NULL)
		i += 0x01000000;
	else
		i++;
	i &= 0xFFFFFFFF;
	if (i == 0) i++;
	sprintf(id, "%08x\n", i);
	(void)ftruncate(fd, 0L);
	(void)lseek(fd, 0L, SEEK_SET);
	(void)write(fd, id, strlen(id));

	flock(fd, LOCK_UN);
	close(fd);

	if (s) {
		strcpy(s, id);
		s[8] = 0;
	}
	return 0;
}

/*
 *	Create a random vector. We could use /dev/urandom
 *	for this under Linux for increased security, but..
 */
static void rad_vector(char *vector)
{
	int	randno;
	int	i;

	srand(time(0) + getpid());
	for(i = 0;i < AUTH_VECTOR_LEN;) {
		randno = rand();
		memcpy(vector, &randno, sizeof(int));
		vector += sizeof(int);
		i += sizeof(int);
	}
}


/*
 *	Build an attribute.
 *	Integers are passed through without conversion...
 */
static ATTR *rad_addattr(ATTR *list, int type, int val_len,
	unsigned int num, char *str)
{
	ATTR *a, *r;

	/*
	 * Ask for space.
	 */
	if ((r = (ATTR *)malloc(sizeof(ATTR))) == NULL) {
		nsyslog(LOG_ERR, "rad_addattr: Out of memory");
		return r;
	}
	memset(r, 0, sizeof(ATTR));

	/*
	 * Find end of the list (if any) and add us to it.
	 */
	for(a = list; a && a->next; a = a->next)
		;
	if (a) a->next = r;

	/*
	 * Fill out fields.
	 */
	if (str) {
		r->pwtype = PW_TYPE_STRING;
		r->len = val_len >= 0 ? val_len : strlen(str) + 1;
		memcpy(r->val.str, str, r->len);
	} else {
		r->pwtype = PW_TYPE_INTEGER;
		r->len = val_len > 0 ? val_len : 6;
		r->val.num = num;
	}
	r->len += 2;
	r->type = type;

	return r;
}

/*
 *	Build a request.
 */
static int rad_buildreq(char *buf, int bufsz, RADPKT *pkt)
{
	char *p = buf;
	ATTR *a;
	int attr_len = 0;
	int tot_len;
	int tm;
	time_t now;

	/*
	 *	Find out how much space we need for the value pairs.
	 */
	for(a = pkt->list; a; a = a->next)
		attr_len += a->len;
	tot_len = attr_len + AUTH_HDR_LEN;
	if (pkt->timestamp) tot_len += 8;
	if (tot_len > bufsz) {
		nsyslog(LOG_ERR, "rad_buildreq: buffer overflow");
		return -1;
	}
	memset(p, 0, tot_len);

	/*
	 *	See if we're going to use a new timestamp -
	 *	if so, we need a new ID.
	 */
	if (pkt->timestamp) {
		time(&now);
		if (pkt->lastsent != now) {
			pkt->id = rad_id();
			pkt->lastsent = now;
		}
	}

	/*
	 *	Fill in header fields.
	 */
	*p++ = pkt->code;
	*p++ = pkt->id;
	*(unsigned short *)p = htons(tot_len);
	p += 2;
	memcpy(p, pkt->vector, AUTH_VECTOR_LEN);
	p += AUTH_VECTOR_LEN;

	/*
	 *	Build complete request.
	 */
	for(a = pkt->list; a; a = a->next) {
		p[0] = a->type;
		p[1] = a->len;
		if (a->pwtype == PW_TYPE_STRING)
			memcpy(p+2, a->val.str, a->len - 2);
		else
			memcpy(p+2, &(a->val.num), 4);
		p += a->len;
	}

	/*
	 *	And add a time stamp.
	 */
	if (pkt->timestamp) {
		*p++ = PW_ACCT_DELAY_TIME;
		*p++ = 8;
		tm = htonl(now - pkt->timestamp);
		memcpy(p, &tm, 4);
	}

	return tot_len;
}

/*
 *	Free a list of attributes.
 */
void rad_attrfree(ATTR *l)
{
	ATTR *next;

	while (l != NULL) {
		next = l->next;
		free(l);
		l = next;
	}
}

/*
 *	Free a RADPKT.
 */
void rad_pktfree(RADPKT *r)
{
	rad_attrfree(r->list);
	free(r);
}

/*
 *	Find an attribute in a list.
 */
ATTR *rad_attrfind(RADPKT *r, int attr)
{
	ATTR *a;

	a = r->list;
	while(a && a->type != attr)
		a = a->next;
	return a;
}

/*
 *	Build an authentication request.
 */
static RADPKT *rad_buildauth(char *secret_key, struct auth *ai)
{
	RADPKT *pkt;
	ATTR *list = NULL;
	int secret_len;
	char  md5buf[256];
	char passtmp[256];
	int i;

	if ((pkt = malloc(sizeof(RADPKT))) == NULL)
		return NULL;
	memset(pkt, 0, sizeof(RADPKT));

	/*
	 *	Build the header.
	 */
	pkt->code = PW_AUTHENTICATION_REQUEST;
	pkt->id   = rad_id();
	rad_vector(pkt->vector);

	/*
	 *	Add the login name.
	 */
	if ((pkt->list = rad_addattr(NULL, PW_USER_NAME, -1, 0, ai->login)) == NULL) {
		free(pkt);
		return NULL;
	}

	/*
	 *	And the password - this one is hard.
	 */
	memset(passtmp, 0, sizeof(passtmp));
	secret_len = strlen(secret_key);
	strcpy(md5buf, secret_key);
	memcpy(md5buf + secret_len, pkt->vector, AUTH_VECTOR_LEN);
	md5_calc(passtmp, md5buf, secret_len + AUTH_VECTOR_LEN);
	for(i = 0; ai->passwd[i] && i < AUTH_PASS_LEN; i++)
		passtmp[i] ^= ai->passwd[i];

#if 0 /* XXX - DEBUG */
	nsyslog(LOG_DEBUG, "passwd/secret: %s/%s", passwd, secret_key);
#endif
	if (rad_addattr(pkt->list, PW_PASSWORD, AUTH_PASS_LEN, 0, passtmp) == NULL) {
		rad_attrfree(pkt->list);
		free(pkt);
		return NULL;
	}

	/*
	 *	Now we finish off with the client id (our ip address),
	 *	and the port id (tty number).
	 */
	if (rad_addattr(pkt->list, PW_NAS_IP_ADDRESS, 0, ai->nas_ip, NULL) == NULL) {
		rad_attrfree(list);
		free(pkt);
		return NULL;
	}
	if (rad_addattr(pkt->list, PW_NAS_PORT_ID, 0, htonl(ai->nas_port), NULL) == NULL) {
		rad_attrfree(list);
		free(pkt);
		return NULL;
	}

	/*
	 *	We add the protocol type if this is PPP.
	 */
	if (ai->ppphint &&
	rad_addattr(pkt->list, PW_FRAMED_PROTOCOL, 0, htonl(PW_PPP), NULL) == NULL) {
		rad_attrfree(list);
		free(pkt);
		return NULL;
	}
	if (ai->ppphint &&
	rad_addattr(pkt->list, PW_SERVICE_TYPE, 0, htonl(PW_FRAMED_USER), NULL) == NULL) {
		rad_attrfree(list);
		free(pkt);
		return NULL;
	}


	return pkt;
}

/*
 *	Build an accounting request.
 */
static RADPKT *rad_buildacct(struct radius *rad, struct acct *ai)
{
	RADPKT *pkt;
	int i, s, p, c;
	unsigned int h, a;

	if ((pkt = malloc(sizeof(RADPKT))) == NULL)
		return NULL;
	memset(pkt, 0, sizeof(RADPKT));

	/*
	 *	Build the header.
	 */
	pkt->code = PW_ACCOUNTING_REQUEST;;
	pkt->id   = rad_id();
	memset(pkt->vector, 0, 4);
	pkt->timestamp = time(NULL);

	/*
	 *	Tell the server what kind of request this is.
	 */
	i = ai->islogin ? PW_STATUS_START : PW_STATUS_STOP;
	if ((pkt->list = rad_addattr(pkt->list, PW_ACCT_STATUS_TYPE, 0, htonl(i), NULL)) == NULL) {
		free(pkt);
		return NULL;
	}

	/*
	 *	Add the login name.
	 */
	if (ai->login[0]) {
		if (rad_addattr(pkt->list, PW_USER_NAME, -1, 0, ai->login) == NULL) {
			rad_attrfree(pkt->list);
			free(pkt);
			return NULL;
		}
	}

	/*
	 *	Now we add the NAS's IP address
	 *	and the port id (tty number).
	 */
	if (rad_addattr(pkt->list, PW_NAS_IP_ADDRESS, 0, ai->nas_ip, NULL) == NULL) {
		rad_attrfree(pkt->list);
		free(pkt);
		return NULL;
	}

	if (rad_addattr(pkt->list, PW_NAS_PORT_ID, 0, htonl(ai->nas_port), NULL) == NULL) {
		rad_attrfree(pkt->list);
		free(pkt);
		return NULL;
	}

	/*
	 *	We have to add a unique identifier, the same
	 *	for login as for logout.
	 */
	if (rad_addattr(pkt->list, PW_ACCT_SESSION_ID, -1, 0, ai->acctsessionid) == NULL) {
		rad_attrfree(pkt->list);
		free(pkt);
		return NULL;
	}

	/*
	 *	Include session time if this is a logout.
	 */
	if (!ai->islogin &&
	    rad_addattr(pkt->list, PW_ACCT_SESSION_TIME, 0,
	    htonl(ai->elapsed), NULL) == NULL) {
		rad_attrfree(pkt->list);
		free(pkt);
		return NULL;
	}

	/*
	 *	We'll have to add some more fields here:
	 *	- service type
	 *	- login service
	 *	- framed protocol
	 *	- framed IP address
	 *	- framed compression
	 *	- login IP host
	 *
	 */
	i = -1;
	s = -1;
	p = -1;
	c = -1;
	h = 0;
	a = 0;
	switch(ai->proto) {
		case P_SHELL:
			s = PW_SHELL_USER;
			break;
		case P_TELNET:
			s = PW_LOGIN_USER;
			i = PW_TELNET;
			h = ai->address;
			break;
		case P_RLOGIN:
			s = PW_LOGIN_USER;
			i = PW_RLOGIN;
			h = ai->address;
			break;
		case P_TCPCLEAR:
		case P_TCPLOGIN:
			s = PW_LOGIN_USER;
			i = PW_TCP_CLEAR;
			h = ai->address;
			break;
		case P_PPP:
		case P_SLIP:
		case P_CSLIP:
			s = PW_FRAMED_USER;
			a = ai->address;
			break;
	}
	switch(ai->proto) {
		case P_PPP:
			p = PW_PPP;
			c = PW_VAN_JACOBSEN_TCP_IP;
			break;
		case P_SLIP:
			p = PW_SLIP;
			break;
		case P_CSLIP:
			p = PW_SLIP;
			c = PW_VAN_JACOBSEN_TCP_IP;
	}
	if (s > 0 && rad_addattr(pkt->list, PW_SERVICE_TYPE, 0, htonl(s), NULL) == NULL) {
buildacct_error:
		rad_attrfree(pkt->list);
		free(pkt);
		return NULL;
	}
	if (i >= 0 && rad_addattr(pkt->list, PW_LOGIN_SERVICE, 0, htonl(i), NULL) == NULL)
		goto buildacct_error;

	if (p >= 0 && rad_addattr(pkt->list, PW_FRAMED_PROTOCOL, 0, htonl(p), NULL) == NULL)
		goto buildacct_error;

	if (a > 0 && rad_addattr(pkt->list, PW_FRAMED_IP_ADDRESS, 0, a, NULL) == NULL)
		goto buildacct_error;

	if (c >= 0 && rad_addattr(pkt->list, PW_FRAMED_COMPRESSION, 0, htonl(c), NULL) == NULL)
		goto buildacct_error;

	if (h > 0 && rad_addattr(pkt->list, PW_LOGIN_IP_HOST, 0, h, NULL) == NULL)
		goto buildacct_error;

	return pkt;
}


static int rad_send(unsigned int host1, unsigned int host2,
	char *recvbuf, int size, RADPKT *req)
{
	char sendbuf[4096];
	int sendlen;
	struct sockaddr_in salocal, saremote, sa_replied;
	int local_port;
	int s, len, n, i;
	unsigned int remote = host1;
	fd_set readfds;
	struct timeval tv;

	sendlen = rad_buildreq(sendbuf, sizeof(sendbuf), req);
	if (sendlen < 0) return -1;

	/*
	 *	We have to bind the socket in order to
	 *	receive an answer back...
	 */
	if ((s = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		nsyslog(LOG_ERR, "socket: %m");
		return -1;
	}

	memset(&salocal, 0, sizeof(salocal));
	salocal.sin_family = AF_INET;
	salocal.sin_addr.s_addr = INADDR_ANY;
	local_port = 1025;
	do {
		local_port++;
		salocal.sin_port = htons((unsigned short)local_port);
	} while ((bind(s, (struct sockaddr *)&salocal, sizeof (salocal)) < 0)
			&& local_port < 64000);

	if (local_port >= 64000) {
		close(s);
		nsyslog(LOG_ERR, "bind: %m");
		return -1;
	}

	/*
	 *	saremote is the remote radius server address.
	 */
	memset(&saremote, 0, sizeof(saremote));
	saremote.sin_family = AF_INET;
	saremote.sin_port = htons(PW_AUTH_UDP_PORT);
	n = 0;

	/*
	 *	Try at most 10 times. We time out after 3 seconds,
	 *	and after 3 tries we switch to an alternate server, and
	 *	keep switching after every timeout.
	 */
	for(i = 0; i < 10; i++) {
		if (host2 && i > 2) {
			nsyslog(LOG_INFO, "radius@%s not responding",
				xdotted(remote));
			if (remote == host1)
				remote = host2;
			else
				remote = host1;
		}
		if (host1 == 0 && host2 != 0) remote = host2;

		/*
		 *	Connect to the radius server, and
		 *	send the request.
		 */
		saremote.sin_addr.s_addr = remote;
		sendto(s, sendbuf, sendlen, 0,
			(struct sockaddr *)&saremote, sizeof(saremote));

		/*
		 *	Now wait for an answer.
		 */
		tv.tv_sec = 3;
		tv.tv_usec = 0;
		FD_ZERO(&readfds);
		FD_SET(s, &readfds);
		len = sizeof(saremote);
		if (select(s + 1, &readfds, NULL, NULL, &tv) > 0 &&
		    (n = recvfrom(s, recvbuf, size, 0,
				(struct sockaddr *)&sa_replied, &len)) > 0)
					break;
	}
	close(s);

	if (i == 10) {
		nsyslog(LOG_ERR, "Radius server(s) not responding");
		return -1;
	}
	if (i > 2) nsyslog(LOG_INFO, "radius@%s replied eventually",
		xdotted(sa_replied.sin_addr.s_addr));

	return n;
}

/*
 *	Ask a radius server to authenticate us. Does nothing more;
 *	just puts the raw reply packet in the buffer.
 */
int rad_client(struct radius *rad, struct auth *ai, char *recvbuf, int bufsz)
{
	RADPKT *req;
	int len;

        /*
         *      First, build the request.
         */
	if ((req = rad_buildauth(rad->secret, ai)) == NULL)
		return -1;

	/*
	 *	Now connect to the server.
	 */
	len = rad_send(rad->authhost1, rad->authhost2,
	    recvbuf, bufsz, req);

	rad_attrfree(req->list);
	free(req);

	if (len < 0) return -1;

#if 0 /* XXX Debug */
	{
		RADPKT *req;
		reply = (AUTH_HDR *)recvbuf;
		nsyslog(LOG_DEBUG, "Got a reply, code %d, length %d",
				reply->code, ntohs(reply->length));
	}
#endif
	return len;
}

/*
 *	Decode a RADIUS reply.
 */
RADPKT *rad_decode(char *recvbuf, int bufsz)
{
	AUTH_HDR *reply;
	RADPKT *req;
	ATTR *r;
	int a_len, a_type;
	char *a_val;
	char *ptr, *maxptr;
	int length;

	/*
	 *	Decode the header of the reply.
	 */
	reply = (AUTH_HDR *)recvbuf;
	ptr = recvbuf;

	if ((req = (RADPKT *)malloc(sizeof(RADPKT))) == NULL) {
		nsyslog(LOG_ERR, "rad_decode: Out of memory");
		return NULL;
	}
	memset(req, 0, sizeof(RADPKT));
	req->code   = reply->code;
	req->id     = reply->id;
	length      = ntohs(reply->length);
	memcpy(req->vector, reply->vector, AUTH_VECTOR_LEN);
	req->timestamp = time(NULL);

	maxptr = ptr + length;
	ptr += 20;

	if (length > bufsz) {
		nsyslog(LOG_ERR, "rad_decode: packet has bogus size %d", length);
		free(req);
		return NULL;
	}

	/*
	 *	Now add the attributes.
	 */
	while(ptr < maxptr) {
		a_type = ptr[0];
		a_len = ptr[1];
		a_val = &ptr[2];
		ptr += a_len;
#if 0 /* XXX - Debug */
		DEBUG("rad_decode: Attribute type %d, length %d\n",
			a_type, a_len);
#endif
		if (a_type == 0 || a_len < 2) break;

		r = rad_addattr(req->list, a_type, a_len - 2, 0, a_val);
		if (r == NULL) break;
		if (req->list == NULL) req->list = r;
	}

	return req;
}

/*
 *	Send accounting info to a RADIUS server.
 */
int rad_acct(struct radius *rad, struct acct *ai)
{
	int len;
	RADPKT *req;
	char recvbuf[4096];

        /*
         *      First, build the request.
         */
	if ((req = rad_buildacct(rad, ai)) == NULL)
		return -1;

	/*
	 *	Now connect to the server.
	 */
	len = rad_send(rad->accthost1, rad->accthost2,
		recvbuf, sizeof(recvbuf), req);

	rad_attrfree(req->list);
	free(req);

	if (len < 0) return -1;

#if 0 /* XXX - Debug */
	{
		AUTH_HDR *reply;
		reply = (AUTH_HDR *)ptr;
		nsyslog(LOG_DEBUG, "Got a reply, code %d, length %d",
			reply->code, ntohs(reply->length));
	}
#endif

	/*
	 *	FIXME: should we check the reply?
	 */

	return 0;
}
