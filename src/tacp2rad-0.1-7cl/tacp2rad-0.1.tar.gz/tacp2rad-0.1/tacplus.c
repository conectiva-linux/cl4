/*
 * tacp2radd	Daemon that translates TACACS+ queries from a NAS
 *		to RADIUS and queries a local or remote RADIUS daemon
 *		for AAA.
 *
 * Version:	@(#)tacp2radd  1.10  04-Sep-1996  miquels@cistron.nl
 *
 */
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <stdarg.h>
#include <syslog.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <signal.h>

#include "radius.h"
#include "radclient.h"
#include "header.h"

#define TACACS_PORT	49
#define MAXPROC		64

/*
 *	Packets types (AAA)
 */
#define TAC_PLUS_AUTHEN		0x01
#define TAC_PLUS_AUTHOR		0x02
#define TAC_PLUS_ACCT		0x03

#define TAC_PLUS_ENCRYPTED	0x00
#define TAC_PLUS_CLEAR		0x01

/*
 *	Every packet sent/received starts with this header.
 */
struct tacplus_pkt {
  struct in_addr sin_addr;
  unsigned char major;
  unsigned char minor;
  unsigned char type;
  unsigned char seqno;
  unsigned char encryption;
  unsigned int session_id;
  unsigned int length;
  char *packet;
  char *data;
  char *data2;
};

/*
 *	This is an authentication request. For some STUPID reason there
 *	are 2 authentication requests: a START packet (the first packet
 *	sent) and a CONTINUE packet (used thereafter).
 */
 
struct authstart_pkt {
  unsigned char action;
  unsigned char priv_lvl;
  unsigned char type;
  unsigned char service;
  char *user;
  char *port;
  char *rem_addr;
};

struct authcont_pkt {
  char *user_msg;
  char *data;
};

/*
 *	This is an autorization or accounting request.
 */
struct aa_req_pkt {
  unsigned char flags; /* Accounting only. */
  unsigned char method;
  unsigned char priv_lvl;
  unsigned char type;
  unsigned char service;
  char *user;
  char *port;
  char *rem_addr;
  char *args[32];
};

static char *lprompt = "login: ";
static char *pprompt = "Password: ";
int debug = 0;

static char sendbuf[1500];
static char recvbuf[4096];

static pid_t mypid, master;

struct radius radius_conf;

/*
 *	This is a one-time attributes buffer.
 */
static struct auth lastauth;
static char lastbuf[1500];
static RADPKT *lastrad;

/*
 *	Print debugging output.
 */
void DEBUG(char *fmt, ...)
{
  va_list ap;

  if (!debug) return;

  if (mypid == 0)
	printf("MASTR: ");
  else
	printf("%5d: ", mypid);
  va_start(ap, fmt);
  vfprintf(stdout, fmt, ap);
  va_end(ap);
}

/*
 *	Our own syslog version.
 */
void nsyslog(int lvl, char *fmt, ...)
{
  va_list ap;
  char buf[256];
  char *s, *pe;
  int l, le;
  int e = errno;

  va_start(ap, fmt);
  vsprintf(buf, fmt, ap);
  va_end(ap);

  s = buf;
  while((s = strstr(s, "%m")) != NULL) {
	if (pe == NULL) {
		pe = strerror(e);
		le = strlen(pe);
	}
	l = strlen(s);
	memmove(s + le, s + 2, strlen(s + 2));
	memcpy(s, pe, le);
  }
  syslog(lvl, "%s", buf);
  DEBUG("%s\n", buf);
}


/*
 *	A process has died. Collect exit status.
 */
/*ARGSUSED*/
void chld_handler(int sig)
{
  int st;
  pid_t pid;

  while((pid = waitpid(0, &st, WNOHANG)) > 0 || (pid < 0 && errno == EINTR))
	;
}

/*
 *	We got the TERM signal. Kill our children too.
 */
void term_handler(int sig)
{
  pid_t pid = getpid();

  signal(sig, SIG_DFL);
  unlink(PIDFILE);
  kill(-pid, sig);
}

/*
 *	Print the header.
 */
void printhdr(struct tacplus_pkt *pkt)
{
  DEBUG("Major   : %02x\n", pkt->major);
  DEBUG("Minor   : %02x\n", pkt->minor);
  DEBUG("Type    : %02x\n", pkt->type);
  DEBUG("Seq_no  : %02x\n", pkt->seqno);
  DEBUG("Encr    : %02x\n", pkt->encryption);
  DEBUG("Sessid  : %08x\n", pkt->session_id);
  DEBUG("Length  : %d\n",   pkt->length);
}

/*
 *	Print authentication START packet.
 */
void printauthstart(struct authstart_pkt *pkt)
{
  DEBUG("Action      : %02x\n", pkt->action);
  DEBUG("Priv_lvl    : %02x\n", pkt->priv_lvl);
  DEBUG("Authen_type : %02x\n", pkt->type);
  DEBUG("Service     : %02x\n", pkt->service);
  DEBUG("User        : %s\n", pkt->user);
  DEBUG("Port        : %s\n", pkt->port);
  DEBUG("Rem addr    : %s\n", pkt->rem_addr);
}

/*
 *	Print authorization request.
 */
void printaapkt(struct aa_req_pkt *pkt)
{
  int i;

  DEBUG("Flags       : %02x\n", pkt->flags);
  DEBUG("Method      : %02x\n", pkt->method);
  DEBUG("Priv_lvl    : %02x\n", pkt->priv_lvl);
  DEBUG("Authen_type : %02x\n", pkt->type);
  DEBUG("Service     : %02x\n", pkt->service);
  DEBUG("User        : %s\n", pkt->user);
  DEBUG("Port        : %s\n", pkt->port);
  DEBUG("Rem addr    : %s\n", pkt->rem_addr);

  for(i = 0; pkt->args[i]; i++)
	DEBUG("%2d. %s\n", i, pkt->args[i]);

}

/*
 *	Get the value of an autorization A/V pair.
 */
char *value(struct aa_req_pkt *pkt, char *attr)
{
  int i;
  char *s;

  for(i = 0; pkt->args[i]; i++) {
	if ((s = strchr(pkt->args[i], '=')) == NULL &&
	    (s = strchr(pkt->args[i], '*')) == NULL)
		continue;
	if (strncmp(pkt->args[i], attr, (s - pkt->args[i])) == 0)
		return s + 1;
  }
  return "";
}

/*
 *	Save a string at the end of the packet space.
 */
char *xstr(char *s, int len, struct tacplus_pkt *pkt)
{
  char *sp = pkt->data2;

  strncpy(pkt->data2, s, len);
  pkt->data2[len] = 0;
  pkt->data2 += len + 1;

  return sp;
}


/*
 *	Read a number of bytes from a network connection.
 */
int xread(int s, char *buf, int nr)
{
  int n, done = 0;

  while((n = read(s, buf + done, nr - done)) > 0 || (n < 0 && errno == EINTR)) {
	if (n > 0)
		done += n;
	if (done >= nr) break;
  }

  if (done == 0 && n < 0) return -1;
  return done;
}

/*
 *	Read one packet from the network.
 */
int readpkt(struct tacplus_pkt *pkt, int s)
{
  int n;

  if ((n = xread(s, recvbuf, 12)) != 12) {
	if (n < 0)
		nsyslog(LOG_ERR, "readpkt: read: %m");
	else if (n > 0)
		nsyslog(LOG_ERR, "readpkt: short read (%d of %d bytes)",
			n, 12);
	else
		DEBUG("readpkt: EOF\n");
	return -1;
  }

  pkt->major      = recvbuf[0] / 16;
  pkt->minor      = recvbuf[0] & 15;
  pkt->type       = recvbuf[1];
  pkt->seqno      = recvbuf[2];
  pkt->encryption = recvbuf[3];
  pkt->session_id = *(unsigned int *)(recvbuf + 4);
  pkt->length     = ntohl(*(unsigned int *)(recvbuf + 8));

  if (debug) printhdr(pkt);

  if (pkt->length > 1500) {
	nsyslog(LOG_ERR, "readpkt: bogus length %d", pkt->length);
	return -1;
  }

  if ((n = xread(s, recvbuf + 12, pkt->length)) != pkt->length) {
	if (n < 0)
		nsyslog(LOG_ERR, "readpkt: read: %m");
	else if (n > 0)
		nsyslog(LOG_ERR, "readpkt: short read (%d of %d bytes)",
			n, pkt->length);
	else
		DEBUG("readpkt: EOF");
	return -1;
  }
  pkt->packet = recvbuf;
  pkt->data = recvbuf + 12;
  pkt->data2 = recvbuf + 12 + pkt->length;

  return 0;
}

/*
 *	Send a reply back to the NAS.
 */
int reply_pkt(int s, struct tacplus_pkt *pkt, char *data, int len)
{

  sendbuf[0] = (pkt->major * 16) + pkt->minor;
  sendbuf[1] = pkt->type;
  sendbuf[2] = ++pkt->seqno;
  sendbuf[3] = pkt->encryption;
  *(unsigned int *)(sendbuf + 4) = pkt->session_id;
  *(unsigned int *)(sendbuf + 8) = htonl(len);
  memcpy(sendbuf + 12, data, len);

  DEBUG("reply_pkt: sending back %d bytes (seqno %d)\n",
	len + 12, pkt->seqno);

  if (write(s, sendbuf, len + 12) != len + 12) {
	nsyslog(LOG_ERR, "reply_pkt: short write!");
	return -1;
  }
  return 0;
}

/*
 *	Reject authentication.
 */
void authen_reject(int s, struct tacplus_pkt *pkt, char *str)
{
  char reply[128];
  int msg_len = strlen(str) + 1;

  reply[0] = 0x02; /* TAC_PLUS_AUTHEN_STATUS_FAIL */
  reply[1] = 0;
  *(unsigned short *)(reply + 2) = msg_len;
  *(unsigned short *)(reply + 4) = 0;
  strcpy(reply + 6, str);

  reply_pkt(s, pkt, reply, msg_len + 6);
}

/*
 *	Handle authentication packet.
 */
int authen_pkt(int s, struct tacplus_pkt *pkt)
{
  struct authstart_pkt apkt;
  char reply[1024];
  int l, n, msg_len;
  char *sp;
  ATTR *a;

  DEBUG("Authentication packet.\n");

  if (lastrad) {
	rad_pktfree(lastrad);
	lastrad = 0;
  }
  memset(&lastauth, 0, sizeof(lastauth));

  if (8 + pkt->data[4] + pkt->data[5] + pkt->data[6] + pkt->data[7]
	!= pkt->length) {
	nsyslog(LOG_ERR, "authen_pkt: START packet length mismatch");

	return -1;
  }
  memset(&apkt, 0, sizeof(apkt));
  apkt.action      = pkt->data[0];
  apkt.priv_lvl    = pkt->data[1];
  apkt.type        = pkt->data[2];
  apkt.service     = pkt->data[3];
  sp  = pkt->data + 8; 
  apkt.user        = xstr(sp, pkt->data[4], pkt);
  sp += pkt->data[4];
  apkt.port        = xstr(sp, pkt->data[5], pkt);
  sp += pkt->data[5];
  apkt.rem_addr    = xstr(sp, pkt->data[6], pkt);

  if (debug) printauthstart(&apkt);

  /*
   *	Check action, type and service. We do not support ARAP, X.25,
   *	CHAP, change password, and all that stuff. Just plain logins.
   */
  if (apkt.action != 0x01) { /* TAC_PLUS_AUTHEN_LOGIN */
	nsyslog(LOG_ERR, "authen_pkt: cannot handle action 0x%02x",
		apkt.action);
	authen_reject(s, pkt, "Sorry - unknown action\n");
	return -1;
  }

  if (apkt.type != 0x01 && apkt.type != 0x02) {
	/* TAC_PLUS_AUTHEN_TYPE_ASCII && TAC_PLUS_AUTHEN_TYPE_PAP */ 
	nsyslog(LOG_ERR, "authen_pkt: we do not support authen_type 0x%02x",
		apkt.type);
	authen_reject(s, pkt, "Sorry - unknown authentication type\n");
	return -1;
  }

  if (apkt.service != 0x01 && apkt.service != 0x03) {
	/* TAC_PLUS_AUTHEN_SVC_LOGIN && TAC_PLUS_AUTHEN_SVC_PPP */
	nsyslog(LOG_ERR,"authen_pkt: request from unsupported service 0x%02x",
		apkt.service);
	authen_reject(s, pkt, "Sorry - request from unknown service\n");
	return -1;
  }

  /*
   *	It is possible that the username is already present in
   *	the first authentication packet (PPP/PAP does this);
   *	so only try to get a username if we don't have it yet.
   */
  if (apkt.user[0] == 0) while(1) {
	/*
	 *	Reply the first query with a standard reply packet.
	 */
	msg_len = strlen(lprompt) + 1;
	reply[0] = 0x04; /* TAC_PLUS_AUTHEN_STATUS_GETUSER */
	reply[1] = 0;
	*(unsigned short *)(reply + 2) = htons(msg_len);
	*(unsigned short *)(reply + 4) = 0;
	strcpy(reply + 6, lprompt);

	DEBUG("Asking the NAS for username.\n");
	reply_pkt(s, pkt, reply, msg_len + 6);

	/*
	 *	Now await the username reply.
	 */
	if (readpkt(pkt, s) < 0)
		return -1;
	l = ntohs(*(unsigned short *)(pkt->data));
	strncpy(lastauth.login, pkt->data + 5, MIN(sizeof(lastauth.login), l));
	if (lastauth.login[0] != 0) break;
  } else
	strncpy(lastauth.login, apkt.user, sizeof(lastauth.login));
  DEBUG("Username is %s\n", lastauth.login);

  /*
   *	And ask for the password.
   */
  msg_len = strlen(pprompt) + 1;
  reply[0] = 0x05;
  reply[1] = 0x01;
  *(unsigned short *)(reply + 2) = htons(msg_len);
  *(unsigned short *)(reply + 4) = 0;
  strcpy(reply + 6, pprompt);

  DEBUG("Asking the NAS for password.\n");
  reply_pkt(s, pkt, reply, msg_len + 6);

  /*
   *	Wait for the password reply.
   */
  if (readpkt(pkt, s) < 0)
        return -1;
  l = ntohs(*(unsigned short *)(pkt->data));
  strncpy(lastauth.passwd, pkt->data + 5, MIN(sizeof(lastauth.passwd), l));

  /*
   *	Here we map the request to a RADIUS type request.
   */
  DEBUG("Password is %s\n", lastauth.passwd);
  lastauth.nas_ip = pkt->sin_addr.s_addr;
  lastauth.nas_port = tac_map(pkt->sin_addr.s_addr, apkt.port);
  lastauth.ppphint = (apkt.service == 0x03); /* TAC_PLUS_AUTHEN_SVC_PPP */

  if ((n = rad_client(&radius_conf, &lastauth, lastbuf, sizeof(lastbuf))) < 0) {
	memset(&lastauth, 0, sizeof(lastauth));
	authen_reject(s, pkt, "Sorry - problem talking to RADIUS\n");
	return -1;
  }
  if ((lastrad = rad_decode(lastbuf, sizeof(lastbuf))) == NULL) {
	memset(&lastauth, 0, sizeof(lastauth));
	authen_reject(s, pkt, "Sorry - problem talking to RADIUS\n");
	return -1;
  }
  if (lastrad->code != PW_AUTHENTICATION_ACK) {
	a = rad_attrfind(lastrad, PW_REPLY_MESSAGE);
	if (a)
		sp = a->val.str;
	else
		sp = "Login incorrect.\n";
	rad_pktfree(lastrad);
	lastrad = NULL;
	memset(&lastauth, 0, sizeof(lastauth));
	authen_reject(s, pkt, sp);
	return -1;
  }

  /*
   *	Buffer this info in the buffer daemon.
   */
  DEBUG("Sending %d bytes into the buffer for %s\n",
	n, lastauth.login);
  buffer_send(&lastauth, lastbuf, n);

  /*
   *    And send login OK.
   */
  msg_len = 0;
  reply[0] = 0x01;
  reply[1] = 0x00;
  *(unsigned short *)(reply + 2) = htons(msg_len);
  *(unsigned short *)(reply + 4) = 0;
  /*strcpy(reply + 6, prompt);*/

  reply_pkt(s, pkt, reply, msg_len + 6);

  return 0;
}

/*
 *	Convert RADIUS packet to a TACACS+ Authorization
 *	packet, for FRAMED type connections.
 */
char **framed_rad2tac(RADPKT *r, char *pre[])
{
  ATTR *a;
  static char *args[32];
  static char buf[1024];
  char *p = buf;
  int l, i = 0, n, val;
  struct in_addr sin_addr;

  /*
   *	Setup the initial values.
   */
  for(n = 0; pre && pre[n]; n++) {
	strcpy(p, pre[n]);
	l = strlen(pre[n]);
	args[i++] = p;
	p += l + 1;
  }

  /*
   *	Now try to convert most of the RADIUS attributes to tacacs+.
   */
  *p = 0;
  for(a = r->list; a; a = a->next) {
	switch(a->type) {
		case PW_FRAMED_IP_ADDRESS:
			sin_addr.s_addr = a->val.num;
			sprintf(p, "addr=%s", inet_ntoa(sin_addr));
			break;
		case PW_FRAMED_ROUTING:
			val = ntohl(a->val.num);
			if (val == 3 || val == 0) {
				/* Send _and_ listen */
				sprintf(p, "routing=%d", val == 3 ? 1 : 0);
			}
			break;
		case PW_CALLBACK_NUMBER:
			sprintf(p, "callback=%s", a->val.str);
			break;
		case PW_FRAMED_ROUTE:
			/*
			 *	FIXME: convert RADIUS style to Cisco style.
			 */
			sprintf(p, "route=%s", a->val.str);
			break;
		case PW_SESSION_TIMEOUT:
			val = ntohl(a->val.num);
			sprintf(p, "timeout=%d", val);
			break;
		case PW_IDLE_TIMEOUT:
			val = ntohl(a->val.num);
			sprintf(p, "idletime=%d", val);
			break;
		/*
		 *	The following would be nice to convert but
		 *	I don't know how tacacs+ calls them.
		 */
		case PW_FRAMED_MTU:
		case PW_FRAMED_IP_NETMASK:
		case PW_FRAMED_COMPRESSION:
			/* Not supported with tacacs+ */
			break;
	}
	if (*p) {
		args[i++] = p;
		l = strlen(p);
		p += l + 1;
		*p = 0;
	}
  }
  args[i] = 0;

  if (debug) {
	DEBUG("Reply A/V pairs:\n");
	for(i = 0; args[i]; i++)
		DEBUG("  %d. %s\n", i, args[i]);
  }
  return args;
}


/*
 *	Handle authorization packet.
 */
int author_pkt(int s, struct tacplus_pkt *pkt)
{
  char reply[1024];
  int reply_len = 0;
  struct aa_req_pkt apkt;
  int nr, i, len, n;
  int arglen;
  char *argp, *sp;
  char *ppppre[] = {
	"service=ppp",
	"protocol=ip",
	NULL,
  };
  char **pppans;
  char *denied = "Authorization failed.";
  ATTR *a;
  int pw_service_type;
  int pw_login_service;
  int pw_framed_protocol;
#if 0
  int msg_len;
  char *shellans[] = {
	"service=shell",
	"cmd*",
	"autocmd*telnet picard",
	NULL,
  };
#endif

  DEBUG("Authorization packet.\n");

  /*
   *	Get the packet into our structure, and put in
   *	a few consistency checks on the way.
   */
  memset(&apkt, 0, sizeof(apkt));
  apkt.flags     = 0x80;
  apkt.method    = pkt->data[0];
  apkt.priv_lvl  = pkt->data[1];
  apkt.type      = pkt->data[2];
  apkt.service   = pkt->data[3];
  nr             = pkt->data[7];
  sp  = pkt->data + 8 + nr;
  apkt.user      = xstr(sp, pkt->data[4], pkt);
  sp += pkt->data[4];
  apkt.port      = xstr(sp, pkt->data[5], pkt);
  sp += pkt->data[5];
  apkt.rem_addr  = xstr(sp, pkt->data[6], pkt);
  arglen         = pkt->data[4] + pkt->data[5] + pkt->data[6];
  argp           = pkt->data + 8 + arglen + nr;

  for(i = 0; i < nr; i++)
	arglen += pkt->data[8 + i];

  if (arglen + nr + 8 != pkt->length) {
	nsyslog(LOG_ERR, "author_pkt: packet length mismatch");
	return -1;
  }
  for(i = 0; i < nr && i < 31; i++) {
	apkt.args[i] = xstr(argp, pkt->data[8 + i], pkt);
	argp += pkt->data[8 + i];
  }
  apkt.args[i] = 0;

  if (debug) printaapkt(&apkt);

  /*
   *	First of all, set the reply packet to "access denied".
   */
  reply[0] = 0x10; /* TAC_PLUS_AUTHOR_STATUS_FAIL */
  reply[1] = 0;
  reply[2] = 0;
  reply[3] = strlen(denied);
  reply[4] = 0;
  reply[5] = 0;
  strncpy(reply + 6, denied, reply[3]);
  reply_len = 6 + reply[3];

  /*
   *	Now find the matching RADIUS reply. I know we must have
   *	it laying around here _somewhere_ :)
   */
  i = tac_map(pkt->sin_addr.s_addr, apkt.port);
  if (strcmp(apkt.user, lastauth.login) != 0 ||
      lastauth.nas_port != i ||
      lastauth.nas_ip != pkt->sin_addr.s_addr) {
	/*
	 *	Not in the cache..
	 */
	if (lastrad != NULL) {
		rad_pktfree(lastrad);
		lastrad = NULL;
	}
	strcpy(lastauth.login, apkt.user);
	lastauth.nas_port = i;
	lastauth.nas_ip = pkt->sin_addr.s_addr;
	if ((n = buffer_ask(&lastauth, lastbuf, sizeof(lastbuf))) <= 0) {
		/*
		 *	Euh we don't have it _at all_. Grmbl..
		 */
		DEBUG("Didn't find original RADIUS reply - sending reject\n");
		reply_pkt(s, pkt, reply, reply_len);
		memset(&lastauth, 0, sizeof(lastauth));
		return 0;
	}
	DEBUG("Found RADIUS reply by asking the buffer process: %d bytes\n",n);
	lastrad = rad_decode(lastbuf, sizeof(lastbuf));
  } else
	DEBUG("Found RADIUS reply in local cache.\n");

  /*
   *	Find some RADIUS variables we really need.
   */
  pw_service_type = 0;
  pw_login_service = 0;
  pw_framed_protocol = 0;
  if ((a = rad_attrfind(lastrad, PW_SERVICE_TYPE)) != NULL)
	pw_service_type = ntohl(a->val.num);
  if ((a = rad_attrfind(lastrad, PW_LOGIN_SERVICE)) != NULL)
	pw_login_service = ntohl(a->val.num);
  if ((a = rad_attrfind(lastrad, PW_FRAMED_PROTOCOL)) != NULL)
	pw_framed_protocol = ntohl(a->val.num);

  /*
   *	Check if this was a PPP authorization request.
   */
  if (strcmp(value(&apkt, "service"), "ppp") == 0 &&
      pw_service_type == PW_FRAMED_USER && pw_framed_protocol == PW_PPP) {

	/*
	 *	LCP requests are always OK, IPCP requests get
	 *	the address set if needed.
	 */
	if (strcmp(value(&apkt, "protocol"), "lcp") == 0) {
		DEBUG("PPP LCP request - always OK.\n");
		memset(reply, 0, 6);
		reply[0] = 0x01; /* TAC_PLUS_AUTHOR_STATUS_PASS_ADD */
		reply_len = 6;
	}
	if (strcmp(value(&apkt, "protocol"), "ip") == 0) {

		DEBUG("PPP IP request - sending IP number etc..\n");

		pppans = framed_rad2tac(lastrad, ppppre);

		reply[0] = 0x02; /* TAC_PLUS_AUTHOR_STATUS_PASS_REPL */
		*(unsigned short *)(reply + 2) = 0;
		*(unsigned short *)(reply + 4) = 0;
		for(i = 0; pppans[i]; i++)
			;
		nr = i;
		reply[1] = nr;
		sp = reply + 6 + nr;
		reply_len = 6 + nr;
	
		for(i = 0; i < nr; i++) {
			len = strlen(pppans[i]);
			reply[6 + i] = len;
			strncpy(sp, pppans[i], len);
			sp += len;
			reply_len += len;
		}
	}
  }

  /*
   *	Perhaps a shell access request.
   */
  if (strcmp(value(&apkt, "service"), "shell") == 0) {

	DEBUG("Shell service request\n");

	/*
	 *	Access to the command line required ?
	 */
	if (pw_service_type == PW_SHELL_USER) {
		DEBUG("Access to NAS command line OK\n");
		memset(reply, 0, 6);
		reply[0] = 0x01; /* TAC_PLUS_AUTHOR_STATUS_PASS_ADD */
		reply_len = 6;
	}

	/*
	 *	Or exec a rlogin/telnet session.
	 */
	if (pw_service_type == PW_LOGIN_USER && pw_login_service == PW_TELNET){
		/* FIXME */
		DEBUG("telnet access asked - not implemented\n");
	}
	if (pw_service_type == PW_LOGIN_USER && pw_login_service == PW_RLOGIN){
		/* FIXME */
		DEBUG("rlogin access asked - not implemented\n");
	}

	/*
	 *	Could also be SLIP/PPP in which case we need to
	 *	give the right autocmd. Not with ISDN30 / Sync PPP tho.
	 */
#if 0
	/*
	 *	FIXME: This doesn't work but something like this needs
	 *	to be done to finish the above.
	 */
	reply[0] = 0x02; /* TAC_PLUS_AUTHOR_STATUS_PASS_REPL */
	*(unsigned short *)(reply + 2) = htons(msg_len);
	*(unsigned short *)(reply + 4) = 0;
	for(i = 0; shellans[i]; i++)
		;
	nr = i;
	reply[1] = nr;
	sp = reply + 6 + nr;
	strncpy(sp, msg, msg_len);
	sp += msg_len;
	reply_len = 6 + nr + msg_len;

	for(i = 0; i < nr; i++) {
		len = strlen(shellans[i]);
		reply[6 + i] = len;
		strncpy(sp, shellans[i], len);
		sp += len;
		reply_len += len;
	}
#endif
  }

  if (reply[0] == 0x10)
	DEBUG("Authorization: no match, denying access.\n");

  /*
   *	Finally send the reply.
   */
  DEBUG("Sending authorization reply\n");
  reply_pkt(s, pkt, reply, reply_len);

  return 0;
}

/*
 *	Handle accounting packet.
 */
int acct_pkt(int s, struct tacplus_pkt *pkt)
{
  char reply[1024];
  int reply_len;
  int ret = 0;
  struct aa_req_pkt apkt;
  int nr, i, sendit;
  int arglen;
  char *argp, *sp;
  struct acct acct;

  DEBUG("Accounting packet.\n");

  /*
   *	Get the packet into our structure, and put in
   *	a few consistency checks on the way.
   *
   *	This is almost, but not entirely, like the authorization
   *	packet. WHY did some GENIUS at Cisco make them different?
   *
   */
  memset(&apkt, 0, sizeof(apkt));
  apkt.flags     = pkt->data[0];
  apkt.method    = pkt->data[1];
  apkt.priv_lvl  = pkt->data[2];
  apkt.type      = pkt->data[3];
  apkt.service   = pkt->data[4];
  nr             = pkt->data[8];
  sp  = pkt->data + 9 + nr;
  apkt.user      = xstr(sp, pkt->data[5], pkt);
  sp += pkt->data[5];
  apkt.port      = xstr(sp, pkt->data[6], pkt);
  sp += pkt->data[6];
  apkt.rem_addr  = xstr(sp, pkt->data[7], pkt);
  arglen         = pkt->data[5] + pkt->data[6] + pkt->data[7];
  argp           = pkt->data + 9 + arglen + nr;

  for(i = 0; i < nr; i++)
	arglen += pkt->data[9 + i];

  if (arglen + nr + 9 != pkt->length) {
	nsyslog(LOG_ERR, "acct_pkt: packet length mismatch");
	return -1;
  }
  for(i = 0; i < nr && i < 31; i++) {
	apkt.args[i] = xstr(argp, pkt->data[9 + i], pkt);
	argp += pkt->data[9 + i];
  }
  apkt.args[i] = 0;

  if (debug) printaapkt(&apkt);

  /*
   *	We have to send a RADIUS accounting packet here.
   */
  if ((apkt.flags & (0x02 | 0x04 | 0x08)) != 0) {

    memset(&acct, 0, sizeof(acct));
    strcpy(acct.login, apkt.user);
    acct.nas_ip = pkt->sin_addr.s_addr;
    acct.nas_port = tac_map(pkt->sin_addr.s_addr, apkt.port);
    if (apkt.flags & (0x02 | 0x08)) acct.islogin = 1;

    for(i = 0; apkt.args[i]; i++) {

	if (strncmp(apkt.args[i], "task_id=", 8) == 0)
		sprintf(acct.acctsessionid, "%08ld", atol(apkt.args[i] + 8));

	if (strncmp(apkt.args[i], "elapsed_time=", 13) == 0)
		acct.elapsed = atol(apkt.args[i] + 13);

	if (strncmp(apkt.args[i], "address=", 8) == 0)
		acct.address = inet_addr(apkt.args[i] + 8);

	if (strncmp(apkt.args[i], "service=", 8) == 0) {
		sp = apkt.args[i] + 8;
		if (strcmp(sp, "shell") == 0) {
			/*
			 *	FIXME: check cmd* for telnet,rlogin.
			 */
			acct.proto = P_CONSOLE;
		}
		if (strcmp(sp, "ppp") == 0)
			acct.proto = P_PPP;
	}
    }

    /*
     *	If this is a framed connection, only send the info
     *	if we have the IP address too!
     */
    sendit = 1;
    if (acct.proto == P_PPP || acct.proto == P_SLIP || acct.proto == P_CSLIP)
	if (acct.address == 0) sendit = 0;

    if (sendit) {
	DEBUG("Sending accounting info to RADIUS server.\n");
	rad_acct(&radius_conf, &acct);
    } else
	DEBUG("NOT sending accounting info to RADIUS server (no IPno).\n");
  }

  /*
   *	If the TAC_PLUS_ACCT_FLAG_MORE flag is not set, we
   *	can close the TCP connection.
   */
  if ((pkt->data[0] & 0x01) != 0x01)
	ret = -1;

  /*
   *	Send back a reply.
   */
  memset(reply, 0, 5);
  reply_len = 5;
  reply[4] = 0x01; /* TAC_PLUS_ACCT_STATUS_SUCCESS */

  DEBUG("Sending accounting reply\n");
  reply_pkt(s, pkt, reply, reply_len);

  return ret;
}

/*
 *	Print out hostname.
 */
void printhost(struct in_addr s)
{
  struct hostent *h;
  char *host;

  if ((h = gethostbyaddr((char *)&s.s_addr, 4, AF_INET)) == NULL)
	host = inet_ntoa(s);
  else
	host = (char *)h->h_name;
  DEBUG("Ah, a connection from %s\n", host);
}

/*
 *	Handle one connection.
 *
 *	TODO: We should select() on all sockets in use and
 *	also listen to the UNIX domain socket to see if
 *	fd's are passed. When all connections are closed we die.
 *	(or, if only the UNIX socket is open we die after 10 secs or so).
 *
 */
int do_connection(int s, struct sockaddr_in *sin)
{
  struct tacplus_pkt xx, *pkt = &xx;
  pid_t pid;
  int n = 0;

  if ((pid = fork()) != 0)
	return pid;

  signal(SIGHUP,  SIG_DFL);
  signal(SIGINT,  SIG_DFL);
  signal(SIGTERM, SIG_DFL);

  DEBUG("Forked daemon to handle connection (pid %d)\n", getpid());
  mypid = getpid();

  pkt->sin_addr = sin->sin_addr;
  if (debug) printhost(pkt->sin_addr);

  while (n >= 0 && readpkt(pkt, s) == 0) {
	switch (pkt->type) {
		case TAC_PLUS_AUTHEN:
			n = authen_pkt(s, pkt);
			break;
		case TAC_PLUS_AUTHOR:
			n = author_pkt(s, pkt);
			break;
		case TAC_PLUS_ACCT:
			n = acct_pkt(s, pkt);
			break;
		default:
			nsyslog(LOG_ERR,
				"readpkt: unknown packet type (0x%02x)",
				pkt->type);
			n = -1;
			break;
	}
  }

  DEBUG("Connection daemon exiting\n");
  exit(0);
}



/*
 *	Initialize: read the tacp2rad.conf and tacp2rad.map file.
 */
static int rad_init(void)
{
  FILE *fp;
  char buf[256];
  char *s, *t;

  if ((fp = fopen(CONFFILE, "r")) == NULL) {
	nsyslog(LOG_ERR, "%s: %m", CONFFILE);
	return -1;
  }

  while(fgets(buf, 256, fp)) {
	if (buf[0] == '#' || buf[0] == '\n')
		continue;
	s = strtok(buf,  " \t\n");
	t = strtok(NULL, " \t\n");
	if (t == NULL) continue;

	if (strcmp(s, "authhost1") == 0)
		radius_conf.authhost1 = inet_addr(t);
	else if (strcmp(s, "authhost2") == 0)
		radius_conf.authhost2 = inet_addr(t);
	else if (strcmp(s, "accthost1") == 0)
		radius_conf.accthost1 = inet_addr(t);
	else if (strcmp(s, "accthost2") == 0)
		radius_conf.accthost2 = inet_addr(t);
	else if (strcmp(s, "secret") == 0)
		strcpy(radius_conf.secret, t);
	else
		nsyslog(LOG_ERR, "%s: unknown keyword \"%s\"",
			CONFFILE, s);
  }
  fclose(fp);

  if (radius_conf.authhost1 == 0 ||
      radius_conf.accthost1 == 0 ||
      radius_conf.secret[0] == 0) {
	nsyslog(LOG_ERR, "%s: missing authost, accthost or secret");
	return -1;
  }
  return 0;
}


/*
 *	Super simple wildcard matcher.
 */
static int matches(char *name, char *wild, char *matchpart)
{
	int len, wlen;
	int ret = 0;

	len = strlen(name);
	wlen = strlen(wild);

	if (len == 0 || wlen == 0) return 0;

	if (wild[0] == '*') {
		wild++;
		wlen--;
		if (wlen <= len && strcmp(name + (len - wlen), wild) == 0) {
			strcpy(matchpart, name);
			matchpart[wlen] = 0;
			ret = 1;
		}
	} else if (wild[wlen - 1] == '*') {
		wild[--wlen] = 0;
		if (wlen <= len && strncmp(name, wild, wlen) == 0) {
			strcpy(matchpart, name + wlen);
			ret = 1;
		}
	}

	return ret;
}


/*
 *	Map a tacacs port to a RADIUS port (serial0:19 --> s19, etc)
 */
int tac_map(unsigned int nas_addr, char *tac_port)
{
  FILE *fp;
  char buf[256], buf2[128];
  char *s, *t;
  int thishost = 0;
  int port = -1;

  if ((fp = fopen(MAPFILE, "r")) == NULL) {
	nsyslog(LOG_ERR, "%s: %m", MAPFILE);
	return -1;
  }

  while(fgets(buf, 256, fp)) {
	if (buf[0] == '#' || buf[0] == '\n')
		continue;
	s = strtok(buf,  " \t\n");
	t = strtok(NULL, " \t\n");
	if (t == NULL) continue;

	if (strcmp(s, "host") == 0)
		thishost = inet_addr(t);

	if (thishost != 0 && thishost != nas_addr)
		continue;

	if (!matches(tac_port, s, buf2))
		continue;

	if (t[0] == '+')
		port = atoi(t + 1) + atoi(buf2);
	else
		port = atoi(t);
	break;
  }
  fclose(fp);

  if (port < 0) {
	nsyslog(LOG_ERR, "tac_map: port %s (NAS %08x) no match",
		tac_port, nas_addr);
	port = 0;
  }

  return port;
}

void usage()
{
  fprintf(stderr, "usage: tacp2radd [-d]\n");
  exit(1);
}

int main(int argc, char **argv)
{
  int s, n, c;
  struct sockaddr_in sin;
  int len;
  int accept_errors = 0;
  struct sigaction sa;
  FILE *fp;

  while((c = getopt(argc, argv, "d")) != EOF) {
	switch(c) {
		case 'd':
			debug = 1;
			break;
		default:
			usage();
			break;
	}
  }

  /*
   *	Initialize.
   */
  if (debug)
	setvbuf(stdout, (char *)NULL, _IOLBF, 0);
  else {
	if (fork() != 0) exit(0);
	close(0);
	close(1);
	close(2);
	setsid();
	if ((fp = fopen(PIDFILE, "w")) != NULL) {
		fprintf(fp, "%d\n", getpid());
		fclose(fp);
	}
  }

  openlog("tacp2radd", LOG_PID, LOG_AUTHPRIV);
  nsyslog(LOG_INFO, "Daemon started.");
  rad_init();

  master = getpid();
  setpgid(0, 0);

  sa.sa_handler = chld_handler;
  sa.sa_mask    = 0;
  sa.sa_flags   = 0;
  sigaction(SIGCHLD, &sa, NULL);

  sa.sa_handler = term_handler;
  sa.sa_mask    = 0;
  sa.sa_flags   = 0;
  sigaction(SIGINT,  &sa, NULL);
  sigaction(SIGHUP,  &sa, NULL);
  sigaction(SIGTERM, &sa, NULL);

  /*
   *	Listen on port 49 (tacacs+).
   */
  if ((s = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
	nsyslog(LOG_ERR, "main: socket: %m");
	return 1;
  }
  sin.sin_family = AF_INET;
  sin.sin_port   = htons(TACACS_PORT);
  sin.sin_addr.s_addr   = INADDR_ANY;
  if (bind(s, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
	nsyslog(LOG_ERR, "main: bind: %m");
	close(s);
	return 1;
  }

  /*
   *	Start the buffer server, then start serving TACACS+ requests.
   */
  buffer_server();

  while (listen(s, 5) == 0) {
	if ((n = accept(s, (struct sockaddr *)&sin, &len)) < 0) {
		if (errno == EINTR || errno == ECONNRESET)
			continue;
		nsyslog(LOG_ERR, "main: accept: %m");
		if (accept_errors++ > 10) {
			nsyslog(LOG_ERR, "Too many accept errors - giving up");
			close(s);
			exit(1);
		}
		continue;
	}
	accept_errors = 0;
	do_connection(n, &sin);
	close(n);
  }
  nsyslog(LOG_ERR, "main: listen: %m");
  close(s);

  /*
   *	That's all, folks!
   */
  term_handler(SIGTERM);

  return 0;
}

