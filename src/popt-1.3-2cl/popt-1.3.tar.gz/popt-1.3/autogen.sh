#!/bin/sh

srcdir="`dirname $0`"
test -z "$srcdir" && srcdir=.

THEDIR="`pwd`"

cd "$srcdir"
libtoolize --copy --force
aclocal
autoheader
automake
autoconf

if [ "$1" = "--noconfigure" ]; then 
    exit 0;
fi

cd "$THEDIR"

if [ X"$@" = X  -a "X`uname -s`" = "XLinux" ]; then
    $srcdir/configure --disable-shared --prefix=/usr
else
    $srcdir/configure --disable-shared "$@"
fi
