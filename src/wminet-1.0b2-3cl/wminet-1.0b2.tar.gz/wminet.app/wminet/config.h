// Config file for WMiNET

// Most options are now set in the config file ~/.wminetrc

// HTTP monitoring
// Uncomment _1_ of the following.

// HTTP_MONITOR_PROC will show the current number of httpd processes
//   but uses 2% cpu on a p100 (ouch)

// HTTP_MONITOR_NET will count inbound tcp connections on ports 80 and 8080
// (reccomended) - uses much less cpu

// #define HTTP_MONITOR_PROC 1
#define HTTP_MONITOR_NET 1

// Maximum ftp classes
// Set this to at least the number of different classes you
// have configured (usually in /etc/ftpaccess)

#define MAX_FTP_CLASSES 5
