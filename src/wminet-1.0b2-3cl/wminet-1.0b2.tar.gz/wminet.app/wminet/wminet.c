/*

 wminet.c
 Inetd Monitor
 by Dave Clark (clarkd@skyia.com) and Antoine Nulle (warp@xs4all.nl)
 
 based on wmifs by Martijn Pieterse (pieterse@xs4all.nl).

 see http://windowmaker.mezaway.org for more awesome wm dock apps :)

*/


#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>


#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>

#include <utmp.h>
#include <dirent.h>

#include <X11/Xlib.h>
#include <X11/xpm.h>
#include <X11/extensions/shape.h>

#include "../wmgeneral/wmgeneral.h"
#include "../wmgeneral/misc.h"

#include "wminet-master.xpm"
#include "wminet-mask.xbm"

#include "config.h"

#define WMINET_VERSION "1.0b2"

#define CHAR_WIDTH 5
#define CHAR_HEIGHT 7

extern	char **environ;

char	*ProgName;

int nUsers=0;
int nFtp=0;
int nHttp=0;
int nNfs=0;
int nProc=0;

int         numftpclasses=0;
char        ftpclasses[MAX_FTP_CLASSES][64];

int monitor_proc=0;
int monitor_users=0;
int monitor_ftp=0;
int monitor_http=0;
int monitor_nfs=0;

char ftp_pid_path[256];

void usage(void);
void printversion(void);
void BlitString(char *name, int x, int y);
void BlitNum(int num, int x, int y);
void GetStats( void );
void wminet_routine(int, char **);
int ReadConfigInt(FILE *fp, char *setting, int *value);
int ReadConfigString(FILE *fp, char *setting, char *value);


void main(int argc, char *argv[]) {

	int		i;
	
	/* Parse Command Line */

	ProgName = argv[0];
	if (strlen(ProgName) >= 5)
		ProgName += (strlen(ProgName) - 5);
	
	for (i=1; i<argc; i++) {
		char *arg = argv[i];

		if (*arg=='-') {
			switch (arg[1]) {
			case 'd' :
				if (strcmp(arg+1, "display")) {
					usage();
					exit(1);
				}
				break;
			case 'v' :
				printversion();
				exit(0);
				break;
			default:
				usage();
				exit(0);
				break;
			}
		}
	}

	wminet_routine(argc, argv);
}

/*******************************************************************************\
|* wminet_routine														   *|
\*******************************************************************************/

void wminet_routine(int argc, char **argv)
{
    int			i;
	XEvent		Event;
	int			but_stat = -1;

    time_t		curtime;
	time_t		prevtime;

    DIR         *dir;
    struct dirent *dent;

    FILE *fp;
    char config_file[512];

    char action_proc[256];
    char action_users[256];
    char action_ftp[256];
    char action_http[256];
    char action_nfs[256];

    memset(&ftpclasses, 0, sizeof(ftpclasses));
    action_proc[0]=0;
    action_users[0]=0;
    action_ftp[0]=0;
    action_http[0]=0;
    action_nfs[0]=0;
    
    
	openXwindow(argc, argv, wminet_master_xpm, wminet_mask_bits, wminet_mask_width, wminet_mask_height);

	/* > Button */
	AddMouseRegion(0, 5, 6, 58, 16);
	AddMouseRegion(1, 5, 16, 58, 26);
	AddMouseRegion(2, 5, 26, 58, 36);
	AddMouseRegion(3, 5, 36, 58, 46);
	AddMouseRegion(4, 5, 46, 58, 56);

    // Read config file
    sprintf(config_file, "%s/.wminetrc", getenv("HOME"));

    fp = fopen(config_file, "r");
    if (fp)
    {
        ReadConfigString(fp, "action_proc", action_proc);
        ReadConfigString(fp, "action_users", action_users);
        ReadConfigString(fp, "action_ftp", action_ftp);
        ReadConfigString(fp, "action_http", action_http);
        ReadConfigString(fp, "action_nfs", action_nfs);
        ReadConfigInt(fp, "monitor_proc", &monitor_proc);
        ReadConfigInt(fp, "monitor_users", &monitor_users);
        ReadConfigInt(fp, "monitor_ftp", &monitor_ftp);
        ReadConfigInt(fp, "monitor_http", &monitor_http);
        ReadConfigInt(fp, "monitor_nfs", &monitor_nfs);
        ReadConfigString(fp, "ftp_pid_path", ftp_pid_path);
        
        fclose(fp);
    }

    if ( monitor_ftp )
    {
        // Determine FTP PID files to search
        dir = opendir(ftp_pid_path);
        if (dir)
        {
            while ((dent = readdir(dir)))
            {
                //printf("scanning: %s\n", dent->d_name);
                if (strstr(dent->d_name, "ftp.pids-") != NULL)
                {
                    strcpy(ftpclasses[numftpclasses++], dent->d_name);
                    //printf("ftppidfile: %s\n", dent->d_name);
                }
            }
    
            closedir(dir);
        }
    }

    // set up labels
    BlitString("procs:", 5, 5);
    BlitString("users:", 5, 16);
    BlitString("ftp  :", 5, 27);
    BlitString("http :", 5, 38);
    BlitString("nfs  :", 5, 49);

    copyXPMArea(39, 84, (3*CHAR_WIDTH), 8, 39, 5);
    copyXPMArea(39, 84, (3*CHAR_WIDTH), 8, 39, 16);
    copyXPMArea(39, 84, (3*CHAR_WIDTH), 8, 39, 27);
    copyXPMArea(39, 84, (3*CHAR_WIDTH), 8, 39, 38);
    copyXPMArea(39, 84, (3*CHAR_WIDTH), 8, 39, 49);
                
    BlitString("XX", 45, 5);
    BlitString("XX", 45, 16);
    BlitString("XX", 45, 27);
    BlitString("XX", 45, 38);
    BlitString("XX", 45, 49);

    
    RedrawWindow();

    prevtime = time(0) - 1;
    
    while (1)
    {
		curtime = time(0);
		waitpid(0, NULL, WNOHANG);

        
        if ( curtime >= prevtime + 1)
        {
            prevtime = curtime;

            // Get data to display
            GetStats();
    

            // Display the stuff

            if ( monitor_proc )
            {
                copyXPMArea(39, 84, (3*CHAR_WIDTH), 8, 39, 5);
                BlitNum(nProc, 45, 5);
            }

            if ( monitor_users )
            {
                copyXPMArea(39, 84, (3*CHAR_WIDTH), 8, 39, 16);
                BlitNum(nUsers, 45, 16);
            }

            if ( monitor_ftp )
            {
                copyXPMArea(39, 84, (3*CHAR_WIDTH), 8, 39, 27);
                BlitNum(nFtp, 45, 27);
            }

            if ( monitor_http )
            {
                copyXPMArea(39, 84, (3*CHAR_WIDTH), 8, 39, 38);
                BlitNum(nHttp, 45, 38);
            }

            if ( monitor_nfs )
            {
                copyXPMArea(39, 84, (3*CHAR_WIDTH), 8, 39, 49);
                BlitNum(nNfs, 45, 49);
            }

            RedrawWindow();
        }
        
        // X Events
        while (XPending(display))
        {
			XNextEvent(display, &Event);
            switch (Event.type)
            {
			case Expose:
				RedrawWindow();
				break;
			case DestroyNotify:
				XCloseDisplay(display);
				exit(0);
                break;
			case ButtonPress:
				i = CheckMouseRegion(Event.xbutton.x, Event.xbutton.y);

				but_stat = i;
				break;
			case ButtonRelease:
				i = CheckMouseRegion(Event.xbutton.x, Event.xbutton.y);

                if (but_stat == i && but_stat >= 0)
                {
                    switch (but_stat)
                    {
                    case 0 :
                        execCommand(action_proc);
                        break;
                    case 1 :
                        execCommand(action_users);
                        break;
                    case 2:
                        execCommand(action_ftp);
                        break;
                    case 3:
                        execCommand(action_http);
                        break;
                    case 4:
                        execCommand(action_nfs);
                        break;

					}
				}
				but_stat = -1;
//				RedrawWindow();
				break;
			}
		}

		usleep(100000L);
	}
}


void GetStats( void )
{
    struct utmp *ut;
    FILE *fp;
    pid_t pid;
    char buf[1024];
    char *tok;
    int i;
    char seps[]={"/"};
    char sep2[]={":"};

#ifdef HTTPD_MONITOR_PROC
    DIR *dir;
    struct dirent *dent;
#endif
    
    // get statistics for display

    // logged in users
    nUsers=0;

    if ( monitor_users )
    {
        
        setutent();
        while ((ut = getutent()))
        {
            if (ut->ut_type == USER_PROCESS)
            {
                nUsers++;
            }
        }
        endutent();
    }

    // ftp connects
    nFtp = 0;

    if ( monitor_ftp )
    {
        for (i=0; i!= numftpclasses; i++)
        {
            sprintf(buf, "%s/%s", ftp_pid_path, ftpclasses[i]);
            //printf("opening '%s'\n", buf);
            fp = fopen(buf, "r");
            if (fp)
            {
                while ( fread(&pid, sizeof(pid), 1, fp) == 1 )
                {
                    if (pid)
                    {
                        nFtp++;
                    }
                }
                fclose(fp);
            }
        }
    }
    

    // httpd processes
    nHttp = 0;

#ifdef HTTP_MONITOR_PROC

    if ( monitor_http )
    {

        dir = opendir("/proc");
        if (dir)
        {
            while ( (dent = readdir(dir)) )
            {
                if (!isalpha(dent->d_name[0]))
                {
                    sprintf(buf, "/proc/%s/stat", dent->d_name);
                    //printf("opening '%s'\n", buf);
                    fp=fopen(buf, "r");
                    if (fp)
                    {
                        fgets(buf, 128, fp);
                        tok = buf + strlen(dent->d_name) + 1;
                        //printf("checking '%s'\n", tok);
                        if (strncmp(tok, "(httpd)", 7) == 0)
                        {
                            nHttp++;
                        }
                        fclose(fp);
                    }
                }
            }
            closedir(dir);
        }
    }
#endif

#ifdef HTTP_MONITOR_NET

    if ( monitor_http )
    {

        fp = fopen("/proc/net/tcp", "r");
        if (fp)
        {
            fgets(buf, 512, fp); // get rid of text header
    
            while ( (fgets(buf, 512, fp)) )
            {
                tok = strtok(buf, sep2);
                tok = strtok(NULL, sep2);
                tok = strtok(NULL, sep2);
    
                tok[4]=0;
    
                // printf("port: %i\n", strtol(tok, NULL, 16));
    
                i = strtol(tok, NULL, 16);
    
                // should make this configurable
                if ( i == 80  || i == 8080)
                {
                    nHttp++;
                }
    
            }
    
            fclose(fp);
        }
    }
#endif


    // NFS connects
    nNfs = 0;

    if ( monitor_nfs )
    {
        fp = popen("/usr/sbin/showmount", "r");
        if (fp)
        {
            while ( (fgets(buf, 128, fp)) )
            {
                nNfs++;
            }
    
            nNfs--;
            
            pclose(fp);
        }
    }

    // Total Processes
    nProc = 0;

    if ( monitor_proc )
    {
        
        fp = fopen("/proc/loadavg", "r");
        if (fp)
        {
            fgets((char *) &buf, 50, fp);
            tok = strtok((char *)&buf, (char *)&seps); // mmmmmmmm... strtok
            tok = strtok(NULL, (char *)&seps);
            nProc=atoi(tok);
            
            fclose(fp);
        }
    }
}

// Blits a string at given co-ordinates
void BlitString(char *name, int x, int y)
{
    int		i;
	int		c;
    int		k;

	k = x;
    for (i=0; name[i]; i++)
    {

        c = toupper(name[i]); 
        if (c >= 'A' && c <= 'Z')
        {   // its a letter
			c -= 'A';
			copyXPMArea(c * 6, 74, 6, 8, k, y);
			k += 6;
        }
        else
        {   // its a number or symbol
			c -= '0';
			copyXPMArea(c * 6, 64, 6, 8, k, y);
			k += 6;
		}
	}

}


// Blits number to give coordinates.. two 0's, right justified

void BlitNum(int num, int x, int y)
{
    char buf[1024];
    int newx=x;

    if (num > 99)
    {
        newx -= CHAR_WIDTH;
    }

    if (num > 999)
    {
        newx -= CHAR_WIDTH;
    }

    sprintf(buf, "%02i", num);

    BlitString(buf, newx, y);
}
    

// ReadConfigSetting
int ReadConfigString(FILE *fp, char *setting, char *value)
{
    char str[1024];
    char buf[1024];
    int i;
    int len;
    int slen;
    char *p=NULL;


    if (!fp)
    {
        return 0;
    }

    sprintf(str, "%s=", setting);
    slen = strlen(str);
    
    fseek(fp, 0, SEEK_SET);

    while ( !feof(fp) )
    {
        
        if (!fgets(buf, 512, fp))
            break;
        
        len = strlen(buf);

        // strip linefeed
        for (i=0; i!=len; i++)
        {
            if (buf[i] == '\n')
            {
                buf[i] = 0;
            }
        }

        //printf("Scanning '%s'...\n", buf);
        if ( strncmp(buf, str, strlen(str)) == 0)
        {
            // found our setting
            
            for(i=0; i!=slen; i++)
            {
                if ( buf[i] == '=' )
                {
                    p=buf+i+1;
                    strcpy(value, p);
                    return 1;
                }
            }
    
        }
    }
    
        return 0;
}

int ReadConfigInt(FILE *fp, char *setting, int *value)
{
    char buf[1024];

    if (ReadConfigString(fp, setting, (char *) &buf))
    {
        *value = atoi(buf);
        return 1;
    }

    return 0;
}

    
            
            



/*******************************************************************************\
|* usage																	   *|
\*******************************************************************************/

void usage(void)
{
    fprintf(stderr, "\nWMiNET - illusion <clarkd@skyia.com> & warp <warp@xs4all.nl>\n\n");
	fprintf(stderr, "usage:\n");
	fprintf(stderr, "\t-d <display name>\n");
	fprintf(stderr, "\t-h\tthis help screen\n");
	fprintf(stderr, "\t-v\tprint the version number\n");
	fprintf(stderr, "\n");
}

/*******************************************************************************\
|* printversion																   *|
\*******************************************************************************/

void printversion(void)
{
	fprintf(stderr, "wminet v%s\n", WMINET_VERSION);
}
