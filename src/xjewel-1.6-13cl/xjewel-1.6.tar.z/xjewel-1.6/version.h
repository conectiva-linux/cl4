/*
**
**	X11 Jewel By David Cooper and Jose Guterman 05/92
**
*/


char *VerString="Version 1.6 (1/29/93) By David Cooper and Jos\351 Guterman";
