/*
**
**	X11 Jewel By David Cooper and Jose Guterman 05/92
**
*/


extern void Expose_Help();
extern void Start_Help();
extern void Init_Help();
