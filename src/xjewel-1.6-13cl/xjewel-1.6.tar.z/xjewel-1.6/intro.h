/*
**
**	X11 Jewel By David Cooper and Jose Guterman 05/92
**
*/

/* functions declared in intro.c */

extern void Expose_Intro();
extern void Init_Intro();
extern void Intro_Timeout();
extern void Start_Intro();
