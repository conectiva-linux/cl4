
/* THIS DOES NOT WORK. STILL IN CODE WRITTING PHASE */


#include "../_pwdb_internal.h"
/* _pwdb_dup_string and _pwdb_delete_string */
#include "../pwdb/pwdb_public.h"
#include "../nis/public.h"

 /* getgrgid - locate the group entry for a given GID
 *
 * getgrgid() locates the first group file entry for the given GID.
 */

struct __pwdb_group * __pwdb_decnis_getgrgid (gid_t gid) 
{
   return __pwdbNIS_getgrgid (gid);
}
/*
 * getgrnam - locate the group entry for a given name
 *
 * getgrnam() locates the first group file entry for the given name.
 */

struct __pwdb_group * __pwdb_decnis_getgrnam (const char * name) 
{
   return __pwdbNIS_getgrnam (name); 
}
