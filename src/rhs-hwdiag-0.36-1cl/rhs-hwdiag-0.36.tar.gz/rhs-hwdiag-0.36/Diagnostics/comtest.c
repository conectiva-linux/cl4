/*
 * Michael Fulbright (msf@redhat.com)
 *
 * Copyright 1997 Red Hat Software
 *
 * This software may be freely redistributed under the terms of the GNU
 * public license.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
  


#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <linux/tty.h>
#include <linux/serial.h>

main(int argc, char **argv) {
    int i, fd;
    int err;

    struct serial_struct serinfo;

    if (argc < 2)
	exit(1);
    
    fd=open(argv[1], O_RDWR|O_NONBLOCK);
    err=errno;
    if (fd<0) {
	perror("open");
	printf("errno = %d\n",err);
	exit(1);
    }

    if (!isatty(fd)) {
	printf("This is not a terminal device\n");
	close(fd);
	exit(1);
    }
    
    if (ioctl(fd, TIOCGSERIAL, &serinfo) < 0) {
	perror("Cannot get serial info");
	close(fd);
	exit(1);
    }

    if (serinfo.type == 0) {
	printf("Unknown UART type\n");
    }
    
    close(i);
}
