/* header file for public routines in utils.c */

#ifndef PNP_UTILS_H
#define PNP_UTILS_H

void print_hex_data( unsigned char *p, int len );

#endif
