/* header file for PnP probing of the parallel port */
#ifndef PNP_PROBE_PARPORT_H
#define PNP_PROBE_PARPORT_H

#include "devprobe.h"

int pnp_probe_parport( struct devprobe **t, char *port );

#endif
