/* generic utility functions useful for PnP tools 
 *
 * Michael Fulbright (msf@redhat.com)
 *
 * Copyright 1997 Red Hat Software
 *
 * This software may be freely redistributed under the terms of the GNU
 * public license.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
*/
  
#include <stdio.h>
#include <signal.h>
#include <unistd.h>

/* NOTE - need to add support into util.h so other routines can see */

/* Generic alarm support */
/* Set alarm with set_alarm(delay) */
/* Check status of alarm with get_alarm() */
/* Reset alarm with reset_alarm() */
/* PROBABLY NOT THREAD FRIENDLY */

int __alarm_in_use=0;
int __alarm_went_off=0;

static void __alarm_signal_handler( int dummy ) {
    __alarm_went_off=1;
    __alarm_in_use=0;
}

/* returns < 0 if alarm in use */
/* delay is in seconds */
int set_alarm(int delay) {
    if (__alarm_in_use)
	return -1;
    __alarm_in_use=1;
    signal(SIGALRM, __alarm_signal_handler);
    alarm(delay);
    return 0;
}

/* tell if alarm is in use or has expired */
/* ALARM_RUNNING means it is in use */
/* ALARM_EXPIRED means it went off  (and ready to use again) */
/* ALARM_READY   means it is ready for use (hasnt gone off) */
#define ALARM_RUNNING -1
#define ALARM_EXPIRED  0
#define ALARM_READY    1
int get_alarm( void ) {
    if (__alarm_in_use)
	return ALARM_RUNNING;
    else
	return (__alarm_went_off) ? ALARM_EXPIRED : ALARM_READY;
}

void reset_alarm( void ) {
    alarm(0);
    __alarm_in_use   = 0;
    __alarm_went_off = 0;
}

/* outputs data in a hex table, 8 values per row */
void print_hex_data( unsigned char *data, int len ) {
    int i, j, pos;

    if (len == 0) {
	printf("No data to print.\n");
	return;
    }

    pos = 0;
    for (i=0; i< len; i+=8) {
	printf("0x%.4x ", i);
	for (j=i; j < len && j < i+8; j++) {
	    printf("0x%.2x ",data[pos++]);
	}
	printf("\n");
    }
}



