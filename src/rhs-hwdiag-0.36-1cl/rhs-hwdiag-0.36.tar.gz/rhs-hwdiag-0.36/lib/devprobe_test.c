#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "devprobe.h"



int main () {
    int status;
    struct devprobe *t;

    t = devprobe_create();
    devprobe_setinfo(t, DEVPROBE_GENPNP);
    status = devprobe_insert(t, "MODEL", "HP6P" );
    status = devprobe_insert(t, "MANUFACTURER", "HP" );
    status = devprobe_insert(t, "CLASS", "PRINTER" );
    status = devprobe_insert(t, "LINUX DEVICE", "/dev/lp1" );
    devprobe_print(t, stdout);
    printf("Match of 'CLASS' yields \"%s\"\n",devprobe_match(t,"CLASS"));
    devprobe_destroy( t );
    exit(0);
}

