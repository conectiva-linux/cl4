/* routines to manipulate the devprobe struct
 *
 * Michael Fulbright (msf@redhat.com)
 *
 * Copyright 1997 Red Hat Software 
 *
 * This software may be freely redistributed under the terms of the GNU
 * public license.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "devprobe.h"


/* These routines implement various action on the devprobe structure */
/*                                                                   */
/*     devprobe_create()          -  create a struct                 */
/*     devprobe_destroy()         -  destroy                         */
/*     devprobe_insert()          -  add a field to a devprobe       */
/*     devprobe_remote()          -  remove a field                  */
/*     devprobe_match()           -  search for a given field        */


/* increment we use when building up array of fields/values */
#define DEVPROBE_NFIELD_INC  8

/* dynamically allocate a new devprobe structure */
struct devprobe *devprobe_create( void ) {
    struct devprobe  *s;

    s = (struct devprobe *) malloc( sizeof(struct devprobe) );
    if (s) {
	s->probe_info = DEVPROBE_NONE;
	s->nfields    = 0;
	s->fields     = NULL;
    }

    return s;
}

void devprobe_destroy( struct devprobe *s ) {

    if (s) {
	int i;

	for (i=0; i < s->nfields; i++) {
	    if (s->fields[i]) {
		if (s->fields[i]->name)
		    free(s->fields[i]->name);
		if (s->fields[i]->value)
		    free(s->fields[i]->value);
		free(s->fields[i]);
	    }
	}

	free(s);
    }
}

/* two routines to manipulate the probe_info field */
int devprobe_setinfo( struct devprobe *s, int flag ) {
    if (!s)
	return -1;

    s->probe_info = flag;
    return 0;
}

int devprobe_getinfo( struct devprobe *s ) {
    if (!s)
	return -1;

    return s->probe_info;
}

/* return value < 0 means we ran into trouble */
int devprobe_insert( struct devprobe *s, char *fieldname, char *value ) {
    /* die if they passed a bad structure or fieldname */
    /* we allow a null value however                   */
    if (!s || !fieldname)
	return -1;

    /* see if we need to expand the space allocated for field/value pairs */
    if (s->nfields % DEVPROBE_NFIELD_INC == 0) {
	struct devfield **t;

	t = (struct devfield **) realloc( s->fields,
		 (s->nfields+DEVPROBE_NFIELD_INC)*sizeof(struct devfield *));
	if (!t)
	    return -1;
	else
	    s->fields = t;
    }

    s->fields[s->nfields]=(struct devfield *) malloc(sizeof(struct devfield));
    s->fields[s->nfields]->name   = strdup(fieldname);
    if (value)
	s->fields[s->nfields]->value  = strdup(value);
    else
	s->fields[s->nfields]->value  = NULL;
	
    s->nfields++;
    return 0;
}





/* returns non-null pointer to value of field if                     */
/* if the requested fieldname is found, otherwise NULL is returned   */
/* match is case-insensitive                                         */
char *devprobe_match( struct devprobe *s, char *fieldname ) {
    int i;
    int found;
    
    if (!s || !fieldname || !s->fields )
	return NULL;

    for (i=0, found=0; i < s->nfields; i++)
	if (!strcasecmp( s->fields[i]->name, fieldname )) {
	    found=1;
	    break;
	}

    if (!found)
	return NULL;
    else
	return strdup(s->fields[i]->value);

}



/* return value < 0 means we ran into trouble */
int devprobe_delete( struct devprobe *s, char *fieldname ) {
    int i, found;
    
    /* die if they passed a bad structure or fieldname */
    /* we allow a null value however                   */
    if (!s || !fieldname)
	return -1;

    /* see if the entry exists */
    for (i=0, found=0; i < s->nfields; i++)
	if (!strcasecmp( s->fields[i]->name, fieldname )) {
	    found=1;
	    break;
	}

    if (!found)
	return -1;
    else {
	free(s->fields[i]->name);
	free(s->fields[i]->value);
	for (; i < s->nfields-1; i++) {
	    s->fields[i]->name = s->fields[i+1]->name;
	    s->fields[i]->value = s->fields[i+1]->value;
	}
	s->nfields--;
	return 0;
    }
}




/* return probe info type as a ascii string */
char *devprobe_infotoasc( struct devprobe *s ) {
    char *retstr=NULL;
    
    if (!s)
	retstr="Struct NULL";
    else if (s->probe_info == DEVPROBE_NONE)
	retstr="No info";
    else if (s->probe_info & DEVPROBE_LEGACY) 
	retstr="Legacy device";
    else if (s->probe_info & DEVPROBE_PCI) 
	retstr="PCI device";
    else if (s->probe_info & DEVPROBE_ISAPNP)
	retstr="ISAPnP device";
    else if (s->probe_info & DEVPROBE_GENPNP) 
	retstr="Generic PnP device";
    else if (s->probe_info & DEVPROBE_SCSI) 
	retstr="SCSI device";
    else if (s->probe_info & DEVPROBE_IDE) 
	retstr="IDE device";
    else if (s->probe_info & DEVPROBE_PSAUX) 
	retstr="PS/2 AUX device";
    else
	retstr="Unknown";

    if (retstr)
	return strdup(retstr);
    else
	return retstr;
}

/* simple helper function to tack a string onto a buffer, growing */
/* the buffer by the required amount                              */
static void strcatbuf(char **buf, char *str) {
    int len;

    if (!str || !buf)
	return;
    if (!*buf)
	len = 0;
    else
	len = strlen(*buf);
    *buf=realloc(*buf, len+strlen(str)+2);
    if (len)
	strcat(*buf, str);
    else
	strcpy(*buf, str);
}    
   

/* output structure contents to the file descr fd */
/* allocates string on the fly                    */
void devprobe_sprint(struct devprobe *s, char **buf) {
    int i;
    char *port;
    char str[256];
    
    if (!s) {
	*buf = strdup("Error - Devprobe structure is undefined.\n");
	return;
    }
    
    /* output the type of probe we have */
    port = devprobe_match(s, "LINUX DEVICE");
    if (port)
	snprintf(str,255,"---- Devprobe structure for device %s ----\n",port);
    else
	snprintf(str,255,"---- Devprobe structure for unknown device ----\n");
    strcatbuf(buf, str);
    
    snprintf(str,255,"PROBE_INFO : value = 0x%x [",s->probe_info);
    strcatbuf(buf,str);
    
    if (s->probe_info == DEVPROBE_NONE)
	strcatbuf(buf,"No information available");
    else if (s->probe_info & DEVPROBE_LEGACY) 
	strcatbuf(buf,"Legacy device");
    else if (s->probe_info & DEVPROBE_PCI) 
	strcatbuf(buf,"PCI device");
    else if (s->probe_info & DEVPROBE_ISAPNP)
	strcatbuf(buf,"ISAPnP device");
    else if (s->probe_info & DEVPROBE_GENPNP) 
	strcatbuf(buf,"Generic PnP device");
    else if (s->probe_info & DEVPROBE_SCSI) 
	strcatbuf(buf,"SCSI device");
    else if (s->probe_info & DEVPROBE_IDE) 
	strcatbuf(buf,"IDE device");
    else if (s->probe_info & DEVPROBE_PSAUX) 
	strcatbuf(buf,"PS/2 AUX device");
    else
	strcatbuf(buf,"Unknown flag");
    strcatbuf(buf,"]\n\n");
    
    if (s->nfields == 0)
	strcatbuf(buf,"No fields defined.\n");
    else {
	for (i=0; i<s->nfields; i++)
	    if (s->fields[i]->name) {
		snprintf(str,255, "   %-15s:  ",s->fields[i]->name);
		strcatbuf(buf,str);
		if (s->fields[i]->value)
		    snprintf(str,255, "\"%s\"\n",s->fields[i]->value);
		else
		    snprintf(str,255, "\"\"\n");
		strcatbuf(buf,str);
	    }
    }

    strcatbuf(buf,"---------- End of Devprobe structure -------------\n");
}

void devprobe_print( struct devprobe *s, FILE *f ) {
    char *buf=NULL;

    devprobe_sprint( s, &buf );
    if (buf) {
	fwrite(buf, 1, strlen(buf), f);
	free(buf);
    }
}


/* sortof a misc function */
/* if no class returned from device, try to determine class */
/* from other fields it returned                            */
/*                                                          */
/*                                                          */
/* First - if 'MANUFACTURER' or 'MFG' fields exist, and are */
/*         'PNP', then use the 'MODEL' field as an index in */
/*         generic PNP classes                              */
/* Second - if 'PNP COMPATIBLE' field exists, search it     */
/*          for a 'PNPxxxx', which gives the # we use above */
/*                                                          */
/* return < 0 if unsuccessful, otherwise sticks 'CLASS'     */
/* field in the devprobe structure                          */
int devprobe_guess_pnp_class( struct devprobe *t ) {

    char *value;
    char *model;
    char *tmpstr;

    model=NULL;
    
    /* see if 'MANUFACTURER' and 'MFG' fields exist */
    if ((value=devprobe_match(t, "MANUFACTURER"))==NULL)
	value=devprobe_match(t, "MFG");

    if (value) {
	/* hey we found one of these */
	if (!strcasecmp(value, "PNP"))
	    model=devprobe_match(t, "MODEL");
    }

    /* otherwise, check for 'PNP COMPATIBLE' */
    if ((value=devprobe_match(t, "PNP COMPATIBLE"))) {
	/* look for 'PNP' inside of string */
	tmpstr = strstr(value, "PNP");
	if (tmpstr)
	    model = tmpstr + 3;
    }

    if (!model)
	return -1;

    if (!strncmp(model, "0F", 2))
	devprobe_insert(t, "CLASS", "MOUSE");
    else if (!strncmp(model, "C", 1))
	devprobe_insert(t, "CLASS", "MODEM");
    else
	return -1;

    /* we did it */
    return 0;
}
    
