#include <stdio.h>
main() { lseek(0,0,0); }
