char *readsoname(char *name, FILE *file, int expected_type, int *type);
