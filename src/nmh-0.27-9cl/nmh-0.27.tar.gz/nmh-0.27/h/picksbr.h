
/*
 * picksbr.h -- definitions for picksbr.c
 *
 * $Id$
 */

/*
 * prototypes
 */
int pcompile (char **, char *);
int pmatches (FILE *, int, long, long);
