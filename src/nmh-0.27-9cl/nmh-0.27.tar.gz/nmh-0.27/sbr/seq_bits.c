
/*
 * seq_bits.c -- return the snprintb() string for a sequence
 *
 * $Id$
 */

#include <h/mh.h>


char *
seq_bits (struct msgs *mp)
{
    int i;
    static char buffer[BUFSIZ];

    strcpy (buffer, MBITS);
    for (i = 0; mp->msgattrs[i]; i++)
	sprintf (buffer + strlen (buffer), "%c%s",
		FFATTRSLOT + 1 + i, mp->msgattrs[i]);

    return buffer;
}
