
/*
 * context_find.c -- find an entry in the context/profile list
 *
 * $Id$
 */

#include <h/mh.h>


char *
context_find (char *str)
{
    struct node *np;

    context_read();
    for (np = m_defs; np; np = np->n_next)
	if (!strcasecmp (np->n_name, str))
	    return (np->n_field);

    return NULL;
}
