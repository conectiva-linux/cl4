
/*
 * m_atoi.c -- parse a string representation of a message number
 *
 * $Id$
 */

#include <h/mh.h>


int
m_atoi (char *str)
{
    int i;
    char  *cp;

    i = 0;
    cp = str;

    while (*cp) {
#ifdef LOCALE
	if (!isdigit(*cp))
#else
	if (*cp < '0' || *cp > '9')
#endif
	    return 0;
	i *= 10;
	i += *cp++ - '0';
    }

    return i;
}
