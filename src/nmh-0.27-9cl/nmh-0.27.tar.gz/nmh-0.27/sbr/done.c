
/*
 * done.c -- terminate the program
 *
 * $Id$
 */

#include <h/mh.h>

void
done (int status)
{
    exit (status);
}
