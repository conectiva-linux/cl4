
/*
 * m_scratch.c -- construct a scratch file
 *
 * $Id$
 */

#include <h/mh.h>


char *
m_scratch (char *file, char *template)
{
    char *cp;
    static char buffer[BUFSIZ], tmpfil[BUFSIZ];

    sprintf (tmpfil, "%sXXXXXX", template);
    mktemp (tmpfil);
    if ((cp = r1bindex (file, '/')) == file)
	strcpy (buffer, tmpfil);
    else
	sprintf (buffer, "%.*s%s", cp - file, file, tmpfil);
    unlink (buffer);

    return buffer;
}
