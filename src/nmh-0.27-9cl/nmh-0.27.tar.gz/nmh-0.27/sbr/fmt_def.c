
/*
 * fmt_def.c -- some defines for sbr/fmt_scan.c
 *
 * $Id$
 */

#include <h/addrsbr.h>

int fmt_norm = AD_NAME;
