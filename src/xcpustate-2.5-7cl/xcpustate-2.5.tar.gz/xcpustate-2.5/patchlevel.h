static char patchlevel[] = "xcpustate Version 2.5 $Id: patchlevel.h,v 1.13 1997/06/04 22:25:33 jdd Exp $";
