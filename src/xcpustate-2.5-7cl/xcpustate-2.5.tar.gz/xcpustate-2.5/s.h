/*
 *  Any system dependent file must implement these routines. See s-bsd.c
 *  and s-sunos5.c for examples.
 */
extern int num_bars();
extern void bar_items(/* int nbars, int items[] */);
extern char **label_bars(/* int nbars */);
extern void init_bars(/* int nbars */);
extern void display_bars(/* int nbars */);
