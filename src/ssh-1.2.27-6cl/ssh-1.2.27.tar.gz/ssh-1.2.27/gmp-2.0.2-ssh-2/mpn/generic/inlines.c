#define _FORCE_INLINES
#define _EXTERN_INLINE /* empty */
#include "gmp.h"
