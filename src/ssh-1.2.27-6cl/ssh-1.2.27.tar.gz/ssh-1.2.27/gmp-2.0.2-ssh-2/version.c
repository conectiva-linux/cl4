static char *gmp_version = "2.0.2-ssh-2";
