/* Define to __s64 if <sys/types.h> does not define */
#undef	quad_t

/* Define to __u64 if <sys/types.h> does not define */
#undef	u_quad_t
